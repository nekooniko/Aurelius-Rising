// JLLM preparation tab. Local-only, no website access or automatic injection.
document.addEventListener('DOMContentLoaded',async()=>{
  const seed=document.getElementById('jllm-seed');
  const status=document.getElementById('jllm-status');
  const stats=document.getElementById('jllm-seed-stats');
  const KEY='aureliusJllmContextSeed';
  const update=()=>{stats.textContent=`${seed.value.length.toLocaleString()} characters · approx. ${Math.ceil(seed.value.length/4).toLocaleString()} tokens (rough estimate)`;};
  try { const data=await chrome.storage.local.get(KEY); seed.value=data[KEY]||''; update(); }
  catch(e){status.textContent='Could not load local seed: '+e.message;}
  const captureStatus=document.getElementById('capture-jllm-status');
  async function activeChat(){
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    return tab && /^https:\/\/(www\.)?janitorai\.com\/chats\//.test(tab.url||'')?tab:null;
  }
  document.getElementById('jllm-lite-open').addEventListener('click',async()=>{
    const tab=await activeChat();
    if(!tab){captureStatus.textContent='Open a JLLM chat first.';return;}
    try{const result=await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_JLLM_LITE_OPEN'});
      captureStatus.textContent=result?.ok?'Node selector opened in the JLLM chat.':'Open a JLLM chat first.';
    }catch{captureStatus.textContent='Refresh the JLLM page after updating the extension.';}
  });
  document.getElementById('jllm-open-archive').addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL('archive.html#jllm-archive')}));
  seed.addEventListener('input',update);
  document.getElementById('jllm-save').addEventListener('click',async()=>{
    try{await chrome.storage.local.set({[KEY]:seed.value});status.textContent='Context seed saved locally.';}
    catch(e){status.textContent='Save failed: '+e.message;}
  });
  document.getElementById('jllm-copy').addEventListener('click',async()=>{
    try{await navigator.clipboard.writeText(seed.value);status.textContent='Context seed copied. Paste and review it in JLLM.';}
    catch(e){status.textContent='Copy failed: '+e.message;}
  });
});
