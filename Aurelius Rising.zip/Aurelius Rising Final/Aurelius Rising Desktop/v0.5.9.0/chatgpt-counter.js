// Aurelius Rising — ChatGPT message detector (read-only).
// Stores message IDs and inferred roles locally, never conversation text.
(() => {
  const SELECTOR = '[data-chatgpt-search-message-ids]';
  const STORAGE_PREFIX = 'aurelius:messages:';
  let conversation = '';
  let messages = new Map();
  let scheduled = false;
  let saveTimer;
  let generation = 0;
  let analyticsBaselineReady = false;
  let pendingGeneration = null;
  let extensionContextReady = false;

  function conversationKey() {
    const match = location.pathname.match(/^\/c\/([^/?#]+)/);
    return match ? STORAGE_PREFIX + match[1] : null;
  }

  function roleFor(element) {
    // In the observed ChatGPT DOM, an assistant turn's wrapper has a
    // data-chatgpt-agent-turn-start marker beside its search-unit container.
    const wrapper = element.parentElement;
    return wrapper?.querySelector(':scope > [data-chatgpt-agent-turn-start]')
      ? 'assistant' : 'user';
  }

  function counts() {
    let user = 0, assistant = 0;
    for (const role of messages.values()) {
      if (role === 'assistant') assistant++;
      else if (role === 'user') user++;
    }
    return { user, assistant, total: user + assistant };
  }

  function scheduleSave() {
    clearTimeout(saveTimer);
    const key = conversation;
    const snapshotGeneration = generation;
    saveTimer = setTimeout(async () => {
      if (generation !== snapshotGeneration || !key) return;
      try {
        await chrome.storage.local.set({ [key]: [...messages] });
      } catch (error) {
        console.warn('[Aurelius Rising] Could not persist counts:', error);
      }
    }, 250);
  }

  function scan() {
    if (!conversation) return;
    let changed = false;
    for (const element of document.querySelectorAll(SELECTOR)) {
      const ids = (element.getAttribute('data-chatgpt-search-message-ids') || '')
        .split(',').map(id => id.trim()).filter(Boolean);
      const role = roleFor(element);
      for (const id of ids) {
        if (messages.has(id)) continue;
        messages.set(id, role);
        changed = true;
        if (analyticsBaselineReady && role === 'assistant' && window.AureliusAnalytics && pendingGeneration?.until > Date.now()) {
          void window.AureliusAnalytics.generation('chatgpt', {reroll: pendingGeneration.reroll, assisted: pendingGeneration.assisted});
          pendingGeneration = null;
          extensionContextReady = false;
        }
      }
    }
    analyticsBaselineReady = true;
    if (changed) scheduleSave();
  }

  async function syncConversation() {
    const key = conversationKey();
    if (key === conversation) return;
    generation++;
    const thisGeneration = generation;
    clearTimeout(saveTimer);
    conversation = key || '';
    messages = new Map();
    analyticsBaselineReady = false;
    pendingGeneration = null;
    extensionContextReady = false;
    if (!key) return;
    try {
      const stored = await chrome.storage.local.get(key);
      if (generation !== thisGeneration) return;
      const pairs = stored[key];
      if (Array.isArray(pairs)) {
        messages = new Map(pairs.filter(pair =>
          Array.isArray(pair) && typeof pair[0] === 'string' &&
          (pair[1] === 'user' || pair[1] === 'assistant')));
      }
    } catch (error) {
      console.warn('[Aurelius Rising] Could not restore counts:', error);
    }
    if (generation === thisGeneration) scan();
  }

  function scheduleScan() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      if (conversationKey() !== conversation) void syncConversation();
      else scan();
    });
  }

  const observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement, {
    childList: true, subtree: true, attributes: true,
    attributeFilter: ['data-chatgpt-search-message-ids']
  });
  void syncConversation();

  window.addEventListener('aurelius:analytics-context-inserted', () => { extensionContextReady = true; });
  function composerHasExtensionMarker() {
    const node = document.querySelector('#prompt-textarea,[data-testid="composer-input"],[contenteditable="true"][role="textbox"],main [contenteditable="true"]');
    const text = node?.matches?.('textarea') ? node.value : (node?.innerText || node?.textContent || '');
    return extensionContextReady && text.includes('[Aurelius Rising behavior reminder]');
  }
  function armGeneration(reroll) {
    pendingGeneration = {until: Date.now() + 120000, reroll, assisted: composerHasExtensionMarker()};
  }
  // Detect send/retry controls from accessible labels only; never store composer text.
  document.addEventListener('click', event => {
    const button = event.target?.closest?.('button,[role="button"]');
    if (!button) return;
    const label = `${button.getAttribute('aria-label') || ''} ${button.getAttribute('data-testid') || ''} ${button.getAttribute('title') || ''}`;
    if (/regenerat|retry|try again/i.test(label)) armGeneration(true);
    else if (/send prompt|send message/i.test(label) || /send-button/i.test(label)) armGeneration(false);
  }, true);
  document.addEventListener('submit', event => {
    if (event.target?.querySelector?.('#prompt-textarea,[data-testid="composer-input"],[contenteditable="true"][role="textbox"]')) armGeneration(false);
  }, true);

  // ChatGPT changes routes without reloading. The periodic check also handles
  // history navigation where no relevant DOM mutation is emitted immediately.
  setInterval(() => {
    if (conversationKey() !== conversation) void syncConversation();
  }, 1000);

  // Same-page communication for the injection script (no background worker needed).
  window.addEventListener('aurelius:counts-request', event => {
    const respond = event.detail?.respond;
    if (typeof respond !== 'function') return;
    (async () => {
      if (conversationKey() !== conversation) await syncConversation();
      scan();
      respond({ ...counts(), conversation: conversationKey() });
    })();
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type !== 'AURELIUS_GET_COUNTS') return;
    (async () => {
      if (conversationKey() !== conversation) await syncConversation();
      scan();
      sendResponse({ ...counts(), url: location.href,
        scope: 'observed-message-ids', ready: Boolean(conversation) });
    })();
    return true;
  });
})();
