import {parseArchive,searchArchives,fingerprint,archiveStatistics,searchStatistics,getContext,preparedArchive,contextWindow,expandArchives,findSceneEvidence,parseClues,sceneEvidenceContext,sceneEvidenceCards} from './archive-core.js';
const $=id=>document.getElementById(id), DB='aurelius-archive-lab', STORE='archives';
function dbOpen(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE,{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function transact(mode,fn){const db=await dbOpen();try{return await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,mode),store=tx.objectStore(STORE);let request;try{request=fn(store)}catch(e){reject(e);return}tx.oncomplete=()=>resolve(request?.result);tx.onerror=()=>reject(tx.error);});}finally{db.close()}}
const all=()=>transact('readonly',s=>s.getAll());let archives=[];
const QUEUE_KEY='aureliusArchiveSceneQueue058';let queue=[];
const loadQueue=async()=>{queue=(await chrome.storage.local.get(QUEUE_KEY))[QUEUE_KEY]||[];renderQueue()};
const saveQueue=async()=>{await chrome.storage.local.set({[QUEUE_KEY]:queue});renderQueue()};
let sceneMode=false;const PAGE_SIZE=50;let currentPage=0,searchResults=[],searchElapsed=0,statsCache=null,searchTimer=null;
const fmt=n=>Number(n).toLocaleString(), millis=n=>`${n.toFixed(1)} ms`;
function el(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function metric(label,value,detail){const d=el('div',undefined,'metric');d.append(el('small',label),el('strong',value));if(detail)d.append(el('small',detail));return d;}
function renderStats(results,elapsed){const s=statsCache??(statsCache=archiveStatistics(archives)), ss=searchStatistics(results,elapsed),target=$('archive-stats');target.replaceChildren(metric('Imported files',fmt(s.fileCount)),metric('Source characters',fmt(s.characters)),metric('Estimated words',fmt(s.words)),metric('UTF-8 text size',`${(s.bytes/1024/1024).toFixed(2)} MiB`),metric('Searchable records',fmt(s.records),`${fmt(s.parsedRecords)} detected messages`),metric('Unstructured files',fmt(s.unstructuredFiles),'No reliable message boundaries'));
 const list=$('file-stats');list.replaceChildren();for(const f of s.files){const row=el('div',undefined,'file-stat');row.append(el('strong',f.filename),el('small',`${fmt(f.characters)} characters · ${fmt(f.words)} words · ${fmt(f.records)} searchable record(s) · ${f.parseMethod}`));list.append(row)}if(!s.files.length)list.append(el('p','Import files to see statistics.','muted'));
 $('search-metrics').replaceChildren(metric('Total matches',fmt(ss.matches)),metric('Search duration',millis(ss.elapsedMs)),metric('Files with matches',fmt(ss.byArchive.size)));
 const dist=$('match-distribution');dist.replaceChildren();if((sceneMode?$('scene-clues').value:$('query').value).trim())for(const f of s.files){const count=ss.byArchive.get(f.id)||0,row=el('div',undefined,'distribution-row'),bar=el('div',undefined,'bar');bar.style.width=`${ss.matches?100*count/ss.matches:0}%`;row.append(el('span',`${f.filename}: ${fmt(count)}`),bar);dist.append(row)}
}
function showContext(wrap,r){
 const a=archives.find(a=>a.id===r.id);if(!a)return;
 const ctx=getContext(a,r.ordinal,r.offset,r.queryLength,600);if(!ctx)return;
 const evidence=r.kind==='bounded-characters'?sceneEvidenceContext(a,r,300):null;
 const panel=el('div',undefined,'context-panel');wrap.append(panel);
 let before=1,after=1,full=false,focusIndex=ctx.index;
 const displayText=t=>t.replace(/\\n/g,'\n').replace(/\\r/g,'\r').replace(/\\t/g,'\t'); // presentation only
 function draw(){
  panel.replaceChildren(el('strong',`Source: ${a.filename} · record ${r.ordinal+1} of ${a.messages.length} · character ${r.offset+1}`));
  panel.append(el('p',a.parseMethod==='unstructured'?'Unstructured source: displaying nearby characters without inventing message boundaries.':`Detected structure: ${a.parseMethod}. Source order is preserved.`,'muted'));
  if(r.clues?.length){
   const cards=sceneEvidenceCards(a,r,200),group=el('div',undefined,'evidence-group');
   group.append(el('h3',`Clue evidence · ${cards.length} verified source location(s)`));
   for(const card of cards){
    const item=el('div',undefined,'evidence-card');
    item.append(el('strong',`“${card.clue}” · ${card.speaker} · message ${card.message} · character ${fmt(card.offset+1)}${card.sourceOffset===null?'':` · source character ${fmt(card.sourceOffset+1)}`}`));
    const excerpt=el('pre');evidenceExcerpt(excerpt,{excerpt:card.excerpt,clues:[{clue:card.clue}]});item.append(excerpt);
    const copy=el('button','Copy this evidence');copy.addEventListener('click',()=>navigator.clipboard.writeText(`Source: ${card.filename}\nMessage: ${card.message}\nCharacter: ${card.offset+1}\nClue: ${card.clue}\n\n${card.excerpt}`).then(()=>{copy.textContent='Copied!';}).catch(()=>{copy.textContent='Select text to copy';}));
    item.append(copy);group.append(item);
   }
   panel.append(group);
  }
  const win=contextWindow(a,focusIndex,before,after);
  if(a.parseMethod==='unstructured'){
   panel.append(el('h3','Matching source passage'),el('pre',displayText(full?ctx.message.text:(evidence?.text??ctx.text))));
   if(!full)panel.append(el('small',`Excerpt characters ${fmt((evidence?.start??ctx.start)+1)}–${fmt(evidence?.end??ctx.end)} of ${fmt(ctx.message.text.length)}`));
  }else{
   for(let i=0;i<win.messages.length;i++){
    const m=win.messages[i],absolute=win.start+i,section=el('div',undefined,'message-card');
    section.append(el('strong',`${absolute===ctx.index?'★ Match · ':''}${m.speaker} · message ${absolute+1}${m.timestamp?' · '+m.timestamp:''}`));
    const text=absolute===ctx.index&&!full&&m.text.length>1600?ctx.text:m.text;
    section.append(el('pre',displayText(text)));panel.append(section);
   }
  }
  const actions=el('div',undefined,'actions');
  function button(label,fn,disabled=false){const b=el('button',label);b.disabled=disabled;b.addEventListener('click',fn);actions.append(b);}
  if(a.parseMethod!=='unstructured'){
   button('↑ 3 earlier messages',()=>{before+=3;draw()},win.start===0);
   button('↓ 3 later messages',()=>{after+=3;draw()},win.end===win.total);
   const jump=el('div',undefined,'jump-control'),label=el('label','Jump to message number');
   const input=el('input');input.type='number';input.min='1';input.max=String(a.messages.length);input.value=String(focusIndex+1);input.setAttribute('aria-label','Message number');
   const go=el('button','Go');const navigate=()=>{const n=Number(input.value);if(!Number.isInteger(n)||n<1||n>a.messages.length){input.setCustomValidity(`Enter 1–${a.messages.length}`);input.reportValidity();return;}input.setCustomValidity('');focusIndex=n-1;before=1;after=1;draw();};
   go.addEventListener('click',navigate);input.addEventListener('keydown',e=>{if(e.key==='Enter')navigate()});jump.append(label,input,go);panel.append(jump);
  }
  button('Add visible context to Nexus queue',async()=>{
    const selected=a.parseMethod==='unstructured'?(full?ctx.message.text:(evidence?.text??ctx.text)):win.messages.map((m,i)=>`[${m.speaker} · message ${win.start+i+1}]\\n${m.text}`).join('\\n\\n');
    const key=`${r.id}:${r.ordinal}:${r.offset}:visible:${win.start}:${win.end}:${full}`;
    if(queue.some(x=>x.key===key)){$('queue-status').textContent='This context is already queued.';return;}
    const item={key,filename:a.filename,sourceId:r.id,ordinal:r.ordinal,offset:r.offset,speaker:ctx.message.speaker,text:selected,
      extraContext:$('scene-extra-context').value.trim(),selectionStart:ctx.start,selectionEnd:ctx.end,createdAt:new Date().toISOString()};
    queue.push(item);
    try{await saveQueue();$('scene-extra-context').value='';$('queue-status').textContent='Visible context added to Nexus queue.'}
    catch(e){queue.pop();$('queue-status').textContent=`Could not save: ${e.message}`}
  });
  button('Copy visible context',()=>{const content=a.parseMethod==='unstructured'?(full?ctx.message.text:(evidence?.text??ctx.text)):win.messages.map((m,i)=>`[${m.speaker} · message ${win.start+i+1}]\n${m.text}`).join('\n\n');navigator.clipboard.writeText(`Source: ${a.filename}\n\n${content}`).then(()=>{const note=el('small','Copied to clipboard.');panel.append(note);setTimeout(()=>note.remove(),2000)}).catch(()=>{const note=el('small','Clipboard unavailable. Select text to copy.');panel.append(note)})});
  button(full?'Show compact match':'Show full matching message',()=>{full=!full;draw()});
  button('Close context',()=>panel.remove());panel.append(actions);
 }
 draw();
}
function evidenceExcerpt(pre,r){
 const content=r.excerpt;const terms=[...new Set((r.clues||[]).map(c=>c.clue))].filter(Boolean).sort((a,b)=>b.length-a.length);
 if(!terms.length){pre.textContent=content;return;}
 const lower=content.toLocaleLowerCase();let at=0;
 while(at<content.length){let pos=content.length,term='';for(const t of terms){const found=lower.indexOf(t,at);if(found>=0&&(found<pos||(found===pos&&t.length>term.length))){pos=found;term=t;}}
  if(!term){pre.append(document.createTextNode(content.slice(at)));break;}
  if(pos>at)pre.append(document.createTextNode(content.slice(at,pos)));
  const mark=el('mark',content.slice(pos,pos+term.length));pre.append(mark);at=pos+term.length;
 }
}
function renderPage(){
 const target=$('results');target.replaceChildren();const totalPages=Math.max(1,Math.ceil(searchResults.length/PAGE_SIZE));currentPage=Math.min(Math.max(currentPage,0),totalPages-1);
 const begin=currentPage*PAGE_SIZE;
 for(const r of searchResults.slice(begin,begin+PAGE_SIZE)){
  const wrap=el('div',undefined,'result');wrap.append(el('strong',`${r.filename} — ${r.speaker} (record ${r.ordinal+1}, character ${r.offset+1})`));if(r.clues)wrap.append(el('small',`Clues found: ${r.clues.map(c=>c.clue+' (message '+c.message+(Number.isInteger(c.offset)?', char '+(c.offset+1):'')+')').join(' · ')} · ${r.kind}${r.span?' · '+r.span+'-character span':''}`));const snippet=el('pre');evidenceExcerpt(snippet,r);wrap.append(snippet);
  const btn=el('button','Show surrounding context');btn.addEventListener('click',()=>{if(wrap.querySelector('.context-panel'))return;showContext(wrap,r)});wrap.append(btn);const pick=el('button','Add scene to Nexus queue');pick.addEventListener('click',()=>selectScene(r));wrap.append(pick);target.append(wrap);
 }
 const nav=$('result-navigation');nav.replaceChildren();if(searchResults.length>PAGE_SIZE){
  const prev=el('button','← Previous 50');prev.disabled=currentPage===0;prev.addEventListener('click',()=>{currentPage--;renderPage()});
  const next=el('button','Next 50 →');next.disabled=currentPage===totalPages-1;next.addEventListener('click',()=>{currentPage++;renderPage()});
  nav.append(prev,el('span',`Page ${fmt(currentPage+1)} of ${fmt(totalPages)} · results ${fmt(begin+1)}–${fmt(Math.min(begin+PAGE_SIZE,searchResults.length))} of ${fmt(searchResults.length)}`),next);
 }
}
function render(){const q=sceneMode?$('scene-clues').value:$('query').value,t0=performance.now();searchResults=sceneMode?findSceneEvidence(archives,q,{maxSpan:Number($('scene-span').value),wholeWords:$('whole-words').checked}):searchArchives(archives,q);searchElapsed=performance.now()-t0;currentPage=0;
 for(const r of searchResults)if(!r.queryLength)r.queryLength=q.trim().length;
 renderStats(searchResults,searchElapsed);
 $('stats').textContent=sceneMode?(parseClues(q).length<2?'Enter at least two distinct clues, separated by semicolons or new lines.':`${fmt(searchResults.length)} candidate source passages across ${fmt(new Set(searchResults.map(r=>r.id)).size)} file(s). Literal clue co-occurrence only; inspect context to verify scenes.`):(q.trim()?`${fmt(searchResults.length)} match(es) across ${fmt(new Set(searchResults.map(r=>r.id)).size)} file(s). Browse all matches in pages of ${PAGE_SIZE}.`:'Enter a phrase to search imported source content.');
 renderPage();
}
async function refresh(){archives=expandArchives(await all());statsCache=null;render()}
$('files').addEventListener('change',async e=>{let added=0,duplicates=0;try{for(const file of e.target.files){const text=await file.text();let items=null;
 try{const data=JSON.parse(text);if(data?.schema==='aurelius-archive-v1'&&Array.isArray(data.archives))items=data.archives}catch{}
 for(const item of items||[{filename:file.name,original:text}]){
  if(typeof item.original!=='string')continue;
  const id=await fingerprint(item.original);
  if((await all()).some(a=>a.id===id)){duplicates++;continue;}
  const a={...parseArchive(item.original,item.filename||file.name),id};
  await transact('readwrite',s=>s.put(a));added++;
 }}$('status').textContent=`Imported ${added} file(s); skipped ${duplicates} exact duplicate(s).`;await refresh();}catch(err){$('status').textContent=`Import failed: ${err.message}`;}e.target.value='';});
$('query').addEventListener('input',()=>{if(sceneMode)return;clearTimeout(searchTimer);searchTimer=setTimeout(render,180)});$('scene-clues').addEventListener('input',()=>{if(!sceneMode)return;clearTimeout(searchTimer);searchTimer=setTimeout(render,250)});$('scene-span').addEventListener('change',()=>{if(sceneMode)render()});$('whole-words').addEventListener('change',()=>{if(sceneMode)render()});$('search-mode').addEventListener('change',e=>{sceneMode=e.target.checked;$('scene-panel').hidden=!sceneMode;$('query').disabled=sceneMode;render()});
$('export').addEventListener('click',async()=>{const blob=new Blob([JSON.stringify({schema:'aurelius-archive-v1',exportedAt:new Date().toISOString(),archives:await all()},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='aurelius-conversation-archive.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
$('clear').addEventListener('click',async()=>{if(!confirm('Permanently delete all archives stored by this experiment in this browser?'))return;await transact('readwrite',s=>s.clear());await refresh();$('status').textContent='Local archive cleared.';});
refresh().catch(e=>{$('status').textContent=`Storage unavailable: ${e.message}`});

function renderQueue(){const target=$('queue-items');target.replaceChildren();$('queue-count').textContent=`${queue.length} selected scene(s) · ${fmt(queue.reduce((n,s)=>n+s.text.length,0))} characters`;for(const s of queue){const row=el('div',undefined,'file-stat');row.append(el('strong',s.filename),el('small',`Record ${s.ordinal+1} · character ${s.offset+1} · ${fmt(s.text.length)} characters`));const remove=el('button','Remove');remove.addEventListener('click',async()=>{queue=queue.filter(x=>x.key!==s.key);await saveQueue()});const notesLabel=el('label','Additional context (editable)');const notes=el('textarea');notes.rows=3;notes.value=s.extraContext||'';notes.placeholder='User-provided scene context or corrections';notes.addEventListener('change',async()=>{s.extraContext=notes.value;await saveQueue();$('queue-status').textContent='Additional context saved.'});row.append(notesLabel,notes,remove);target.append(row)}}
async function selectScene(r){
 const a=archives.find(a=>a.id===r.id);if(!a)return;
 const radius=$('scene-radius').value;
 const ctx=getContext(a,r.ordinal,r.offset,r.queryLength||1,radius==='full'?Number.MAX_SAFE_INTEGER:Number(radius));
 if(!ctx)return;
 const key=`${r.id}:${r.ordinal}:${r.offset}`;
 if(queue.some(x=>x.key===key)){$('queue-status').textContent='This occurrence is already selected.';return;}
 const evidence=r.kind==='bounded-characters'?sceneEvidenceContext(a,r,300):null;
 const text=evidence?.text??ctx.text;
 const selectionStart=evidence?.start??ctx.start,selectionEnd=evidence?.end??ctx.end;
 queue.push({key,filename:a.filename,sourceId:r.id,ordinal:r.ordinal,offset:r.offset,speaker:ctx.message.speaker,text,
  extraContext:$('scene-extra-context').value.trim(),selectionStart,selectionEnd,createdAt:new Date().toISOString()});
 try{await saveQueue();$('scene-extra-context').value='';$('queue-status').textContent='Scene queued for ChatGPT Nexus Drafting.'}
 catch(e){queue.pop();$('queue-status').textContent=`Could not save scene: ${e.message}`}
}

$('clear-queue').addEventListener('click',async()=>{if(!confirm('Clear selected scenes? Original archives remain untouched.'))return;queue=[];await saveQueue();$('queue-status').textContent='Scene queue cleared.'});
$('open-chatgpt').addEventListener('click',()=>chrome.tabs.create({url:'https://chatgpt.com/'}));
loadQueue().catch(e=>{$('queue-status').textContent=`Scene queue unavailable: ${e.message}`});
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes[QUEUE_KEY]){queue=changes[QUEUE_KEY].newValue||[];renderQueue()}});

$('download-excerpts').addEventListener('click',()=>{if(!queue.length){$('queue-status').textContent='Select at least one scene first.';return;}const result=AureliusEvidence.build(queue);AureliusEvidence.download('aurelius-selected-excerpts-clean.txt',result.content);$('queue-status').textContent=`Exported ${result.passages} merged evidence passage(s) from ${result.originalSelections} selections. Original archives unchanged.`;});
