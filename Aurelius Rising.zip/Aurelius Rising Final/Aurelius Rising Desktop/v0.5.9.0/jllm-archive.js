// Optional, local-only live JLLM capture. Only messages rendered by JanitorAI are saved.
(() => {
  if (window.__aureliusJllmArchiveLoaded) return;
  window.__aureliusJllmArchiveLoaded = true;
  const PREFIX='aureliusJllmChat:', SETTINGS_KEY='aureliusChatCaptureSettings', STATUS_KEY='aureliusChatCaptureStatus:jllm';
  const chatId=()=>location.pathname.match(/^\/chats\/([^/]+)/)?.[1]||null;
  let enabled=false,busy=false,again=false,lastRoute=null,collectTimer=0;
  const keyFor=id=>PREFIX+id;
  const getRows=()=>[...document.querySelectorAll('[data-index]')].flatMap(node=>{
    const index=Number(node.getAttribute('data-index'));
    if(!Number.isSafeInteger(index)||index<0)return[];
    const message=node.querySelector('li[class*="_messageDisplayWrapper_"]');
    if(!message)return[];
    const speaker=message.querySelector('[class*="_nameText_"]')?.textContent?.trim()||'Unknown';
    const body=message.querySelector('[class*="_messageBody_"]');if(!body)return[];
    const text=(body.querySelector('.css-mk84ka')||body).innerText?.trim()||'';
    return text?[{id:String(index),index,speaker,text}]:[];
  });
  async function setStatus(extra={}){
    const id=chatId();
    try{await chrome.storage.local.set({[STATUS_KEY]:{platform:'jllm',enabled,chatId:id,...extra,observedAt:new Date().toISOString()}});}catch(_){}
  }
  function scheduleCollect(){if(collectTimer)return;collectTimer=setTimeout(()=>{collectTimer=0;void collect();},800);}
  async function loadEnabled(){
    try{const value=(await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]||{};enabled=value.jllm===true;}catch(_){enabled=false;}
    const id=chatId();
    if(id!==lastRoute){lastRoute=id;}
    if(enabled&&id)void collect();
    else void setStatus({message:enabled?'Waiting for a JanitorAI chat.':'Live capture is off.'});
  }
  async function collect(){
    const id=chatId();if(!enabled||!id)return;
    if(busy){again=true;return;}
    busy=true;
    try{
      const rows=getRows();
      const k=keyFor(id),stored=(await chrome.storage.local.get(k))[k]||{platform:'jllm',chatId:id,source:'janitorai.com',createdAt:new Date().toISOString(),messages:{},checkpoints:[]};
      if(!stored.createdAt)stored.createdAt=new Date().toISOString();
      if(document.title)stored.title=document.title;
      if(!enabled||chatId()!==id)return;
      if(!stored.messages||typeof stored.messages!=='object')stored.messages={};
      if(!Array.isArray(stored.checkpoints))stored.checkpoints=[];
      const now=new Date().toISOString();let changed=false;
      for(const row of rows){
        const old=stored.messages[row.id];
        if(!old||old.speaker!==row.speaker||old.text!==row.text){
          stored.messages[row.id]={...row,firstCapturedAt:old?.firstCapturedAt||now,lastEditedAt:old&&old.text!==row.text?now:(old?.lastEditedAt||null)};
          changed=true;
        }
      }
      if(changed){stored.updatedAt=now;stored.lastCapturedAt=now;stored.lastIndex=Math.max(-1,...rows.map(row=>row.index));await chrome.storage.local.set({[k]:stored});}
      await setStatus({messageCount:Object.keys(stored.messages).length,lastCapturedAt:stored.lastCapturedAt||null,lastCheckpointAt:stored.checkpoints[stored.checkpoints.length-1]?.at||null,message:enabled?`Saving locally · ${Object.keys(stored.messages).length} message positions captured.`:'Live capture is off.'});
    }catch(error){console.warn('Aurelius JLLM capture failed:',error);enabled=false;await setStatus({message:'Capture paused after a storage error.'});}
    finally{busy=false;if(again){again=false;void collect();}}
  }
  async function checkpoint(){
    const id=chatId();if(!enabled||!id)return{ok:false};
    if(collectTimer){clearTimeout(collectTimer);collectTimer=0;}await collect();
    while(busy)await new Promise(resolve=>setTimeout(resolve,50));
    const k=keyFor(id),stored=(await chrome.storage.local.get(k))[k];if(!stored)return{ok:false};
    const at=new Date().toISOString();if(!Array.isArray(stored.checkpoints))stored.checkpoints=[];
    stored.checkpoints.push({at,messageCount:Object.keys(stored.messages||{}).length,throughIndex:Number.isSafeInteger(stored.lastIndex)?stored.lastIndex:null});
    stored.lastCheckpointAt=at;stored.updatedAt=at;await chrome.storage.local.set({[k]:stored});
    await setStatus({messageCount:Object.keys(stored.messages||{}).length,lastCapturedAt:stored.lastCapturedAt||null,lastCheckpointAt:at,message:'Timestamped JLLM checkpoint saved locally.'});
    return{ok:true,chatId:id,at};
  }
  const observer=new MutationObserver(()=>{
    const id=chatId();if(id!==lastRoute){lastRoute=id;void loadEnabled();}
    else if(enabled)scheduleCollect();
  });
  observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true});
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area==='local'&&changes[SETTINGS_KEY])void loadEnabled();
  });
  chrome.runtime.onMessage.addListener((message,_sender,reply)=>{
    if(message?.type==='AURELIUS_JLLM_CAPTURE_STATUS'){
      reply({capturing:enabled,chatId:chatId(),loaded:getRows().length});
    }else if(message?.type==='AURELIUS_JLLM_CAPTURE_SET'){
      void chrome.storage.local.get(SETTINGS_KEY).then(v=>{
        const settings={...(v[SETTINGS_KEY]||{}),jllm:!!message.enabled};
        return chrome.storage.local.set({[SETTINGS_KEY]:settings});
      }).then(()=>reply({capturing:!!message.enabled,chatId:chatId()})).catch(()=>reply({capturing:false,chatId:chatId()}));
      return true;
    }else if(message?.type==='AURELIUS_CHAT_CHECKPOINT'){
      void checkpoint().then(reply).catch(()=>reply({ok:false}));return true;
    }
  });
  void loadEnabled();
})();
