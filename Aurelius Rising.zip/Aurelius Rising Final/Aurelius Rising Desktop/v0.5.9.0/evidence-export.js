// Evidence export utilities: never mutate the saved selection queue or original archives.
(function(global){
// Non-destructive: preserve all characters of the selected source, including model reasoning.
// Source headings identify provenance; never guess where a reasoning block ends.
function preserveEvidence(s){
 const text=String(s||'');
 const thinkingHeaders=(text.match(/\bThinking Process\b/gi)||[]).length;
 const roleMarkers=(text.match(/\[(?:Bot|YOU|USER|Assistant)\]/gi)||[]).length;
 return {text,thinkingHeaders,roleMarkers};
}
// Compatibility alias: no longer removes anything.
function cleanThinking(s){const result=preserveEvidence(s);return {...result,removedBlocks:0,uncertain:0};}
function groups(queue){
 const bySource=new Map();
 for(const s of queue){const start=Number(s.selectionStart),end=Number(s.selectionEnd);const valid=Number.isFinite(start)&&Number.isFinite(end)&&end>start;
  const id=s.sourceId||s.filename;const key=id+'::'+(s.ordinal??0);if(!bySource.has(key))bySource.set(key,[]);
  bySource.get(key).push({...s,_start:valid?start:0,_end:valid?end:String(s.text||'').length});
 }
 const output=[];
 for(const records of bySource.values()){
  records.sort((a,b)=>a._start-b._start);
  let current=null;
  for(const s of records){if(current&&s._start<=current.end){
    const overlap=Math.max(0,current.end-s._start);
    // Extend using the actual overlapping excerpt, preserving exact original character spans.
    if(s._end>current.end){current.text+=String(s.text||'').slice(overlap);current.end=s._end;}
    current.selections.push(s);
  }else{if(current)output.push(current);current={filename:s.filename,ordinal:s.ordinal,start:s._start,end:s._end,text:String(s.text||''),selections:[s]};}}
  if(current)output.push(current);
 }
 return output.sort((a,b)=>a.filename.localeCompare(b.filename)||a.start-b.start);
}
function build(queue){
 const merged=groups(queue);let thinkingHeaders=0;
 const content=merged.map((g,i)=>{
  const evidence=preserveEvidence(g.text);thinkingHeaders+=evidence.thinkingHeaders;
  const notes=[...new Set(g.selections.map(s=>(s.extraContext||'').trim()).filter(Boolean))];
  const kind=evidence.thinkingHeaders?'MIXED SOURCE: STORY TEXT + MODEL THINKING':'SOURCE EXCERPT (STORY / CONTEXT; CHECK BOUNDARIES)';
  return `[Evidence passage ${i+1}]\nSource: ${g.filename} | record ${Number(g.ordinal)+1} | original character range ${g.start+1}–${g.end}\nMerged from ${g.selections.length} selection(s)\n--- ${kind} (VERBATIM; NOTHING REMOVED) ---\n${evidence.text}\n--- END SOURCE EXCERPT ---${notes.length?'\n--- USER-SUPPLIED CONTEXT (not transcript) ---\n'+notes.join('\n\n')+'\n--- END USER CONTEXT ---':''}`;
 }).join('\n\n');
 return {content,passages:merged.length,thinkingHeaders,removed:0,uncertain:0,originalSelections:queue.length};
}
function download(name,content){const url=URL.createObjectURL(new Blob([content],{type:'text/plain;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);}
global.AureliusEvidence={build,download,cleanThinking,preserveEvidence,groups};
})(globalThis);
