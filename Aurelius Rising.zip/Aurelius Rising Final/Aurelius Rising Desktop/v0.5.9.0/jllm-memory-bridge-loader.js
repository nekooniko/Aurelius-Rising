// Loads the JLLM request adapter into the page's main JavaScript world.
(() => {
  'use strict';
  if (window.__aureliusJllmMemoryBridgeRequested) return;
  window.__aureliusJllmMemoryBridgeRequested = true;
  const inject = () => {
    const parent = document.head || document.documentElement;
    if (!parent) return false;
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('jllm-memory-bridge.js');
    script.onload = () => script.remove();
    script.onerror = () => script.remove();
    parent.appendChild(script);
    return true;
  };
  if (!inject()) document.addEventListener('DOMContentLoaded',inject,{once:true});
})();
