// Optional, local-only live capture for DreamJourney AI sessions.
// The selectors mirror Aster's observed chat container and message IDs.
(() => {
  'use strict';
  if(window.__aureliusDjaiCaptureLoaded)return;
  window.__aureliusDjaiCaptureLoaded=true;
  const PREFIX='aureliusDjaiChat:',SETTINGS_KEY='aureliusChatCaptureSettings',STATUS_KEY='aureliusChatCaptureStatus:djai';
  const sessionId=()=>location.pathname.match(/\/app\/session\/([^/?#]+)/)?.[1]||null;
  let enabled=false,busy=false,again=false,lastRoute=null,collectTimer=0;
  const archiveKey=id=>PREFIX+id;
  const rows=()=>{
    const container=document.querySelector('.scrollchatmessages');if(!container)return[];
    const botMessageIds=new Set([...container.querySelectorAll('img[alt="@shadcn"]')]
      .map(image=>image.closest('[id^="message-"]')?.id).filter(Boolean));
    const byMessageId=new Map();
    [...container.querySelectorAll('[id^="message-"]')].forEach((el,index)=>{
      const id=el.id;if(!id)return null;
      const text=(el.querySelector('.markdown')||el).innerText?.trim()||'';if(!text)return null;
      const bot=botMessageIds.has(id)||!!el.querySelector('img[alt="@shadcn"]');
      const numeric=id.match(/^message-(\d+)$/)?.[1];
      const row={id,index:Number.isSafeInteger(Number(numeric))?Number(numeric):index,speaker:bot?'Assistant':'User',text};
      const previous=byMessageId.get(id);
      // DJAI repeats each message ID on a nested wrapper. Keep one row and
      // prefer the outer wrapper when it exposes the bot avatar.
      if(!previous||(bot&&previous.speaker!=='Assistant'))byMessageId.set(id,row);
    });
    return [...byMessageId.values()];
  };
  async function setStatus(extra={}){
    try{await chrome.storage.local.set({[STATUS_KEY]:{platform:'djai',enabled,chatId:sessionId(),...extra,observedAt:new Date().toISOString()}});}catch(_){}
  }
  function scheduleCollect(){if(collectTimer)return;collectTimer=setTimeout(()=>{collectTimer=0;void collect();},800);}
  async function loadEnabled(){
    try{const value=(await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY]||{};enabled=value.djai===true;}catch(_){enabled=false;}
    const id=sessionId();if(id!==lastRoute)lastRoute=id;
    if(enabled&&id)void collect();
    else void setStatus({message:enabled?'Waiting for a DreamJourney AI session.':'Live capture is off.'});
  }
  async function collect(){
    const id=sessionId();if(!enabled||!id)return;
    if(busy){again=true;return;}
    busy=true;
    try{
      const current=rows(),k=archiveKey(id);
      const stored=(await chrome.storage.local.get(k))[k]||{platform:'djai',chatId:id,source:'dreamjourneyai.com',createdAt:new Date().toISOString(),messages:{},checkpoints:[]};
      if(!stored.createdAt)stored.createdAt=new Date().toISOString();
      if(document.title)stored.title=document.title;
      if(!enabled||sessionId()!==id)return;
      if(!stored.messages||typeof stored.messages!=='object')stored.messages={};
      if(!Array.isArray(stored.checkpoints))stored.checkpoints=[];
      const now=new Date().toISOString();let changed=false;
      for(const row of current){
        const old=stored.messages[row.id];
        if(!old||old.speaker!==row.speaker||old.text!==row.text){
          stored.messages[row.id]={...row,firstCapturedAt:old?.firstCapturedAt||now,lastEditedAt:old&&old.text!==row.text?now:(old?.lastEditedAt||null)};
          changed=true;
        }
      }
      if(changed){stored.updatedAt=now;stored.lastCapturedAt=now;stored.lastIndex=Math.max(-1,...current.map(row=>row.index));await chrome.storage.local.set({[k]:stored});}
      await setStatus({messageCount:Object.keys(stored.messages).length,lastCapturedAt:stored.lastCapturedAt||null,lastCheckpointAt:stored.checkpoints[stored.checkpoints.length-1]?.at||null,message:enabled?`Saving locally · ${Object.keys(stored.messages).length} messages captured.`:'Live capture is off.'});
    }catch(error){console.warn('Aurelius DreamJourney AI capture failed:',error);enabled=false;await setStatus({message:'Capture paused after a storage error.'});}
    finally{busy=false;if(again){again=false;void collect();}}
  }
  async function checkpoint(){
    const id=sessionId();if(!enabled||!id)return{ok:false};
    if(collectTimer){clearTimeout(collectTimer);collectTimer=0;}await collect();
    while(busy)await new Promise(resolve=>setTimeout(resolve,50));
    const k=archiveKey(id),stored=(await chrome.storage.local.get(k))[k];if(!stored)return{ok:false};
    const at=new Date().toISOString();if(!Array.isArray(stored.checkpoints))stored.checkpoints=[];
    stored.checkpoints.push({at,messageCount:Object.keys(stored.messages||{}).length,throughIndex:Number.isSafeInteger(stored.lastIndex)?stored.lastIndex:null});
    stored.lastCheckpointAt=at;stored.updatedAt=at;await chrome.storage.local.set({[k]:stored});
    await setStatus({messageCount:Object.keys(stored.messages||{}).length,lastCapturedAt:stored.lastCapturedAt||null,lastCheckpointAt:at,message:'Timestamped DreamJourney AI checkpoint saved locally.'});
    return{ok:true,chatId:id,at};
  }
  const observer=new MutationObserver(()=>{
    const id=sessionId();if(id!==lastRoute){lastRoute=id;void loadEnabled();}
    else if(enabled)scheduleCollect();
  });
  observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true});
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes[SETTINGS_KEY])void loadEnabled();});
  chrome.runtime.onMessage.addListener((message,_sender,reply)=>{
    if(message?.type==='AURELIUS_CHAT_CHECKPOINT'){void checkpoint().then(reply).catch(()=>reply({ok:false}));return true;}
    if(message?.type==='AURELIUS_DJAI_CAPTURE_STATUS'){reply({capturing:enabled,chatId:sessionId(),loaded:rows().length});}
  });
  void loadEnabled();
})();
