// Aurelius Rising DJAI bridge: extension messaging without popup script injection.
(() => {
  'use strict';
  const CHANNEL = 'aurelius-djai-054';
  const INTERVAL_KEY = 'aureliusDjaiInjectionReminderInterval';
  const bridgeInstanceId = (crypto.randomUUID && crypto.randomUUID()) || ('ar-tab-'+Date.now()+'-'+Math.random().toString(36).slice(2));
  const RELAY_COMMAND_PREFIX = 'aureliusDjaiRelayCommand:';
  const sessionId = () => location.pathname.match(/^\/app\/session\/([^/]+)/)?.[1];
  const reminderStates = new Map();
  let reminderInterval = 0;
  let renderReminder = () => {};
  let pendingRerollUntil = 0;

  function reminderState(session) {
    if (!reminderStates.has(session)) {
      let state = {count: 0, dismissedAt: 0};
      try {
        const saved = JSON.parse(sessionStorage.getItem('arInjectionReminder:' + session));
        if (saved && Number.isSafeInteger(saved.count) && Number.isSafeInteger(saved.dismissedAt)) state = saved;
      } catch (_) {}
      reminderStates.set(session, state);
    }
    return reminderStates.get(session);
  }

  function saveReminderState(session, state) {
    reminderStates.set(session, state);
    try { sessionStorage.setItem('arInjectionReminder:' + session, JSON.stringify(state)); }
    catch (_) {}
    renderReminder();
  }

  function setReminderInterval(value) {
    reminderInterval = Number.isInteger(value) && value >= 10 && value <= 20 ? value : 0;
    renderReminder();
  }
  chrome.storage.local.get(INTERVAL_KEY).then(value => setReminderInterval(value[INTERVAL_KEY])).catch(() => {});
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[INTERVAL_KEY]) setReminderInterval(changes[INTERVAL_KEY].newValue);
  });

  let serial = 0;
  const callbacks = new Map();
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('djai-page-bridge.js');
  script.onload = () => script.remove();
  script.onerror = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== location.origin || event.data?.channel !== CHANNEL) return;
    if (event.data.kind === 'chat-completed') {
      if (reminderInterval && typeof event.data.session === 'string') {
        const {session, injected} = event.data;
        const state = reminderState(session);
        saveReminderState(session, injected ? {count: 0, dismissedAt: 0} : {...state, count: state.count + 1});
      }
      const reroll = Date.now() < pendingRerollUntil;
      pendingRerollUntil = 0;
      if (window.AureliusAnalytics) void window.AureliusAnalytics.generation('djai', {reroll, assisted: event.data.injected === true});
      return;
    }
    if (event.data.kind !== 'reply') return;
    const cb = callbacks.get(event.data.id);
    if (cb) { callbacks.delete(event.data.id); cb(event.data); }
  });
  document.addEventListener('click', event => {
    const button = event.target?.closest?.('button,[role="button"]');
    if (!button) return;
    const label = `${button.getAttribute('aria-label') || ''} ${button.getAttribute('data-testid') || ''} ${button.getAttribute('title') || ''}`;
    if (/regenerat|retry|try again/i.test(label)) pendingRerollUntil = Date.now() + 120000;
  }, true);
  function quickCommand(action,text,limit,session){
    return new Promise(resolve => {
      const id=++serial;
      const timeout=setTimeout(()=>{callbacks.delete(id);resolve({ok:false,status:'Bridge did not respond; reload DJAI.'});},action==='import-nexus'?20000:2500);
      callbacks.set(id,result=>{clearTimeout(timeout);resolve(result);});
      window.postMessage({channel:CHANNEL,kind:'command',id,action,text,limit,session},location.origin);
    });
  }
  function mountStar(){
    if(document.getElementById('ar-floating-root') || !location.pathname.startsWith('/app/session/')) return;
    const host=document.createElement('div');host.id='ar-floating-root';
    host.style.cssText='position:fixed;right:14px;bottom:110px;z-index:2147483646;pointer-events:none';
    const root=host.attachShadow({mode:'open'});
    root.innerHTML=`<style>
      *{box-sizing:border-box}
      .star{pointer-events:auto;border:0;border-radius:0;width:52px;height:52px;background:transparent;padding:0;box-shadow:none;touch-action:none;opacity:.65;display:flex;align-items:center;justify-content:center;cursor:pointer}
      .star img{width:100%;height:100%;object-fit:contain;image-rendering:pixelated;pointer-events:none}
      .star.open,.star:active{opacity:1}.star:focus-visible{outline:2px solid #fff}
      .panel{pointer-events:auto;position:absolute;bottom:62px;right:0;width:min(380px,calc(100vw - 20px));height:min(70dvh,640px);max-height:calc(100dvh - 90px);overflow:hidden;background:#24212e;color:white;border:1px solid #9b7aa9;border-radius:14px;box-shadow:0 8px 35px #0009;display:flex;flex-direction:column}
      .panel[hidden]{display:none}.bar{display:flex;justify-content:space-between;align-items:center;padding:9px 12px;background:#292332;font:700 14px system-ui;color:#ffa4dd;flex:none}
      .close{background:transparent;border:0;color:white;font-size:24px;cursor:pointer;line-height:1}
      .injection-reminder{position:fixed;inset:12px 12px auto auto;width:min(320px,calc(100vw - 24px));z-index:3;pointer-events:auto;padding:12px;border:1px solid #d78ac1;border-radius:12px;background:#211925;color:#fff;font:14px/1.45 system-ui;box-shadow:0 8px 32px #0009}
      .injection-reminder p{margin:4px 0 8px}
      .injection-reminder button{border:1px solid #d78ac1;border-radius:8px;padding:6px 10px;margin:0 6px 0 0;background:#432c43;color:#fff;font:inherit;cursor:pointer}
      iframe{width:100%;height:100%;min-height:0;flex:1;border:0;background:#24212e}
    </style><section class="panel" hidden><div class="bar"><span>Aurelius Rising · DreamJourney AI</span><button class="close" aria-label="Close panel">×</button></div><iframe title="Aurelius Rising DreamJourney AI tools" loading="lazy"></iframe></section><button class="star" aria-label="Open Aurelius Rising DreamJourney AI tools" aria-expanded="false" title="Aurelius Rising"><img alt="" src="${chrome.runtime.getURL('assets/aurelius-rising-icon.png')}"></button><section class="injection-reminder" hidden aria-label="Scene injection reminder"><strong style="display:flex;align-items:center;gap:8px"><img src="${chrome.runtime.getURL('assets/notification alert.png')}" alt="" width="32" height="32">Scene injection reminder</strong><p role="status"></p><button class="review-injection" type="button">Review scene context</button><button class="dismiss-injection" type="button">Dismiss</button></section>`;
    document.documentElement.append(host);
    const star=root.querySelector('.star'),panel=root.querySelector('.panel'),frame=root.querySelector('iframe');
    // Requests from our own embedded extension popup, authenticated by frame and origin.
    const extensionOrigin=new URL(chrome.runtime.getURL('djai-floating.html')).origin;
    window.addEventListener('message',async event=>{
      const data=event.data;
      if(event.source!==frame.contentWindow || (event.origin!==extensionOrigin && event.origin!=='null') ||
         data?.channel!=='aurelius-floating-0571' || data.kind!=='command')return;
      if(!['arm','check','cancel','import-nexus'].includes(data.action) || typeof data.id!=='string')return;
      let result;
      try {result=await quickCommand(data.action,data.text,data.limit);}
      catch(err){result={ok:false,status:String(err.message||err)};}
      event.source.postMessage({channel:'aurelius-floating-0571',kind:'reply',id:data.id,result},event.origin==='null'?'*':extensionOrigin);
    });
    chrome.storage.local.get(['arStarPosition']).then(v=>{
      if(v.arStarPosition){host.style.right=v.arStarPosition.right+'px';host.style.bottom=v.arStarPosition.bottom+'px';}
    }).catch(()=>{});
    let down=null,suppress=false;
    star.addEventListener('pointerdown',e=>{down={x:e.clientX,y:e.clientY,right:parseFloat(host.style.right),bottom:parseFloat(host.style.bottom),moved:false};star.setPointerCapture(e.pointerId);});
    star.addEventListener('pointermove',e=>{if(!down)return;const dx=e.clientX-down.x,dy=e.clientY-down.y;if(Math.abs(dx)+Math.abs(dy)>8)down.moved=true;if(!down.moved)return;host.style.right=Math.max(0,Math.min(innerWidth-52,down.right-dx))+'px';host.style.bottom=Math.max(0,Math.min(innerHeight-52,down.bottom-dy))+'px';});
    star.addEventListener('pointerup',()=>{if(down?.moved){suppress=true;chrome.storage.local.set({arStarPosition:{right:parseFloat(host.style.right),bottom:parseFloat(host.style.bottom)}}).catch(()=>{});}down=null;});
    function setPanelOpen(open, review = false) {
      panel.hidden = !open;
      if (open && (!frame.src || review)) {
        const params = new URLSearchParams({session: sessionId() || 'unscoped',bridge:bridgeInstanceId}); if (review) params.set('review','scene');
        frame.src = chrome.runtime.getURL('djai-floating.html') + '?' + params.toString() + '#djai-floating';
      }
      star.classList.toggle('open', open);
      star.setAttribute('aria-expanded', String(open));
    }
    star.addEventListener('click',()=>{if(suppress){suppress=false;return;}setPanelOpen(panel.hidden);});
    root.querySelector('.close').addEventListener('click',()=>setPanelOpen(false));

    const reminder = root.querySelector('.injection-reminder');
    const copy = reminder.querySelector('p');
    renderReminder = () => {
      const session = sessionId();
      const state = session && reminderInterval ? reminderState(session) : null;
      const due = state && state.count - state.dismissedAt >= reminderInterval;
      reminder.hidden = !due;
      const message = due ? `It's been ${state.count - state.dismissedAt} messages. Choose the Nexus facts and instructions this scene needs, then arm your next message.` : '';
      if (copy.textContent !== message) copy.textContent = message;
    };
    function dismissReminder() {
      const session = sessionId();
      if (!session) return;
      const state = reminderState(session);
      saveReminderState(session, {...state, dismissedAt: state.count});
    }
    reminder.querySelector('.dismiss-injection').addEventListener('click', dismissReminder);
    reminder.querySelector('.review-injection').addEventListener('click', () => {
      dismissReminder();
      setPanelOpen(true, true);
    });
    renderReminder();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mountStar,{once:true});else mountStar();
  // DJAI can switch sessions without reloading the page.
  let lastPath = location.pathname;
  new MutationObserver(() => {
    if (lastPath === location.pathname) return;
    lastPath = location.pathname;
    mountStar();
    const host=document.getElementById('ar-floating-root');
    const root=host?.shadowRoot, panel=root?.querySelector('.panel'), frame=root?.querySelector('iframe');
    if(panel && !panel.hidden && frame){const params=new URLSearchParams({session:sessionId()||'unscoped',bridge:bridgeInstanceId});frame.src=chrome.runtime.getURL('djai-floating.html')+'?'+params.toString()+'#djai-floating';}
    renderReminder();
  }).observe(document.documentElement, {childList: true, subtree: true});
  // Relay commands from our own extension iframe through shared extension storage.
  // This avoids mobile browsers' inconsistent cross-frame messaging behavior.
  const handledRelayIds=new Set();
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local')return;
    for(const [key,change] of Object.entries(changes)){
      if(!key.startsWith(RELAY_COMMAND_PREFIX))continue;
      const cmd=change.newValue;
      if(!cmd || typeof cmd.id!=='string' || handledRelayIds.has(cmd.id) || cmd.bridge!==bridgeInstanceId || cmd.session!==sessionId() || !['arm','check','cancel','import-nexus'].includes(cmd.action))continue;
      handledRelayIds.add(cmd.id);
      if(handledRelayIds.size>100)handledRelayIds.clear();
      const resultKey='aureliusDjaiRelayResult:'+cmd.id;
      quickCommand(cmd.action,cmd.text,cmd.limit,cmd.session)
        .then(result=>chrome.storage.local.set({[resultKey]:{id:cmd.id,result}}))
        .catch(error=>chrome.storage.local.set({[resultKey]:{id:cmd.id,result:{ok:false,status:String(error.message||error)}}}))
        .finally(()=>chrome.storage.local.remove(key).catch(()=>{}));
    }
  });
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type !== 'aurelius-djai-command') return;
    const id = ++serial;
    const timeout = setTimeout(() => {
      if (callbacks.has(id)) { callbacks.delete(id); sendResponse({ok:false,status:'Page bridge did not respond. Reload DJAI and retry.'}); }
    }, msg.action === 'import-nexus' ? 20000 : 2500);
    callbacks.set(id, result => { clearTimeout(timeout); sendResponse(result); });
    window.postMessage({channel:CHANNEL,kind:'command',id,action:msg.action,text:msg.text,limit:msg.limit,session:msg.session},location.origin);
    return true;
  });
})();
