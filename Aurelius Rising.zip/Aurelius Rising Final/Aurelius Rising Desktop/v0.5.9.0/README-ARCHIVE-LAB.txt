Aurelius Rising v0.5.8.0 — Archive Lab / ChatGPT Nexus Drafting

INSTALL
1. Unzip and load this folder as an unpacked Chrome extension (or replace the existing extension folder).
2. Open the Aurelius Rising popup > ChatGPT > Archive Lab · Nexus Drafting > Open Aurelius Archive Lab.
3. Import TXT/JSON transcript exports, or the previous Aurelius archive-v1 JSON backup.
4. Search, select matching passages with adjustable context, and switch to ChatGPT.
5. In the ChatGPT popup, preview the payload and click Insert selected scenes into ChatGPT draft. Review, then send manually.
6. Review ChatGPT's proposed Nexus nodes and manually enter only approved nodes.

IMPORTANT STORAGE MIGRATION
The old standalone localhost:8765 Archive Lab IndexedDB is not accessible to an extension page because browser origins differ. In the old Archive Lab, click Download archive JSON, then import that file in the new extension Archive Lab. This version intentionally preserves old archive records rather than attempting silent migration.

Scene queue: chrome.storage.local, persists across tabs and reloads. Original transcripts: extension-origin IndexedDB. Both remain local. No automatic submission or automatic canon editing. Optional local chat capture is a separate opt-in setting; disable it in the DJAI or JLLM popup to stop collecting new messages. Clear queues and archives explicitly.

Selected text may be very large. If the composer rejects a long payload, select shorter context or fewer scenes. The ChatGPT site may change its editor behavior.

Character Development instructions prohibit anti-romance and anti-growth soft locks and require evidence-based, positive descriptions. They are bundled into every Nexus drafting payload, not an optional module.

Existing v0.5.7.6 DJAI and behavior features remain included. No live browser compatibility test has been performed on this build.


v0.5.8.2 — Restored user-supplied additional context: enter notes before selecting a scene, or edit notes on queued scenes. Notes persist with the scene in extension storage and are clearly labeled separately from original transcript evidence in ChatGPT drafting payloads.

v0.5.8.3 — Restored the ORIGINAL Archive Lab v0.2.0 Evidence Navigator:
scene clues, exact evidence cards, paginated search, conservative TXT message parsing,
jump-to-message, expanding earlier/later messages, copy visible context.
New: Add visible context to Nexus queue, preserving user-added notes and ChatGPT handoff.
Existing queue storage key is unchanged. The original Archive Lab v0.2.0 source was used,
not a simplified reimplementation.


v0.5.8.4 — ChatGPT composer crash mitigation. Blocks single-operation insertion of archive payloads above 6,000 characters in both popup and content script; adds full-payload copy button. Does not truncate, delete, or alter stored scenes. Large payloads should be transferred in smaller portions. This is a safety limit, not a verified fix for all crashes.
