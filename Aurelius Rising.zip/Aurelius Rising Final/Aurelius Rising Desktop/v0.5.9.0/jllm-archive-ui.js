// Local-only DreamJourney AI and JLLM archive browser.
(() => {
  const prefixes=[['aureliusJllmChat:','jllm'],['aureliusDjaiChat:','djai']];
  const $=id=>document.getElementById(id);
  const status=$('jllm-archive-status'), chats=$('jllm-archive-chats'), results=$('jllm-archive-results');
  let selected=null;
  const formatTime=value=>value?new Date(value).toLocaleString():'unknown';
  const rows=chat=>Object.values(chat?.messages||{}).sort((a,b)=>(a.index??0)-(b.index??0)||String(a.firstCapturedAt||'').localeCompare(String(b.firstCapturedAt||'')));
  async function getChats(){
    const all=await chrome.storage.local.get(null);
    return Object.entries(all).flatMap(([key,data])=>{
      const match=prefixes.find(([prefix])=>key.startsWith(prefix));
      return match&&data?.messages&&typeof data.messages==='object'?[{key,data,platform:data.platform||match[1]}]:[];
    }).sort((a,b)=>(b.data.updatedAt||'').localeCompare(a.data.updatedAt||''));
  }
  function make(tag,text){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;}
  function download(name,data){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=make('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
  async function refresh(){
    const all=await getChats();chats.replaceChildren();
    if(!all.length){chats.append(make('p','No live-captured conversations saved yet. Turn on a platform toggle and open a chat.'));results.replaceChildren();selected=null;return;}
    if(!all.some(x=>x.key===selected))selected=all[0].key;
    for(const {key,data} of all){
      const line=make('div');line.className='file-stat';
      const service=data.platform==='djai'?'DreamJourney AI':'JanitorAI';
      const btn=make('button',`${key===selected?'● ':'○ '}${service} · ${data.title||'Chat'} · ${data.chatId} · ${rows(data).length} saved messages`);
      btn.addEventListener('click',()=>{selected=key;void refresh()});
      const checkpointCount=Array.isArray(data.checkpoints)?data.checkpoints.length:0;
      line.append(btn,make('small',`Saved through ${formatTime(data.lastCapturedAt||data.updatedAt)} · ${rows(data).length} captured positions · ${checkpointCount} checkpoint(s)`));chats.append(line);
    }
    const current=all.find(x=>x.key===selected);
    render(current.data);
  }
  function render(data){
    const query=$('jllm-archive-query').value.toLocaleLowerCase().trim();
    const messages=rows(data),matches=messages.filter(m=>!query||m.text.toLocaleLowerCase().includes(query)||m.speaker.toLocaleLowerCase().includes(query));
    results.replaceChildren(make('p',`${messages.length} saved message(s) · ${matches.length} match(es). Gaps in position numbers mean those messages have not been captured.`));
    if(Array.isArray(data.checkpoints)&&data.checkpoints.length){
      const times=data.checkpoints.map(point=>formatTime(point.at)).join(' · ');
      results.prepend(make('small',`Timestamped checkpoints: ${times}`));
    }
    for(const m of matches.slice(0,150)){
      const card=make('div');card.className='message-card';
      card.append(make('strong',`Position ${m.index+1} · ${m.speaker}`),make('pre',m.text));results.append(card);
    }
    if(matches.length>150)results.append(make('p',`Showing the first 150 matches of ${matches.length}. Narrow your search to see others.`));
  }
  $('jllm-archive-query').addEventListener('input',()=>{void refresh()});
  $('jllm-archive-refresh').addEventListener('click',()=>{void refresh()});
  $('jllm-archive-export').addEventListener('click',async()=>{
    const item=(await getChats()).find(x=>x.key===selected);
    if(!item){status.textContent='No chat selected.';return;}
    const service=item.platform==='djai'?'DreamJourney AI':'JanitorAI';
    download(`aurelius-${item.platform}-chat-${item.data.chatId}.json`,{source:'Aurelius Rising local live capture',platform:item.platform,service,chatId:item.data.chatId,createdAt:item.data.createdAt,updatedAt:item.data.updatedAt,lastCapturedAt:item.data.lastCapturedAt,checkpoints:item.data.checkpoints||[],messages:rows(item.data)});
    status.textContent='Selected conversation JSON downloaded.';
  });
  $('jllm-archive-export-all').addEventListener('click',async()=>{
    const all=await getChats();if(!all.length){status.textContent='Nothing to export.';return;}
    download('aurelius-live-conversation-archives.json',{source:'Aurelius Rising local live capture',chats:all.map(x=>({...x.data,messages:rows(x.data)}))});
    status.textContent='All local conversation archives downloaded.';
  });
  $('jllm-archive-delete').addEventListener('click',async()=>{
    if(!selected)return;
    if(!confirm('Delete this locally saved conversation? This cannot be undone.'))return;
    await chrome.storage.local.remove(selected);selected=null;status.textContent='Selected conversation archive deleted.';await refresh();
  });
  void refresh().catch(e=>{status.textContent='Unable to read JLLM archive: '+e.message});
})();
