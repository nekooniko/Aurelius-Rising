(() => {
  'use strict';
  const button = document.getElementById('floating-save-checkpoint');
  const status = document.getElementById('floating-checkpoint-status');
  if (!button || !status) return;
  button.addEventListener('click', async () => {
    button.disabled = true;
    button.textContent = 'Saving…';
    status.textContent = '';
    try {
      const result = await chrome.runtime.sendMessage({type: 'AURELIUS_CAPTURE_SAVE_CHECKPOINT'});
      if (result?.ok) {
        button.textContent = 'Save checkpoint now';
        status.textContent = 'Checkpoint saved locally.';
      } else {
        button.textContent = 'Save checkpoint now';
        status.textContent = 'Could not save. Turn on local capture and keep an open DJAI chat active.';
      }
    } catch (_) {
      button.textContent = 'Save checkpoint now';
      status.textContent = 'Could not reach the capture service. Reload the DJAI tab and try again.';
    } finally {
      button.disabled = false;
    }
  });
})();
