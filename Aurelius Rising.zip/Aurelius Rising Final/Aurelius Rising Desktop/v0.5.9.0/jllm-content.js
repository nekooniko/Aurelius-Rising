// Read-only JLLM adapter. Does not intercept requests or modify conversation content.
(() => {
  if (window.__aureliusJllmCounterLoaded) return;
  window.__aureliusJllmCounterLoaded = true;
  const INDEX_SELECTOR = '[data-index]';
  const MESSAGE_SELECTOR = 'li[class*="_messageDisplayWrapper_"]';
  let observedMax = -1;
  let observedChat = location.pathname;
  function snapshot() {
    if (location.pathname !== observedChat) { observedChat = location.pathname; observedMax = -1; }
    const entries = [...document.querySelectorAll(INDEX_SELECTOR)]
      .filter(el => el.querySelector(MESSAGE_SELECTOR))
      .map(el => Number(el.getAttribute('data-index')))
      .filter(Number.isInteger);
    if (entries.length) observedMax = Math.max(observedMax, ...entries);
    return {
      supported: /^\/chats\/[^/]+/.test(location.pathname),
      loadedMessages: entries.length,
      firstLoadedIndex: entries.length ? Math.min(...entries) : null,
      lastLoadedIndex: entries.length ? Math.max(...entries) : null,
      highestObservedIndex: observedMax >= 0 ? observedMax : null,
      observedPositionCount: observedMax >= 0 ? observedMax + 1 : null,
      composerDetected: !!document.querySelector('[data-chat-composer="true"] textarea'),
      virtualizedListDetected: !!document.querySelector('#virtuoso-head-marker'),
      note: 'Indices describe positions, not verified total messages. Older messages may not be mounted in the DOM.'
    };
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'AURELIUS_JLLM_SNAPSHOT') { sendResponse(snapshot()); }
  });
  // Track observed indices during scroll; never retain message text.
  let pending = false;
  const observer = new MutationObserver(() => {
    if (pending) return;
    pending = true;
    requestAnimationFrame(() => { pending = false; snapshot(); });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  snapshot();
})();
