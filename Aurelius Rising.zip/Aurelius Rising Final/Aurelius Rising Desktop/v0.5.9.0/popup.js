const $=s=>document.querySelector(s);
const instructionField=$('#instruction'),intervalField=$('#interval'),statusField=$('#status'),autoInjectionField=$('#auto-injection'),autoSendField=$('#auto-send');
let moduleStates={},selectedId='intent',expandedId=null;
$('#module-editor').hidden=true;$('#module-editor').style.display='none';
const defaults=()=>Object.fromEntries(AURELIUS_MODULES.map(m=>[m.id,{enabled:false,mode:m.mode,interval:m.interval,instruction:m.instruction,reason:m.reason,example:m.example,includeContext:true}]));
function selected(){return moduleStates[selectedId]}
function renderButtons(){
 const grid=$('#module-buttons'),editor=$('#module-editor');
 // Detach the live editor before replacing tiles so its contents are not destroyed.
 editor.remove();grid.replaceChildren();
 for(const mod of AURELIUS_MODULES){
  if(mod.id==='research')continue;
  const tile=document.createElement('div');tile.className='module-tile'+(expandedId===mod.id?' expanded':'');
  const heading=document.createElement('div');heading.className='module-heading';
  const name=document.createElement('span');name.className='module-name';name.textContent=mod.name;
  const star=document.createElement('button');star.type='button';star.className='star-toggle';
  const isExpanded=expandedId===mod.id;
  star.setAttribute('aria-label',(isExpanded?'Collapse ':'Expand ')+mod.name);
  star.setAttribute('aria-expanded',String(isExpanded));
  star.setAttribute('aria-controls','module-editor');
  const starImg=document.createElement('img');starImg.src=isExpanded?'assets/star-expanded.png':'assets/star-collapsed.png';starImg.alt='';starImg.width=30;starImg.height=30;star.append(starImg);
  star.addEventListener('click',async()=>{
   if(expandedId!==null){collectEditor();await chrome.storage.local.set({behaviorModules:moduleStates});}
   expandedId=isExpanded?null:mod.id;
   if(expandedId)selectedId=expandedId;
   renderButtons();if(expandedId)renderEditor();
  });
  const toggle=document.createElement('button');toggle.type='button';toggle.className='heart-toggle';const isOn=moduleStates[mod.id].enabled;
  toggle.setAttribute('aria-label',(isOn?'Disable ':'Enable ')+mod.name);toggle.setAttribute('aria-pressed',String(isOn));
  const heart=document.createElement('img');heart.src=isOn?'assets/heart-enabled.png':'assets/heart-disabled.png';heart.alt='';heart.width=32;heart.height=32;toggle.append(heart);
  toggle.addEventListener('click',async()=>{moduleStates[mod.id].enabled=!moduleStates[mod.id].enabled;if(expandedId===mod.id)$('#module-enabled').checked=moduleStates[mod.id].enabled;await chrome.storage.local.set({behaviorModules:moduleStates});renderButtons()});
  heading.append(star,name,toggle);tile.append(heading);
  if(isExpanded){tile.append(editor);editor.hidden=false;editor.style.display='block'}
  grid.append(tile);
 }
 if(expandedId===null){editor.hidden=true;editor.style.display='none';grid.after(editor)}
 $('#enabled-count').textContent=AURELIUS_MODULES.filter(m=>m.id!=='research'&&moduleStates[m.id].enabled).length+' enabled';
}
function renderEditor(){const mod=AURELIUS_MODULES.find(m=>m.id===selectedId),state=selected();$('#module-editor').hidden=expandedId===null;$('#module-editor').style.display=expandedId===null?'none':'block';$('#module-title').textContent=mod.name;$('#module-enabled').checked=state.enabled;$('#module-instruction').value=state.instruction;$('#module-reason').value=state.reason;$('#module-example').value=state.example;$('#module-mode').value=state.mode;$('#include-context').checked=state.includeContext}
function collectEditor(){if(expandedId===null)return true;const state=selected();Object.assign(state,{enabled:$('#module-enabled').checked,instruction:$('#module-instruction').value,reason:$('#module-reason').value,example:$('#module-example').value,mode:$('#module-mode').value,includeContext:$('#include-context').checked});return true}
async function persistModules(){await chrome.storage.local.set({behaviorModules:moduleStates});renderButtons();statusField.textContent='Module saved locally.'}
async function loadSettings(){try{const saved=await chrome.storage.local.get(['instruction','interval','autoInjection','autoSend','behaviorModules']);instructionField.value=saved.instruction??'';intervalField.value=saved.interval??5;autoInjectionField.checked=saved.autoInjection===true;autoSendField.checked=saved.autoSend===true;moduleStates=defaults();for(const [id,state] of Object.entries(saved.behaviorModules||{})){if(moduleStates[id]&&state&&typeof state==='object')Object.assign(moduleStates[id],state)}renderButtons();if(expandedId)renderEditor()}catch(e){statusField.textContent=`Could not load settings: ${e.message}`}}
async function saveSettings(){const interval=Number(intervalField.value);if(!Number.isSafeInteger(interval)||interval<1){statusField.textContent='Enter a whole number of messages (1 or more).';return}try{const old=await chrome.storage.local.get(['autoInjection','autoInjectionEpoch']);const starting=autoInjectionField.checked&&!old.autoInjection;await chrome.storage.local.set({instruction:instructionField.value,interval,autoInjection:autoInjectionField.checked,autoSend:autoSendField.checked,...(starting?{autoInjectionEpoch:Date.now()}:{} )});statusField.textContent='Settings saved locally.'}catch(e){statusField.textContent=`Could not save settings: ${e.message}`}}
$('#save').addEventListener('click',saveSettings);$('#save-module').addEventListener('click',async()=>{if(collectEditor())await persistModules()});
async function insert(instruction){const out=$('#injection-status');out.textContent='Working…';if(!instruction.trim()){out.textContent='No instruction to insert.';return}try{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id||!tab.url?.startsWith('https://chatgpt.com/')){out.textContent='Open a ChatGPT conversation first.';return}const result=await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_INSERT_DRAFT',instruction});out.textContent=result?.ok?'Inserted into draft. Review before sending.':(result?.error||'Insertion failed.')}catch(e){out.textContent='Could not reach ChatGPT. Reload the tab after updating the extension.'}}
function modulePayload(id){const m=moduleStates[id];return `[Aurelius Rising — ${AURELIUS_MODULES.find(x=>x.id===id).name}]\n${m.instruction.trim()}${m.includeContext?`\nReason: ${m.reason.trim()}\nExample: ${m.example.trim()}`:''}`}
$('#research-now').addEventListener('click',async()=>{await insert(modulePayload('research'));$('#research-status').textContent=$('#injection-status').textContent;});$('#insert').addEventListener('click',()=>insert(instructionField.value));$('#insert-module').addEventListener('click',async()=>{if(!collectEditor())return;await persistModules();await insert(modulePayload(selectedId))});$('#insert-enabled').addEventListener('click',async()=>{
  // Save the currently edited module before constructing the combined payload.
  if(!collectEditor())return;
  await persistModules();
  const active=AURELIUS_MODULES.filter(m=>m.id!=='research'&&moduleStates[m.id].enabled);
  if(!active.length){$('#injection-status').textContent='Enable at least one heart before inserting.';return;}
  await insert(`[Aurelius Rising — ${active.length} enabled behavioral modules]\n\n`+active.map(m=>modulePayload(m.id)).join('\n\n'));
  // Keep the insertion result: it reports additions and skipped duplicates accurately.
});
async function refreshCounts(){
 const info=$('#counter-status'),numbers=$('#counter-numbers'),due=$('#counter-due');
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!tab.url?.startsWith('https://chatgpt.com/')){info.textContent='Open a ChatGPT conversation to see counts.';numbers.textContent='';due.textContent='';return}
  const data=await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_GET_COUNTS'});
  info.textContent='Read-only counter active (observed messages)';
  numbers.textContent=`User: ${data.user} | Assistant: ${data.assistant} | Total: ${data.total}`;
  const n=Number(intervalField.value);
  const id=new URL(tab.url).pathname.match(/^\/c\/([^/?#]+)/)?.[1];
  if(!Number.isSafeInteger(n)||n<1){due.textContent='Enter a valid message interval.';return}
  if(!autoInjectionField.checked){due.textContent=`Auto-injection off · starts at ${n} messages when enabled`;return}
  const key='aurelius:injection:'+id;
  const state=(await chrome.storage.local.get(key))[key];
  if(!state||state.version!==2){due.textContent=`Next injection in ${n} user messages`;return}
  const elapsed=Math.max(0,data.user-state.baseline);
  const remaining=n-(elapsed%n);
  due.textContent=`Next injection in ${remaining} user messages`;
 }catch(e){info.textContent='Counter unavailable. Reload the ChatGPT tab.';numbers.textContent='';due.textContent=''}
}
loadSettings();refreshCounts();setInterval(refreshCounts,1500);

// Aurelius JSON Converter — manual draft handoff; never auto-send.
const AURELIUS_JSON_CONVERTER_PAYLOAD = "# Aurelius Rising — Source-to-JSON Converter\n\nYou are converting roleplay archives, lorebooks, existing memory nodes, and user-supplied corrections into Aurelius Rising Memory Nodes Lite JSON.\n\n## Objective\nExtract meaningful, source-supported continuity into structured JSON that follows the `ar-jllm-lite/1` schema. Preserve established canon, chronology, character development, relationships, abilities, and world mechanics.\n\n## Supported node types\n- `character` — identity, personality, established history, character development\n- `relationship` — participants, established bonds, changes, meaningful interactions\n- `event` — important scenes, decisions, outcomes, chronology\n- `place` — locations, residents, features, location history\n- `ability` — spells, powers, techniques, transformations, ownership, effects\n\n## Required node structure\nEach node must contain:\n- `schema_version`: `\"ar-jllm-lite/1\"`\n- `id`: stable, unique identifier\n- `type`: one of the five supported types\n- `title`: human-readable title\n- `facts`: array of concise, source-supported statements\n- `related_ids`: array of related node IDs\n- `sources`: source references including chat ID and message indices, when available\n- `status`: `\"proposed\"` for newly extracted nodes\n- `last_updated_message_index`: latest supporting message index, or `null` when unavailable\n\nInclude relevant type-specific fields:\n- Character: `character_id`, `aliases`\n- Relationship: `participant_ids`, `relationship_label`\n- Event: `participant_ids`, `place_id`, `chronology_note`\n- Place: `resident_ids`, `parent_place_id`\n- Ability: `owner_id`, `form_name`, `ability_kind`\n\n## Extraction rules\n1. Treat explicit user-authored story facts and corrections as authoritative within the supplied material.\n2. Distinguish roleplay narration, character dialogue, speculation, and out-of-character corrections.\n3. Do not automatically promote bot-generated assumptions or character speculation into established canon.\n4. Preserve meaningful emotional and relationship developments without inventing conclusions.\n5. Maintain exact character identities and distinguish the player character from NPCs.\n6. Keep abilities linked to their actual owners using stable IDs.\n7. Preserve chronological anchors, elapsed time, and the distinction between completed events and future plans.\n8. When information conflicts, prioritize explicit user corrections and report unresolved contradictions.\n9. Never invent source message indices, chat IDs, events, or missing facts.\n10. Avoid duplicate nodes. When existing JSON is supplied, propose updates to matching nodes while preserving established information.\n11. Use positive, factual statements rather than unnecessary negative restrictions.\n12. Keep private Moritori Memory Library structures separate from the public Lite schema.\n\n## Output requirements\nReturn:\n1. A valid JSON object containing a `nodes` array.\n2. A short review section identifying uncertain claims, contradictions, and proposed updates that need approval.\n\nEvery generated node must conform to the schema. Do not insert explanatory commentary inside JSON. Do not mark new nodes as approved without user authorization.\nWhen supplied with an existing JSON file, preserve existing IDs and propose changes rather than replacing the entire database.\n\n**Source material:** [Insert or attach the chat export, lorebook, scene, or correction.]\n**Existing nodes:** [Optional JSON file.]\n**Conversion mode:** [Extract new nodes / Update existing nodes / Both.]\n\n## Large archive workflow\nBefore asking me to process an archive containing 3,000 or more messages, split it into 10 consecutive, roughly equal batches and send them in order. Preserve the original chat ID and global message indices in every batch; never renumber indices within a batch. Identify each batch and its message-index range. Track completed ranges, and do not produce the merged JSON until all 10 batches are present. Then reconcile duplicates, chronology, contradictions, and relationships across batch boundaries, and report any missing ranges.\n\n## Blank JSON template\n```json\n{\n  \"schema_version\": \"ar-jllm-lite/1\",\n  \"nodes\": [\n    {\n      \"schema_version\": \"ar-jllm-lite/1\",\n      \"id\": \"\",\n      \"type\": \"\",\n      \"title\": \"\",\n      \"facts\": [],\n      \"related_ids\": [],\n      \"sources\": [\n        {\n          \"chat_id\": \"\",\n          \"message_indices\": []\n        }\n      ],\n      \"status\": \"proposed\",\n      \"last_updated_message_index\": null\n    }\n  ]\n}\n```\n";
const converterButton = document.getElementById("json-converter-insert");
if (converterButton) converterButton.addEventListener("click", () => insert(AURELIUS_JSON_CONVERTER_PAYLOAD));
