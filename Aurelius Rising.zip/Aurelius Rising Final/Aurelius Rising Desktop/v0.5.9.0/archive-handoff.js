// User-controlled cross-tab handoff. No automatic sending, no background upload.
(()=>{
const KEY='aureliusArchiveSceneQueue058';const $=id=>document.getElementById(id);
const DEVELOPMENT=`[Character development — required]
Record established behavior, feelings, relationships, and developments in positive, evidence-based language. Preserve evolving relationships, initiative, emotional ambiguity, and room for future growth. Never introduce anti-romance or anti-growth soft locks (such as strictly platonic, only friends, never romantic, cannot develop feelings, or not yet romantically involved) unless explicitly requested by the user. Do not treat the absence of a confession as evidence that attraction is impossible or absent. Do not invent romantic developments unsupported by the scenes. Distinguish observations from interpretations.
`;
let queue=[];
const excerptMessageCount=()=>queue.reduce((n,s)=>n+((s.text.match(/\[(?:bot|YOU|user|assistant)[^\]\n]*\]/gi)||[]).length||1),0);
function evidenceText(){return queue.map((s,i)=>`[Selected scene ${i+1}]\nSource: ${s.filename} | record ${s.ordinal+1} | character ${s.offset+1} | range ${(s.selectionStart??0)+1}–${s.selectionEnd??s.text.length}\nSpeaker: ${s.speaker}\n--- ORIGINAL PASSAGE ---\n${s.text}\n--- END PASSAGE ---${s.extraContext?.trim()?`\n--- USER-SUPPLIED CONTEXT (not transcript) ---\n${s.extraContext.trim()}\n--- END USER CONTEXT ---`:''}`).join('\n\n');}
function downloadText(name,content){const url=URL.createObjectURL(new Blob([content],{type:'text/plain;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);}
const cleanupCommand=`[Aurelius Rising — Remove Growth Locks]
Review the Nexus draft for unnecessary anti-romance, anti-growth and relationship-limiting language. Replace defensive uncertainty with positive, evidence-grounded descriptions of established actions and development. Preserve genuine ambiguity, chronology, user corrections, and all source references. Never invent romantic milestones, and never silently overwrite canon. Treat attached Nexus entries as existing memory and attached chat excerpts as original evidence; keep user notes separate. Return complete revised nodes and a concise change log for user approval.`;

const relationshipEvidenceCommand=`[Aurelius Rising — Relationship Evidence Retrieval]
Search BOTH Thinking Process and visible story text in the user-provided archives for evidence of character relationships, emotional development, attraction, affection, romantic feelings, and changes in relationship status. Do not discard Thinking Process.

Evidence sources:
1. Thinking Process: Extract explicit statements about feelings, attraction, motivations, reciprocity, and developing emotional attachments. Label as MODEL INTERPRETATION, not independently established story canon.
2. Story Text: Extract relevant dialogue, actions, confessions, narration, and reactions. Label as STORY EVIDENCE. Cross-reference with corresponding thinking when possible.
3. User Statements: Keep canon declarations, corrections, and clarifications separately labeled as USER STATEMENTS, not model interpretation.

For each finding record: characters involved, direction of feelings, exact short supporting excerpt, source filename, message or record and location, evidence type, chronological position, and whether feelings are emerging, established, reciprocated, confessed, inferred, conditional, or contradicted.

Preserve chronological developments; compare earlier and later evidence rather than freezing an early relationship label. Distinguish explicit confirmation from speculation. Never invent feelings or milestones, silently overwrite Nexus canon, or treat a model's thinking alone as proof of an event. Group findings by relationship and propose concise, evidence-grounded Nexus updates with a change log for user approval.`;

function payload(){if(!queue.length)return '';return `[Aurelius Rising — Archive Lab Nexus Drafting]
Create copy-paste-ready draft Nexus nodes from the following user-selected original transcript passages. Suggest appropriate character, relationship, location, object, spell, or event entries when supported. Separate directly evidenced facts from interpretations; include source references. Treat user-supplied additional context as a separate source, not as transcript dialogue. Use it to clarify chronology, intent, and corrections without inventing new evidence. Preserve chronology when known, and mark unknowns as unknown without adding negative locks. Do not silently overwrite existing canon. The user will review and manually enter approved nodes.

${DEVELOPMENT}
${queue.map((s,i)=>`[Selected scene ${i+1}]
Source: ${s.filename} | record ${s.ordinal+1} | original character offset ${s.offset+1} | selected range ${s.selectionStart+1}–${s.selectionEnd}
Speaker/record type: ${s.speaker}
--- ORIGINAL PASSAGE ---
${s.text}
--- END PASSAGE ---
${s.extraContext?.trim()?`--- USER-SUPPLIED ADDITIONAL CONTEXT (not original transcript) ---\n${s.extraContext.trim()}\n--- END USER CONTEXT ---`:''}`).join('\n\n')}

Return organized draft nodes with names, types, descriptions, concise atomic facts, relevant relationships, and citations to selected scene numbers. Never treat a draft as automatically approved canon.`}
function scenePayload(){return queue.length?evidenceText():'';}
async function insertArchiveDraft(content, successText){
 const status=$('archive-insert-status');
 if(content.length>MAX_SAFE_DRAFT){
  status.textContent=`Draft is ${content.length.toLocaleString()} characters, above the ${MAX_SAFE_DRAFT.toLocaleString()}-character safe insertion limit. Nothing was inserted. Download the excerpt evidence file and attach it manually, or select fewer scenes.`;
  return;
 }
 status.textContent='Preparing ChatGPT draft…';
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!tab.url?.startsWith('https://chatgpt.com/')){status.textContent='Open a ChatGPT conversation in the active tab first.';return;}
  const result=await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_INSERT_DRAFT',instruction:content});
  status.textContent=result?.ok?successText:result?.error||'Insertion could not be confirmed.';
 }catch(e){status.textContent='Could not reach ChatGPT. Reload its tab and try again.';}
}
async function refresh(){try{queue=(await chrome.storage.local.get(KEY))[KEY]||[];const total=queue.reduce((n,s)=>n+s.text.length,0);$('archive-queue-badge').textContent=`${queue.length} scenes`;$('archive-queue-summary').textContent=`${queue.length} scene(s) · ${total.toLocaleString()} source characters. Review the full payload below.`;$('archive-draft-payload').value=excerptMessageCount()>10?'More than 10 source messages selected: download the excerpt evidence file and attach it in ChatGPT.':scenePayload();$('archive-insert').disabled=!queue.length;$('archive-nexus-insert').disabled=!queue.length}catch(e){$('archive-insert-status').textContent=`Cannot load scene queue: ${e.message}`}}
$('archive-open').addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL('archive.html')}));
$('archive-clear').addEventListener('click',async()=>{if(!confirm('Clear selected scenes? Imported archives will remain untouched.'))return;await chrome.storage.local.set({[KEY]:[]});await refresh()});
// Large transcripts can freeze rich-text composers. Explicitly block oversized drafts.
// Users can copy the full payload and paste a smaller selection manually.
const MAX_SAFE_DRAFT=6000;
$('archive-insert').addEventListener('click',async()=>{
 const content=scenePayload();
 if(!content)return;
 await insertArchiveDraft(content,'Selected scenes inserted into ChatGPT draft without Nexus instructions. Review before sending.');
});
$('archive-nexus-insert').addEventListener('click',async()=>{
 if(!queue.length)return;
 const content=excerptMessageCount()>10?
 `[Aurelius Rising — Archive Lab Nexus Drafting]\\nUse the attached Aurelius excerpt evidence file to draft copy-paste-ready Nexus nodes. Cite the selected scene numbers. Distinguish original evidence from user notes; do not invent unsupported developments. Require user approval.`:payload();
 await insertArchiveDraft(content,'Nexus drafting request inserted into ChatGPT draft. Review before sending.');
});
$('archive-download').addEventListener('click',()=>{if(!queue.length)return;downloadText('aurelius-selected-excerpts-preserved.txt',AureliusEvidence.build(queue).content);$('archive-insert-status').textContent='Excerpt evidence downloaded. Attach the TXT file to ChatGPT yourself; no file was uploaded automatically.';});
$('growth-command').addEventListener('click',async()=>{const status=$('archive-insert-status');try{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.url?.startsWith('https://chatgpt.com/')){status.textContent='Open a ChatGPT conversation in the active tab first.';return;}const result=await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_INSERT_DRAFT',instruction:cleanupCommand});status.textContent=result?.ok?'Growth-lock cleanup command inserted for review. Attach source files manually before sending.':result?.error||'Insertion not confirmed.';}catch(e){status.textContent='Could not reach ChatGPT; reload the ChatGPT tab.';}});
$('relationship-evidence-command').addEventListener('click',async()=>{
 const status=$('archive-insert-status');
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!tab.url?.startsWith('https://chatgpt.com/')){status.textContent='Open a ChatGPT conversation in the active tab first.';return;}
  const result=await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_INSERT_DRAFT',instruction:relationshipEvidenceCommand});
  status.textContent=result?.ok?'Relationship evidence instruction inserted into ChatGPT draft. Attach archives, review, then send manually.':result?.error||'Insertion not confirmed.';
 }catch(e){status.textContent='Could not reach ChatGPT. Reload its tab and try again.';}
});
$('archive-copy').addEventListener('click',async()=>{
 try{await navigator.clipboard.writeText(scenePayload());$('archive-insert-status').textContent='Selected scenes copied without Nexus instructions.'}
 catch(e){$('archive-insert-status').textContent='Copy failed; select the preview text and copy manually.'}
});

// File handoff: explicit file choice, optional cleaned evidence, no automatic message send.
const pickedFiles=[];
$('archive-file-picker').addEventListener('change',e=>{$('audit-review').hidden=true;pickedFiles.splice(0,pickedFiles.length,...e.target.files);$('archive-file-list').textContent=pickedFiles.length?pickedFiles.map(f=>`${f.name} (${(f.size/1024).toFixed(0)} KiB)`).join(' · '):'No source files selected.';});
function plannedFiles(){
 const files=[...pickedFiles];let evidence=null;
 if($('archive-include-evidence').checked&&queue.length){evidence=AureliusEvidence.build(queue);files.unshift(new File([evidence.content],'aurelius-selected-excerpts-preserved.txt',{type:'text/plain'}));}
 return {files,evidence};
}
function classify(name){return /nexus/i.test(name)?'Existing Nexus / memory (verify)':/excerpt|evidence/i.test(name)?'Original excerpt evidence':/archive|chat|fictionfall|export/i.test(name)?'Original transcript (verify)':'Unclassified source (review)';}
$('audit-preview').addEventListener('click',()=>{
 const {files,evidence}=plannedFiles();$('audit-review').hidden=false;$('audit-confirm').checked=false;
 $('audit-command-preview').value=cleanupCommand;
 $('audit-files-preview').value=files.length?files.map(f=>`${classify(f.name)} | ${f.name} | ${(f.size/1024).toFixed(1)} KiB`).join('\n'):'No files selected. Choose Nexus/source files or queue excerpts first.';
 $('audit-summary').textContent=evidence?`${evidence.originalSelections} selections → ${evidence.passages} passages; ${evidence.thinkingHeaders} Thinking Process headers detected; 0 thinking blocks removed. Original excerpt text preserved verbatim. Review mixed-source boundaries before approving.`:'No queued evidence included. Review source file types and provenance.';
 $('audit-result').textContent='Nothing has been attached or inserted.';
});
$('audit-handoff').addEventListener('click',async()=>{
 const status=$('audit-result');if(!$('audit-confirm').checked){status.textContent='Review and confirm first.';return;}
 const {files}=plannedFiles();if(!files.length){status.textContent='No files selected. Nothing changed.';return;}
 if(files.some(f=>f.size>8*1024*1024)){status.textContent='File exceeds 8 MiB. Use manual ChatGPT upload.';return;}
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id||!tab.url?.startsWith('https://chatgpt.com/')){status.textContent='Open a ChatGPT conversation in the active tab first.';return;}
 try{
  const items=await Promise.all(files.map(async f=>({name:f.name,type:f.type||'text/plain',bytes:Array.from(new Uint8Array(await f.arrayBuffer()))})));
  const response=await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_ATTACH_FILES',files:items});
  if(!response?.ok){status.textContent=`Attachment handoff failed: ${response?.error||'not supported'}. Nothing was sent. Upload manually.`;return;}
  const inserted=await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_INSERT_DRAFT',instruction:cleanupCommand});
  status.textContent=`File handoff attempted: ${files.map(f=>f.name).join(', ')}. ${inserted?.ok?'Audit instruction inserted into draft.':'Instruction insertion not confirmed.'} Verify actual attachment chips and text in ChatGPT before pressing Send. Server upload not confirmed.`;
 }catch(e){status.textContent=`Handoff failed (${e.message}). Nothing was sent; use manual attachment.`;}
});

chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes[KEY])refresh()});refresh();
})();
