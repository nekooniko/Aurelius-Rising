(() => {
  const $ = id => document.getElementById(id);
  const settingsKey = window.AureliusAnalytics.SETTINGS_KEY;
  const DEFAULT_ANALYTICS_ENDPOINT = 'https://aurelius-rising-analytics.aurelius-rising.workers.dev/api/analytics';
  const $collect = $('analytics-collect'), $endpoint = $('analytics-endpoint'), $consent = $('analytics-consent');
  const $status = $('analytics-summary'), $preview = $('analytics-preview'), $sendStatus = $('analytics-send-status');
  const $send = $('analytics-send');
  function setStatus(message) { $status.textContent = message; }
  function refreshSendState() { $send.disabled = !($consent.checked && $endpoint.value.trim()); }
  async function refresh() {
    try {
      const [saved, report] = await Promise.all([chrome.storage.local.get(settingsKey), window.AureliusAnalytics.summary()]);
      const config = saved[settingsKey] || {};
      $collect.checked = config.collect === true;
      $endpoint.value = (config.endpoint || '').trim() || DEFAULT_ANALYTICS_ENDPOINT;
      $consent.checked = config.sendConsent === true;
      const estimates = config.joulesPerGeneration || {};
      for (const provider of ['chatgpt', 'djai', 'jllm']) $(
        `analytics-j-${provider}`
      ).value = Number.isFinite(Number(estimates[provider])) && estimates[provider] !== '' ? estimates[provider] : '';
      $preview.value = JSON.stringify(report, null, 2);
      setStatus(report.localCollectionEnabled
        ? `${report.retainedEvents} local events · ${report.activeDays} active days · estimates are modeled where configured.`
        : `${report.retainedEvents} retained events · collection is off.`);
      refreshSendState();
    } catch (error) { setStatus(`Analytics could not load: ${error.message}`); }
  }
  async function saveSettings() {
    const estimates = {};
    for (const provider of ['chatgpt', 'djai', 'jllm']) {
      const raw = $(`analytics-j-${provider}`).value.trim();
      if (raw !== '') {
        const value = Number(raw);
        if (!Number.isFinite(value) || value < 0) { setStatus('Enter a non-negative joule estimate, or leave the field blank.'); return; }
        estimates[provider] = value;
      }
    }
    const prior = (await chrome.storage.local.get(settingsKey))[settingsKey] || {};
    const next = {...prior, collect: $collect.checked, joulesPerGeneration: estimates,
      endpoint: $endpoint.value.trim(), sendConsent: $consent.checked};
    await chrome.storage.local.set({[settingsKey]: next});
    setStatus(next.collect ? 'Analytics settings saved on this device.' : 'Collection paused. Previously stored counts remain until deleted.');
    await refresh();
  }
  async function log(kind, reroll = false) {
    if (!$collect.checked) { setStatus('Turn on local collection before recording events.'); return; }
    const provider = $('analytics-provider').value;
    const assisted = $('analytics-assisted').checked;
    if (kind === 'generation') await window.AureliusAnalytics.generation(provider, {assisted, reroll});
    else await window.AureliusAnalytics.record(provider, kind, {assisted});
    await refresh();
    setStatus(kind === 'generation' ? (reroll ? 'Reroll and generation recorded locally.' : 'Generation recorded locally.') : 'Correction recorded locally.');
  }
  $('analytics-save').addEventListener('click', () => void saveSettings().catch(error => setStatus(`Could not save settings: ${error.message}`)));
  $('analytics-log-generation').addEventListener('click', () => void log('generation'));
  $('analytics-log-reroll').addEventListener('click', () => void log('generation', true));
  $('analytics-log-correction').addEventListener('click', () => void log('correction'));
  $('analytics-export').addEventListener('click', async () => {
    const blob = new Blob([await window.AureliusAnalytics.exportJson()], {type: 'application/json'});
    const url = URL.createObjectURL(blob), anchor = document.createElement('a');
    anchor.href = url; anchor.download = 'aurelius-rising-analytics.json'; anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  $('analytics-clear').addEventListener('click', async () => {
    if (!confirm('Delete all locally stored Aurelius Rising analytics counts?')) return;
    await chrome.storage.local.remove(window.AureliusAnalytics.EVENTS_KEY);
    await refresh(); setStatus('Local analytics counts deleted.');
  });
  $endpoint.addEventListener('input', refreshSendState);
  $consent.addEventListener('change', refreshSendState);
  $('analytics-send').addEventListener('click', async () => {
    $sendStatus.textContent = '';
    const endpoint = $endpoint.value.trim();
    let url;
    try { url = new URL(endpoint); } catch (_) { $sendStatus.textContent = 'Enter a valid HTTPS endpoint.'; return; }
    if (url.protocol !== 'https:') { $sendStatus.textContent = 'The report endpoint must use HTTPS.'; return; }
    if (!$consent.checked) { $sendStatus.textContent = 'Check the consent box before sending.'; return; }
    try {
      if (!chrome.permissions?.request) throw new Error('This browser does not support optional endpoint permissions here. Export the JSON report instead.');
      const granted = await chrome.permissions.request({origins: [`${url.origin}/*`]});
      if (!granted) throw new Error('Endpoint permission was not granted.');
      const report = await window.AureliusAnalytics.summary();
      const response = await fetch(endpoint, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(report)});
      if (!response.ok) throw new Error(`Server replied with HTTP ${response.status}.`);
      $sendStatus.textContent = 'Aggregate report sent.';
    } catch (error) { $sendStatus.textContent = `Could not send report: ${error.message}`; }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes[window.AureliusAnalytics.EVENTS_KEY] || changes[settingsKey])) void refresh();
  });
  void refresh();
})();
