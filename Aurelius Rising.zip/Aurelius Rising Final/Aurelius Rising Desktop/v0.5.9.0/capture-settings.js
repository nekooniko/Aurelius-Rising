// Popup controls for opt-in, per-platform local chat capture.
document.addEventListener('DOMContentLoaded',()=>{
  const SETTINGS_KEY='aureliusChatCaptureSettings';
  const platforms={
    djai:{toggle:'capture-djai-toggle',status:'capture-djai-status',checkpoint:'capture-djai-checkpoint',url:/^https:\/\/(www\.)?dreamjourneyai\.com\/app\/session\//},
    jllm:{toggle:'capture-jllm-toggle',status:'capture-jllm-status',checkpoint:'capture-jllm-checkpoint',url:/^https:\/\/(www\.)?janitorai\.com\/chats\//}
  };
  let settings={jllm:false,djai:false};
  const el=id=>document.getElementById(id);
  const show=(platform)=>{
    const info=platforms[platform],box=el(info.toggle),status=el(info.status);if(!box||!status)return;
    box.checked=settings[platform]===true;
    chrome.storage.local.get(`aureliusChatCaptureStatus:${platform}`).then(data=>{
      if(box.checked){
        const saved=data[`aureliusChatCaptureStatus:${platform}`];
        const details=[saved?.message||'Live capture is on. Open a chat to begin saving messages locally.'];
        if(saved?.lastCapturedAt)details.push(`Saved through ${new Date(saved.lastCapturedAt).toLocaleString()}`);
        if(saved?.lastCheckpointAt)details.push(`Checkpoint ${new Date(saved.lastCheckpointAt).toLocaleString()}`);
        status.textContent=details.join(' · ');
      }else status.textContent='Capture is off. Existing local archives are kept.';
    }).catch(()=>{status.textContent=box.checked?'Live capture is on.':'Capture is off.';});
  };
  async function load(){
    try{const data=await chrome.storage.local.get(SETTINGS_KEY);settings={...settings,...(data[SETTINGS_KEY]||{})};}catch(_){}
    Object.keys(platforms).forEach(show);
  }
  for(const [platform,info] of Object.entries(platforms)){
    const box=el(info.toggle);if(!box)continue;
    box.addEventListener('change',async()=>{
      settings={...settings,[platform]:box.checked};
      try{await chrome.storage.local.set({[SETTINGS_KEY]:settings});show(platform);}
      catch(error){box.checked=!box.checked;const status=el(info.status);if(status)status.textContent='Could not update capture setting: '+error.message;}
    });
    el(info.checkpoint)?.addEventListener('click',async()=>{
      const status=el(info.status);
      try{
        const [tab]=await chrome.tabs.query({active:true,lastFocusedWindow:true});
        if(!tab?.id||!info.url.test(tab.url||'')){status.textContent='Open a chat on this platform first.';return;}
        const result=await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_CHAT_CHECKPOINT'});
        status.textContent=result?.ok?'Timestamped checkpoint saved locally.':'Turn on live capture before saving a checkpoint.';
      }catch(error){status.textContent='Reload the chat page after updating the extension, then retry.';}
    });
  }
  el('capture-open-archive-djai')?.addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL('archive.html#jllm-archive')}));
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local')return;
    if(changes[SETTINGS_KEY]){settings={...settings,...(changes[SETTINGS_KEY].newValue||{})};Object.keys(platforms).forEach(show);}
    for(const platform of Object.keys(platforms))if(changes[`aureliusChatCaptureStatus:${platform}`])show(platform);
  });
  void load();
});
