// Aurelius Rising: JLLM Memory Nodes Lite. Extension-owned nodes; JLLM has no native nodes.
(() => {
  if (window.__aureliusMemoryLite) return;
  window.__aureliusMemoryLite = true;
  const KEY = 'aureliusJllmLite:';
  const chatId = () => location.pathname.match(/^\/chats\/([^/]+)/)?.[1];
  const get = async id => {
    const stored=(await chrome.storage.local.get(KEY+id))[KEY+id];
    const data={nodes:[],...(stored||{})};
    if(!Array.isArray(data.nodes))data.nodes=[];
    const staleKeys=['interval','autoInject','injectNext','lastInjectionIndex','lastInjectionAt','lastReviewIndex','bridgeStatus','bridgeStatusAt'];
    const hadInjectionSettings=staleKeys.some(key=>Object.prototype.hasOwnProperty.call(data,key));
    for(const key of staleKeys)delete data[key];
    if(hadInjectionSettings)await chrome.storage.local.set({[KEY+id]:data});
    return data;
  };
  const put = async (id,data) => chrome.storage.local.set({[KEY+id]:data});
  const save = async (id,data) => put(id,data);
  let modal = null;
  const el = (tag, txt) => {const x=document.createElement(tag); if(txt!=null)x.textContent=txt;return x;};
  const style = el('style');style.textContent=`
    #ar-lite-overlay{position:fixed;inset:0;z-index:2147483647;background:rgba(10,7,18,.83);display:flex;align-items:center;justify-content:center;padding:12px;box-sizing:border-box;font:15px/1.5 system-ui,-apple-system,sans-serif;color:#f8edf8}
    #ar-lite-panel{color-scheme:dark;box-sizing:border-box;background:#292231;color:#f8edf8;border:1px solid #6a4c68;border-radius:20px;max-width:560px;width:100%;max-height:calc(100dvh - 24px);overflow-y:auto;overscroll-behavior:contain;padding:18px;box-shadow:0 16px 55px #000a;-webkit-overflow-scrolling:touch}
    #ar-lite-panel *{box-sizing:border-box}#ar-lite-panel h2{font-size:20px;line-height:1.25;margin:0;color:#fff}#ar-lite-panel h3{font-size:16px;margin:0 0 10px;color:#fff}#ar-lite-panel p{line-height:1.45;margin:9px 0 14px;color:#d5c1d4}
    #ar-lite-panel button,#ar-lite-panel select,#ar-lite-panel input,#ar-lite-panel textarea{font:inherit;max-width:100%;border-radius:10px;min-height:43px}
    #ar-lite-panel button{cursor:pointer;background:#f052b0;color:#231526;border:1px solid #fa83c8;padding:9px 13px;font-weight:700;white-space:normal;overflow-wrap:anywhere}
    #ar-lite-panel button:disabled{opacity:.5}#ar-lite-panel button:focus-visible,#ar-lite-panel input:focus-visible,#ar-lite-panel textarea:focus-visible,#ar-lite-panel select:focus-visible{outline:2px solid #ff9dd7;outline-offset:2px}
    #ar-lite-panel select,#ar-lite-panel input:not([type=checkbox]):not([type=file]),#ar-lite-panel textarea{background:#19151f;color:#fff;border:1px solid #79617b;padding:10px 12px}
    #ar-lite-panel input[type=file]{display:block;width:100%;background:#19151f;color:#f8edf8;border:1px solid #79617b;padding:8px;font-size:13px;min-height:0}
    #ar-lite-panel input[type=file]::file-selector-button{background:#f052b0;color:#231526;border:0;border-radius:8px;padding:8px;margin-right:8px;font-weight:700}
    #ar-lite-panel textarea{width:100%;min-height:96px;resize:vertical}#ar-lite-panel .ar-row{display:flex;gap:9px;flex-wrap:wrap;margin:10px 0;align-items:center}
    #ar-lite-panel .ar-row>*{min-width:0}#ar-lite-panel .ar-node{padding:12px;margin:9px 0;background:#372c3e;border:1px solid #604c63;border-radius:12px;overflow-wrap:anywhere}
    #ar-lite-panel .ar-node label{display:flex;gap:9px;align-items:flex-start}#ar-lite-panel input[type=checkbox]{accent-color:#f052b0;min-height:0;width:19px;height:19px;flex:none}
    #ar-lite-panel small{display:block;color:#cbb9cb;font-size:12px;line-height:1.5;overflow-wrap:anywhere}#ar-lite-panel .ar-section{background:#302738;border:1px solid #604c63;border-radius:14px;padding:14px;margin:14px 0}
    #ar-lite-panel .ar-section>summary{cursor:pointer;display:flex;align-items:center;gap:10px;list-style:none;font-size:16px;font-weight:750;color:#fff;min-height:36px;touch-action:manipulation}#ar-lite-panel .ar-section>summary::-webkit-details-marker{display:none}#ar-lite-panel .ar-section>summary:after{content:'⌄';margin-left:auto;color:#f052b0;font-size:22px;line-height:1;transition:transform .15s}#ar-lite-panel .ar-section[open]>summary:after{transform:rotate(180deg)}#ar-lite-panel .ar-section[open]>summary{margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid #604c63}#ar-lite-panel .ar-section>summary:focus-visible{outline:2px solid #ff9dd7;outline-offset:3px;border-radius:6px}#ar-lite-panel .ar-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:10px}#ar-lite-panel .ar-close{background:#4a384f;color:#fff;border:1px solid #816785;min-width:44px;flex:none}
    #ar-lite-panel .ar-secondary{background:#49374e;color:#fceafa;border-color:#87668b}#ar-lite-panel .ar-section input:not([type=file]),#ar-lite-panel .ar-section select{flex:1}
    @media(max-width:480px){#ar-lite-overlay{padding:7px;align-items:center}#ar-lite-panel{padding:13px;max-height:calc(100dvh - 14px);border-radius:15px}#ar-lite-panel .ar-section{padding:12px}#ar-lite-panel .ar-row button{flex:1 1 auto}}
  `;document.documentElement.append(style);
  const section=(title)=>{const box=el('details');box.className='ar-section';box.append(el('summary',title));return box;};
  function close(){modal?.remove();modal=null;}
  function openDialog(id,data,reason){
    if(modal)return;
    modal=el('div');modal.id='ar-lite-overlay';
    const panel=el('section');panel.id='ar-lite-panel';modal.append(panel);
    const head=el('div');head.className='ar-head';const heading=el('h2','Aurelius Memory Nodes Lite');const closeButton=el('button','✕');closeButton.className='ar-close';closeButton.setAttribute('aria-label','Close memory panel');closeButton.onclick=close;head.append(heading,closeButton);panel.append(head);
    panel.append(el('p','Choose memories below, review the preview, then copy and paste it into JanitorAI’s memory fields. Aurelius does not edit or send anything to JanitorAI.'));
    const copyBox=section('Copy selected memories');copyBox.open=true;panel.append(copyBox);
    const preview=el('textarea');preview.readOnly=true;preview.rows=8;preview.setAttribute('aria-label','Preview of selected memories');
    const previewStats=el('small','No memories selected.');const copyStatus=el('small');copyStatus.setAttribute('role','status');copyStatus.setAttribute('aria-live','polite');
    const copyButton=el('button','Copy selected memories');copyButton.className='ar-secondary';copyButton.disabled=true;
    function selectedText(){const chosen=data.nodes.filter(n=>n&&n.selected!==false&&String(n.name||'').trim()&&String(n.fact||'').trim());return chosen.map(n=>'['+String(n.type||'event').toUpperCase()+'] '+String(n.name).trim()+'\n'+String(n.fact).trim()).join('\n\n');}
    function renderPreview(){const text=selectedText();preview.value=text;const count=data.nodes.filter(n=>n&&n.selected!==false&&String(n.name||'').trim()&&String(n.fact||'').trim()).length;previewStats.textContent=count?count+' selected memor'+(count===1?'y':'ies')+' · '+text.length.toLocaleString()+' characters':'No memories selected.';copyButton.disabled=!text;copyStatus.textContent='';}
    copyButton.onclick=async()=>{
      const text=selectedText();if(!text){copyStatus.textContent='Select at least one memory first.';return;}
      try{await navigator.clipboard.writeText(text);}
      catch(_){preview.focus();preview.select();if(!document.execCommand('copy')){copyStatus.textContent='Copy failed. Select the preview text and copy it manually.';return;}}
      copyStatus.textContent='Copied. Paste the selected memories into a JanitorAI memory field.';
    };
    copyBox.append(el('p','Preview updates as you select memories.'),preview,previewStats,copyButton,copyStatus);
    const manage=section('Manage memories');panel.append(manage);
    const searchLabel=el('label','Search memories');searchLabel.htmlFor='ar-lite-search';
    const search=el('input');search.id='ar-lite-search';search.type='search';search.placeholder='Search name, type, or memory text';search.setAttribute('aria-label','Search JLLM memory nodes');manage.append(searchLabel,search);
    const searchStatus=el('small');searchStatus.setAttribute('role','status');searchStatus.setAttribute('aria-live','polite');manage.append(searchStatus);
    const list=el('div');manage.append(list);let visibleNodes=[];
    function render(){const query=search.value.trim().toLocaleLowerCase();visibleNodes=data.nodes.filter(node=>!query||[node.type,node.name,node.fact].some(value=>String(value??'').toLocaleLowerCase().includes(query)));list.replaceChildren();searchStatus.textContent=data.nodes.length?`Showing ${visibleNodes.length} of ${data.nodes.length} memories.`:'No saved memories yet.';if(!data.nodes.length)list.append(el('p','No nodes yet. Add a node below to begin.'));else if(!visibleNodes.length)list.append(el('p','No memories match that search.'));
      for(const node of visibleNodes){const wrap=el('div');wrap.className='ar-node';const label=el('label');const check=el('input');check.type='checkbox';check.checked=node.selected!==false;check.onchange=async()=>{node.selected=check.checked;await save(id,data);render()};
        label.append(check,el('strong',`${node.type}: ${node.name}`));wrap.append(label,el('small',node.fact));
        const edit=el('button','Edit');edit.onclick=()=>{const name=prompt('Node name',node.name);if(name===null)return;const fact=prompt('Established fact / lorebook text',node.fact);if(fact===null)return;node.name=name.trim();node.fact=fact.trim();void save(id,data).then(render)};
        const del=el('button','Delete');del.onclick=()=>{if(!confirm(`Delete ${node.name}?`))return;data.nodes=data.nodes.filter(n=>n.id!==node.id);void save(id,data).then(render)};
        const buttons=el('div');buttons.className='ar-row';buttons.append(edit,del);wrap.append(buttons);list.append(wrap)}
      renderPreview();
    }search.addEventListener('input',render);render();
    const actions=el('div');actions.className='ar-row';
    const all=el('button','Select shown');all.onclick=()=>{visibleNodes.forEach(n=>n.selected=true);void save(id,data).then(render)};
    const clear=el('button','Clear shown');clear.onclick=()=>{visibleNodes.forEach(n=>n.selected=false);void save(id,data).then(render)};
    actions.append(all,clear);manage.append(actions);
    // Import is extension-owned; no JLLM node API exists. Never replace existing nodes.
    const importBox=section('Import nodes (.json or .txt)');importBox.open=true;
    const importRow=el('div');importRow.className='ar-row';
    const fileInput=el('input');fileInput.type='file';fileInput.accept='.json,.txt,application/json,text/plain';
    fileInput.setAttribute('aria-label','Choose JSON or TXT nodes file');
    const importButton=el('button','Import nodes');
    const importStatus=el('small','JSON: array of nodes or {"nodes": [...]}. TXT: one fact per line, or blank-line-separated blocks.');
    importStatus.setAttribute('role','status');
    const allowedTypes=new Set(['character','relationship','event','place','ability']);
    function parseImportedNodes(text,filename){
      if(/\.json$/i.test(filename)){
        const parsed=JSON.parse(text);
        const records=Array.isArray(parsed)?parsed:parsed?.nodes;
        if(!Array.isArray(records))throw Error('JSON must contain a nodes array (or be an array of nodes).');
        return records.map((item,i)=>{
          if(!item||typeof item!=='object'||Array.isArray(item))throw Error(`Node ${i+1} is not an object.`);
          const name=String(item.name||item.title||'').trim();
          const type=String(item.type||'event').toLowerCase().trim();
          const fact=String(item.fact||item.description||(Array.isArray(item.facts)?item.facts.join('\n'):item.text||'')).trim();
          if(!name||!fact)throw Error(`Node ${i+1} needs a name and fact/description/facts.`);
          if(!allowedTypes.has(type))throw Error(`Node ${i+1} has unsupported type: ${type}`);
          return {id:crypto.randomUUID(),type,name,fact,selected:true};
        });
      }
      // TXT supports [TYPE] Name: fact lines (including prepared lorebook text),
      // and simple plain-text notes (each line or blank-line-separated paragraph).
      const blocks=text.trim().split(/\n\s*\n/).flatMap(block=>{
        const lines=block.split(/\r?\n/).map(line=>line.trim()).filter(Boolean);
        if(lines.length>1&&lines.every(line=>/^\[(?:CHARACTER|RELATIONSHIP|EVENT|PLACE|ABILITY)\]\s+.+?:\s*.+/i.test(line)))return lines;
        return [block.trim()];
      }).filter(Boolean);
      return blocks.map((block,i)=>{
        const match=block.match(/^\[(character|relationship|event|place|ability)\]\s+([^:\n]+):\s*([\s\S]+)/i);
        if(match)return {id:crypto.randomUUID(),type:match[1].toLowerCase(),name:match[2].trim(),fact:match[3].trim(),selected:true};
        const lines=block.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
        const heading=lines.length>1?lines[0].replace(/^#+\s*/,'').replace(/:$/,''):'';
        return {id:crypto.randomUUID(),type:'event',name:heading||`Imported note ${i+1}`,fact:lines.length>1?lines.slice(1).join('\n'):block.trim(),selected:true};
      });
    }
    importButton.onclick=async()=>{
      const file=fileInput.files?.[0];
      if(!file){importStatus.textContent='Choose a .json or .txt file first.';return;}
      if(!/\.(json|txt)$/i.test(file.name)){importStatus.textContent='Only .json and .txt files are supported.';return;}
      if(file.size>2*1024*1024){importStatus.textContent='File is too large (2 MB maximum).';return;}
      importButton.disabled=true;
      try{
        const imported=parseImportedNodes(await file.text(),file.name);
        if(!imported.length)throw Error('No nodes found in the file.');
        const existing=new Set(data.nodes.map(n=>`${n.type}\u0000${n.name.toLowerCase()}\u0000${n.fact}`));
        const additions=imported.filter(n=>{const key=`${n.type}\u0000${n.name.toLowerCase()}\u0000${n.fact}`;if(existing.has(key))return false;existing.add(key);return true;});
        // Refresh stored state to avoid overwriting edits from another open tab.
        const latest=await get(id);
        const latestKeys=new Set(latest.nodes.map(n=>`${n.type}\u0000${n.name.toLowerCase()}\u0000${n.fact}`));
        const unique=additions.filter(n=>!latestKeys.has(`${n.type}\u0000${n.name.toLowerCase()}\u0000${n.fact}`));
        latest.nodes.push(...unique);
        await save(id,latest);
        data.nodes=latest.nodes;
        render();
        importStatus.textContent=`Imported ${unique.length} node(s). Skipped ${imported.length-unique.length} duplicate(s). Existing nodes preserved.`;
        fileInput.value='';
      }catch(err){importStatus.textContent='Import failed: '+err.message;}
      finally{importButton.disabled=false;}
    };
    importRow.append(fileInput,importButton);importBox.append(importRow,importStatus);panel.insertBefore(importBox,manage);
    const add=section('Add memory node');
    const row=el('div');row.className='ar-row';const type=el('select');for(const t of ['character','relationship','event','place','ability']){const o=el('option',t);o.value=t;type.append(o)}
    const name=el('input');name.placeholder='Node name';row.append(type,name);add.append(row);
    const fact=el('textarea');fact.placeholder='Memory text';add.append(fact);
    const addButton=el('button','Add node');addButton.onclick=async()=>{if(!name.value.trim()||!fact.value.trim())return;data.nodes.push({id:crypto.randomUUID(),type:type.value,name:name.value.trim(),fact:fact.value.trim(),selected:true});await save(id,data);name.value='';fact.value='';render()};add.append(addButton);panel.append(add);
    document.body.append(modal);
  }
  async function openForCurrentChat() {
    const id = chatId();
    if (!id) return {ok: false};
    const data = await get(id);
    if (chatId() !== id) return {ok: false};
    openDialog(id, data, 'manual');
    return {ok: true};
  }
  globalThis.aureliusJllmOpenNodes = openForCurrentChat;
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg?.type !== 'AURELIUS_JLLM_LITE_OPEN') return;
    void openForCurrentChat().then(reply, () => reply({ok: false}));
    return true;
  });
})();
