// Local, opt-in, content-free analytics for Aurelius Rising.
(() => {
  const EVENTS_KEY = 'aureliusAnalyticsEventsV1';
  const SETTINGS_KEY = 'aureliusAnalyticsSettingsV1';
  const MAX_EVENTS = 10000;
  const providers = new Set(['chatgpt', 'djai', 'jllm']);
  const kinds = new Set(['generation', 'reroll', 'correction']);
  const day = () => new Date().toISOString().slice(0, 10);
  async function settings() {
    return (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY] || {};
  }
  async function record(provider, kind, options = {}) {
    if (!providers.has(provider) || !kinds.has(kind)) return false;
    try {
      const config = await settings();
      if (config.collect !== true) return false;
      const estimate = Number(config.joulesPerGeneration?.[provider]);
      const events = (await chrome.storage.local.get(EVENTS_KEY))[EVENTS_KEY] || [];
      const entry = { day: day(), provider, kind,
        assisted: options.assisted === true ? 'yes' : options.assisted === false ? 'no' : 'unknown',
        estimatedJ: kind === 'generation' && Number.isFinite(estimate) && estimate >= 0 ? estimate : null,
        reroll: options.reroll === true };
      events.push(entry);
      await chrome.storage.local.set({ [EVENTS_KEY]: events.slice(-MAX_EVENTS) });
      return true;
    } catch (_) { return false; }
  }
  async function generation(provider, options = {}) {
    return record(provider, 'generation', options);
  }
  async function summary() {
    const [settingsValue, eventValue] = await Promise.all([
      chrome.storage.local.get(SETTINGS_KEY), chrome.storage.local.get(EVENTS_KEY)
    ]);
    const config = settingsValue[SETTINGS_KEY] || {};
    const events = Array.isArray(eventValue[EVENTS_KEY]) ? eventValue[EVENTS_KEY] : [];
    const output = {schemaVersion: 1, period: 'all retained local events', providers: {}, activeDays: new Set(events.map(x => x.day)).size, generatedMonth: day().slice(0, 7)};
    for (const provider of providers) output.providers[provider] = {generations: 0, rerolls: 0, corrections: 0, estimatedJoules: 0, generationsWithEstimate: 0, extensionContextAdded: 0, extensionContextNotAdded: 0, contextStatusUnknown: 0};
    for (const event of events) {
      if (!event || !providers.has(event.provider)) continue;
      const row = output.providers[event.provider];
      if (event.kind === 'generation') {
        row.generations++;
        if (event.estimatedJ !== null && Number.isFinite(event.estimatedJ)) { row.estimatedJoules += event.estimatedJ; row.generationsWithEstimate++; }
        if (event.assisted === 'yes') row.extensionContextAdded++;
        else if (event.assisted === 'no') row.extensionContextNotAdded++;
        else row.contextStatusUnknown++;
        if (event.reroll) row.rerolls++;
      } else if (event.kind === 'reroll') row.rerolls++;
      else if (event.kind === 'correction') row.corrections++;
    }
    output.retainedEvents = events.length;
    output.localCollectionEnabled = config.collect === true;
    return output;
  }
  async function exportJson() {
    return JSON.stringify(await summary(), null, 2);
  }
  window.AureliusAnalytics = {record, generation, summary, exportJson, SETTINGS_KEY, EVENTS_KEY};
})();
