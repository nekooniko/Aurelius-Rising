// Local conversation-capture reminders. Message text stays in extension storage.
(() => {
  'use strict';
  const SETTINGS_KEY = 'aureliusChatCaptureSettings';
  const ALARM = 'aurelius-live-capture-checkpoint';
  const NOTICE = 'aurelius-live-capture-notice';
  const ARCHIVE_URL = chrome.runtime.getURL('archive.html#jllm-archive');

  async function settings() {
    return (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY] || {jllm:false,djai:false};
  }
  async function syncAlarm() {
    try {
      const enabled = await settings();
      if (enabled.jllm || enabled.djai) {
        const alarm = await chrome.alarms.get(ALARM);
        if (!alarm) await chrome.alarms.create(ALARM,{delayInMinutes:30,periodInMinutes:30});
      } else {
        await chrome.alarms.clear(ALARM);
        await chrome.notifications.clear(NOTICE);
      }
    } catch (error) { console.warn('Aurelius capture reminder unavailable:',error); }
  }
  async function openArchive() {
    try { await chrome.tabs.create({url:ARCHIVE_URL}); } catch (error) { console.warn('Could not open Aurelius Archive Lab:',error); }
  }
  async function checkpointCurrentChat() {
    try {
      const [tab] = await chrome.tabs.query({active:true,lastFocusedWindow:true});
      if (!tab?.id) return false;
      const reply = await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_CHAT_CHECKPOINT'});
      return !!reply?.ok;
    } catch (_) { return false; }
  }
  async function showReminder(sites) {
    try {
      await chrome.notifications.create(NOTICE,{
        type:'basic',
        iconUrl:chrome.runtime.getURL('assets/notification alert.png'),
        title:'Aurelius Rising · Chat checkpoint',
        message:`${sites} live capture is on. Save a timestamped checkpoint or open your local archive.`,
        buttons:[{title:'Save checkpoint'},{title:'Open archive'}],
        priority:1
      });
      return {ok:true};
    } catch (error) {
      console.warn('Aurelius checkpoint notification unavailable:',error);
      return {ok:false,error:String(error)};
    }
  }

  chrome.runtime.onInstalled.addListener(() => { void syncAlarm(); });
  chrome.runtime.onStartup.addListener(() => { void syncAlarm(); });
  chrome.storage.onChanged.addListener((changes,area) => {
    if (area==='local' && changes[SETTINGS_KEY]) void syncAlarm();
  });
  chrome.alarms.onAlarm.addListener(async alarm => {
    if (alarm.name!==ALARM) return;
    const enabled=await settings();
    if (!enabled.jllm && !enabled.djai) return;
    const [tab] = await chrome.tabs.query({active:true,lastFocusedWindow:true});
    if (enabled.djai && tab?.id && /^https:\/\/(www\.)?dreamjourneyai\.com\//.test(tab.url||'')) {
      try { await chrome.tabs.sendMessage(tab.id,{type:'AURELIUS_CAPTURE_MENU_REMINDER'}); return; }
      catch (_) { /* If the page bridge is unavailable, use the browser notification below. */ }
    }
    const sites=[enabled.djai?'DreamJourney AI':null,enabled.jllm?'JanitorAI':null].filter(Boolean).join(' and ');
    await showReminder(sites);
  });
  chrome.notifications.onButtonClicked.addListener(async (_id,index) => {
    if (_id!==NOTICE) return;
    if (index===0) {
      const ok=await checkpointCurrentChat();
      if (ok) await chrome.notifications.create(NOTICE+'-saved',{
        type:'basic',iconUrl:chrome.runtime.getURL('assets/notification alert.png'),
        title:'Checkpoint saved locally',message:'The active chat was added to your chronological archive.',priority:0
      });
      else await openArchive();
    } else if (index===1) await openArchive();
    await chrome.notifications.clear(NOTICE);
  });
  chrome.notifications.onClicked.addListener(async id => {
    if (id===NOTICE) await openArchive();
  });
  chrome.runtime.onMessage.addListener((message,_sender,reply) => {
    if (message?.type==='AURELIUS_CAPTURE_OPEN_ARCHIVE') { void openArchive(); reply({ok:true}); }
    if (message?.type==='AURELIUS_CAPTURE_SAVE_CHECKPOINT') { void checkpointCurrentChat().then(ok=>reply({ok})); return true; }
    if (message?.type==='AURELIUS_CAPTURE_PROMPT') {
      void settings().then(enabled=>{
        if(!enabled[message.platform])return{ok:false,error:'Capture is off.'};
        const site=message.platform==='djai'?'DreamJourney AI':'JanitorAI';
        return showReminder(site);
      }).then(reply).catch(error=>reply({ok:false,error:String(error)}));
      return true;
    }
  });
  void syncAlarm();
})();
