// Active-page reminder fallback. DreamJourney AI reminders appear beside Aurelius's floating menu.
(() => {
  'use strict';
  const SETTINGS_KEY='aureliusChatCaptureSettings';
  const PLATFORM=location.pathname.startsWith('/app/session/')?'djai':'jllm';
  const STATE_KEY=`aureliusCaptureReminderFallback:${PLATFORM}`;
  const INTERVAL=30*60*1000;
  let timeout=0;
  const enabledForPage=()=>PLATFORM==='djai'?/^https:\/\/(www\.)?dreamjourneyai\.com\//.test(location.origin):/^https:\/\/(www\.)?janitorai\.com\//.test(location.origin);

  function showReminderCard(root,anchor){
    if(root.querySelector('#aurelius-capture-reminder'))return;
    const card=document.createElement('section');card.id='aurelius-capture-reminder';
    card.setAttribute('role','alertdialog');card.setAttribute('aria-live','polite');card.setAttribute('aria-label','Chat checkpoint reminder');
    card.style.cssText='pointer-events:auto;position:absolute;right:58px;bottom:0;width:min(320px,calc(100vw - 100px));padding:14px;border:1px solid #e58ac6;border-radius:14px;background:#211925;color:#fff;font:14px/1.45 system-ui,sans-serif;box-shadow:0 8px 32px #0009;z-index:2';
    const title=document.createElement('strong');title.textContent='Chat checkpoint reminder';title.style.cssText='display:block;font-size:16px;margin-bottom:6px;color:#ffb7df';
    const copy=document.createElement('p');copy.textContent='Your chat is being saved locally as messages appear. Save a timestamped checkpoint or open the archive.';copy.style.cssText='margin:0 0 12px';
    const status=document.createElement('p');status.setAttribute('role','status');status.style.cssText='margin:8px 0 0;color:#ffc8e6';
    const actions=document.createElement('div');actions.style.cssText='display:flex;gap:8px;flex-wrap:wrap';
    const button=(label,action)=>{const el=document.createElement('button');el.type='button';el.textContent=label;el.style.cssText='border:1px solid #d78ac1;border-radius:8px;padding:8px 10px;background:#432c43;color:#fff;font:inherit;cursor:pointer';el.addEventListener('click',action);return el;};
    actions.append(button('Save checkpoint',async event=>{
      const target=event.currentTarget;target.disabled=true;target.textContent='Saving…';
      try{const result=await chrome.runtime.sendMessage({type:'AURELIUS_CAPTURE_SAVE_CHECKPOINT'});if(result?.ok){status.textContent='Checkpoint saved locally.';target.textContent='Saved';}else{status.textContent='Could not save from this chat. Open the archive to check your capture.';target.textContent='Try again';target.disabled=false;}}
      catch(_){status.textContent='Could not save from this chat. Try again.';target.textContent='Try again';target.disabled=false;}
    }));
    actions.append(button('Open archive',()=>{void chrome.runtime.sendMessage({type:'AURELIUS_CAPTURE_OPEN_ARCHIVE'});card.remove();}));
    actions.append(button('Dismiss',()=>card.remove()));
    card.append(title,copy,actions,status);anchor.append(card);
  }

  function showFallback(){
    if(PLATFORM==='djai'){
      const host=document.getElementById('ar-floating-root');
      if(host?.shadowRoot){const star=host.shadowRoot.querySelector('.star');if(star){showReminderCard(host.shadowRoot,host.shadowRoot);return;}}
    }
    if(document.getElementById('aurelius-capture-reminder'))return;
    const panel=document.createElement('section');panel.id='aurelius-capture-reminder';
    panel.setAttribute('role','dialog');panel.setAttribute('aria-live','polite');
    panel.style.cssText='position:fixed;right:16px;bottom:16px;z-index:2147483647;width:min(340px,calc(100vw - 32px));padding:16px;border:1px solid #e58ac6;border-radius:14px;background:#211925;color:#fff;font:14px/1.45 system-ui,sans-serif;box-shadow:0 8px 32px #0009';
    const title=document.createElement('strong');title.textContent='Chat checkpoint reminder';title.style.cssText='display:block;font-size:16px;margin-bottom:6px;color:#ffb7df';
    const copy=document.createElement('p');copy.textContent='Your chat is being saved locally as messages appear. Save a timestamped checkpoint or open the archive.';copy.style.cssText='margin:0 0 12px';
    const actions=document.createElement('div');actions.style.cssText='display:flex;gap:8px;flex-wrap:wrap';
    const button=(label,action)=>{const el=document.createElement('button');el.type='button';el.textContent=label;el.style.cssText='border:1px solid #d78ac1;border-radius:8px;padding:8px 10px;background:#432c43;color:#fff;font:inherit';el.addEventListener('click',action);return el;};
    actions.append(button('Save checkpoint',async event=>{const target=event.currentTarget;target.disabled=true;target.textContent='Saving…';try{const result=await chrome.runtime.sendMessage({type:'AURELIUS_CAPTURE_SAVE_CHECKPOINT'});target.textContent=result?.ok?'Checkpoint saved':'Could not save';}catch(_){target.textContent='Could not save';}}));
    actions.append(button('Open archive',()=>{void chrome.runtime.sendMessage({type:'AURELIUS_CAPTURE_OPEN_ARCHIVE'});panel.remove();}));
    actions.append(button('Dismiss',()=>panel.remove()));
    panel.append(title,copy,actions);document.body.append(panel);
  }

  async function schedule(){
    if(timeout)clearTimeout(timeout);timeout=0;
    if(!enabledForPage())return;
    try{
      const data=await chrome.storage.local.get([SETTINGS_KEY,STATE_KEY]);
      const settings=data[SETTINGS_KEY]||{};
      if(settings[PLATFORM]!==true){await chrome.storage.local.remove(STATE_KEY);return;}
      const now=Date.now();let state=data[STATE_KEY]||{};
      if(!Number.isFinite(state.nextAt)){state={nextAt:now+INTERVAL};await chrome.storage.local.set({[STATE_KEY]:state});}
      const delay=Math.max(1000,state.nextAt-now);
      timeout=setTimeout(async()=>{
        timeout=0;const dueAt=Date.now();state={...state,lastPromptAt:dueAt,nextAt:dueAt+INTERVAL};await chrome.storage.local.set({[STATE_KEY]:state});
        if(PLATFORM==='djai')showFallback();
        else{try{const response=await chrome.runtime.sendMessage({type:'AURELIUS_CAPTURE_PROMPT',platform:PLATFORM});if(!response?.ok)showFallback();}catch(_){showFallback();}}
        void schedule();
      },delay);
    }catch(_){/* Keep the normal capture path independent of reminder storage. */}
  }
  chrome.runtime.onMessage.addListener(message=>{if(message?.type==='AURELIUS_CAPTURE_MENU_REMINDER'&&PLATFORM==='djai')showFallback();});
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes[SETTINGS_KEY]||changes[STATE_KEY]))void schedule();});
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')void schedule();});
  void schedule();
})();
