// Page-world JLLM bridge. Adds selected memories to eligible outgoing chat requests
// without adding a visible message to the conversation.
(() => {
  'use strict';
  if (window.__aureliusJllmMemoryBridge) return;
  window.__aureliusJllmMemoryBridge = true;
  const CHANNEL = 'aurelius-jllm-memory-05813';
  const MARKER = '[Selected context]';
  let config = null;
  let lastInjectedIndex = -1;

  function report(kind, detail = {}) {
    window.postMessage({channel:CHANNEL,kind,chatId:chatId(),...detail},location.origin);
  }

  const chatId = () => location.pathname.match(/^\/chats\/([^/]+)/)?.[1] || null;
  function currentIndex() {
    const indices = [...document.querySelectorAll('[data-index]')]
      .filter(el => el.querySelector('li[class*="_messageDisplayWrapper_"]'))
      .map(el => Number(el.getAttribute('data-index')))
      .filter(Number.isSafeInteger);
    return indices.length ? Math.max(...indices) : -1;
  }
  function cleanNodes(nodes) {
    if (!Array.isArray(nodes)) return [];
    return nodes.filter(n => n && typeof n.name === 'string' && typeof n.fact === 'string' && n.name.trim() && n.fact.trim())
      .map(n => ({type:String(n.type || 'event').slice(0,40),name:n.name.trim().slice(0,240),fact:n.fact.trim().slice(0,8000)}));
  }
  function memoryText(nodes) {
    const sections=[];
    if(nodes.length)sections.push(`Selected memories:\n${nodes.map(n => `[${n.type.toUpperCase()}] ${n.name}: ${n.fact}`).join('\n\n')}`);
    const scene=cleanScene(config.scene);
    if(scene){
      const lines=[];
      if(scene.location)lines.push(`Location: ${scene.location}`);
      if(scene.character)lines.push(`Your character: ${scene.character}`);
      if(scene.present)lines.push(`Present: ${scene.present}`);
      if(scene.note)lines.push(`Scene note: ${scene.note}`);
      sections.push(`Current scene:\n${lines.join('\n')}`);
    }
    return `${MARKER}\n${sections.join('\n\n')}\n[End selected context]`;
  }
  function cleanScene(scene) {
    if(!scene||typeof scene!=='object'||scene.enabled===false)return null;
    const clean={};
    for(const key of ['location','character','present','note'])if(typeof scene[key]==='string')clean[key]=scene[key].trim().slice(0,2000);
    return Object.values(clean).some(Boolean)?clean:null;
  }
  function eligibleUrl(raw, method) {
    if (method !== 'POST') return false;
    try {
      const url = new URL(raw, location.href);
      // JanitorAI's JLLM generation route. OpenAI-compatible proxy routes are
      // also supported when the request uses a messages array.
      return /\/generateAlpha\/?$/i.test(url.pathname) || /\/chat\/completions\/?$/i.test(url.pathname);
    } catch (_) { return false; }
  }
  function findMessageArray(body) {
    const candidates = [body, body?.data, body?.request, body?.input];
    for (const candidate of candidates) {
      if (!candidate || typeof candidate !== 'object') continue;
      for (const key of ['messages','chat_history','history']) {
        if (Array.isArray(candidate[key]) && candidate[key].every(item => item && typeof item === 'object')) {
          return {owner:candidate,key};
        }
      }
    }
    return null;
  }
  function patchJson(text, rawUrl, method) {
    if (typeof text !== 'string' || !eligibleUrl(rawUrl, method)) return null;
    const activeId = chatId();
    if (!config || !config.enabled || !activeId || config.chatId !== activeId) return null;
    const nodes = cleanNodes(config.nodes);
    const scene=cleanScene(config.scene);
    if (!nodes.length&&!scene) return null;
    const interval = [10,15,20].includes(Number(config.interval)) ? Number(config.interval) : 15;
    const position = currentIndex();
    const baseline = Number.isSafeInteger(lastInjectedIndex) && lastInjectedIndex >= 0 ? lastInjectedIndex : Number(config.lastInjectionIndex);
    if (position < 0 || !Number.isSafeInteger(baseline) || baseline < 0) {
      report('waiting', {message:'Waiting for JanitorAI message positions to load.'});
      return null;
    }
    const remaining = interval - (position - baseline);
    if (remaining > 0) {
      report('waiting', {message:`Hidden memory injection is armed; ${remaining} message${remaining===1?'':'s'} until the next injection.`});
      return null;
    }
    let body;
    try { body = JSON.parse(text); } catch (_) { report('unsupported',{message:'JanitorAI sent a request format this injector could not read.'}); return null; }
    if (!body || typeof body !== 'object' || Array.isArray(body)) { report('unsupported',{message:'JanitorAI sent a request format this injector could not read.'}); return null; }
    const context = memoryText(nodes);
    const found = findMessageArray(body);
    if (found) {
      const list = found.owner[found.key];
      if (list.some(message => typeof message.content === 'string' && message.content.includes(MARKER))) return null;
      let insertAt = 0;
      while (insertAt < list.length && ['system','developer'].includes(String(list[insertAt]?.role || '').toLowerCase())) insertAt++;
      list.splice(insertAt,0,{role:'system',content:context});
    } else {
      report('unsupported',{message:'Generation request detected, but it had no messages array. Nothing was pasted into the chat box.'});
      return null;
    }
    lastInjectedIndex = position;
    report('applied',{messageIndex:position,nodeCount:nodes.length,sceneIncluded:Boolean(scene),message:`Injected ${nodes.length} selected memor${nodes.length===1?'y':'ies'}${scene?' and the current scene':''} as hidden system context.`});
    return JSON.stringify(body);
  }

  window.addEventListener('message',event => {
    if (event.source !== window || event.origin !== location.origin || event.data?.channel !== CHANNEL || event.data?.kind !== 'config') return;
    const d = event.data;
    if (typeof d.chatId !== 'string' || ![10,15,20].includes(Number(d.interval))) return;
    const previous = JSON.stringify(config);
    const changedChat = config?.chatId !== d.chatId;
    if (changedChat) lastInjectedIndex = -1;
    config = {chatId:d.chatId,enabled:d.enabled===true,interval:Number(d.interval),nodes:cleanNodes(d.nodes),scene:cleanScene(d.scene)};
    const saved = Number(d.lastInjectionIndex);
    if (Number.isSafeInteger(saved) && saved >= 0) lastInjectedIndex = changedChat ? saved : Math.max(lastInjectedIndex,saved);
    if (d.checkId || JSON.stringify(config)!==previous) report('ready',{checkId:d.checkId,message:config.enabled&&(config.nodes.length||config.scene)?'Hidden request hook connected.':'Hook connected; enable auto-injection and select memories or save a Current Scene.'});
  });

  const originalFetch = window.fetch;
  window.fetch = function(input,init) {
    const args = arguments;
    let rawUrl,method,body;
    try {
      rawUrl = typeof input === 'string' ? input : input?.url;
      method = String(init?.method || input?.method || 'GET').toUpperCase();
      body = init?.body;
      if (typeof body === 'string') {
        const patched = patchJson(body,rawUrl,method);
        if (patched) return originalFetch.call(this,input,{...init,body:patched});
      } else if (input instanceof Request && body == null && eligibleUrl(rawUrl,method)) {
        const self = this;
        return input.clone().text().then(text => {
          const patched = patchJson(text,rawUrl,method);
          return patched ? originalFetch.call(self,new Request(input,{body:patched})) : originalFetch.apply(self,args);
        }).catch(() => originalFetch.apply(self,args));
      }
    } catch (_) {}
    return originalFetch.apply(this,args);
  };

  const xhr = XMLHttpRequest.prototype;
  const originalOpen = xhr.open;
  xhr.open = function(method,url) {
    this.__aureliusJllmUrl = url;
    this.__aureliusJllmMethod = String(method || 'GET').toUpperCase();
    return originalOpen.apply(this,arguments);
  };
  const originalSend = xhr.send;
  xhr.send = function(body) {
    try {
      const patched = patchJson(body,this.__aureliusJllmUrl,this.__aureliusJllmMethod);
      return originalSend.call(this,patched || body);
    } catch (_) { return originalSend.apply(this,arguments); }
  };
})();
