// Aurelius Rising: standalone page-context, opt-in, one-request DJAI bridge.
(() => {
  'use strict';
  if (window.__aureliusDjaiBridge054) return;
  window.__aureliusDjaiBridge054 = true;
  const CHANNEL = 'aurelius-djai-054';
  let pending = null;
  let status = 'not armed';
  const originalFetch = window.fetch;
  const currentSession = () => location.pathname.match(/^\/app\/session\/([^/]+)/)?.[1] || null;
  function rewriteBody(rawBody, armed) {
    if (pending !== armed) return null;
    const {text:extra,limit,session:armedSession} = armed;
    pending = null;
    if (armedSession && armedSession !== currentSession()) {
      status = 'cancelled: active chat changed before the request';
      return null;
    }
    try {
      if (typeof rawBody !== 'string') throw Error('Unsupported chat request body');
      const body = JSON.parse(rawBody);
      if (!body || typeof body !== 'object' || Array.isArray(body)) throw Error('Unexpected chat payload');
      if (body.director != null && (typeof body.director !== 'object' || Array.isArray(body.director))) throw Error('Unexpected director format');
      const director = body.director || {};
      const prior = director.instruction;
      if (prior != null && typeof prior !== 'string') throw Error('Unexpected instruction format');
      const merged = (prior ? prior + '\n\n' : '') + extra;
      if (merged.length > limit) throw Error('Combined instruction '+merged.length+' characters exceeds selected '+limit+'-character ceiling');
      body.director = {...director, instruction: merged};
      status = 'modified outgoing request (server/model acceptance unverified)';
      return JSON.stringify(body);
    } catch (err) {
      status = 'skipped: ' + err.message;
      return null;
    }
  }
  function sendChat(receiver, args, injected = false) {
    const session = currentSession();
    const request = originalFetch.apply(receiver, args);
    if (session) {
      void request.then(response => {
        if (response.ok) window.postMessage({channel: CHANNEL, kind: 'chat-completed', session, injected}, location.origin);
      }, () => {});
    }
    return request;
  }
  window.fetch = function(input, init) {
    let url;
    try { url = new URL(typeof input === 'string' ? input : input?.url, location.href); }
    catch (_) { return originalFetch.apply(this, arguments); }
    if (url.origin !== location.origin || url.pathname !== '/api/chat' ||
        (init?.method || input?.method || 'GET').toUpperCase() !== 'POST') {
      return originalFetch.apply(this, arguments);
    }
    if (!pending) return sendChat(this, arguments);
    const armed=pending, receiver=this, args=arguments;
    if (typeof init?.body === 'string') {
      const body=rewriteBody(init.body,armed);
      return body ? sendChat(receiver,[input,{...init,body}],true) : sendChat(receiver,args);
    }
    if(input instanceof Request && init?.body == null){
      return input.clone().text().then(raw=>{
        const body=rewriteBody(raw,armed);
        if(!body)return sendChat(receiver,args);
        return sendChat(receiver,[new Request(input,{...init,body})],true);
      }).catch(error=>{
        if(pending===armed){pending=null;status='skipped: '+error.message;}
        return sendChat(receiver,args);
      });
    }
    const body=rewriteBody(init?.body,armed);
    return body ? sendChat(receiver,[input,{...init,body}],true) : sendChat(receiver,args);
  };
  async function importCurrentNexus(id, requestedSession) {
    const sid = currentSession();
    try {
      if (!sid) throw new Error('Open a DreamJourney chat before importing its Nexus.');
      if (requestedSession && requestedSession !== sid) throw new Error('The active chat changed. Reopen Aurelius and retry.');
      const response = await originalFetch.call(window,
        '/api/nexus?sessionId=' + encodeURIComponent(sid),
        {method:'GET', credentials:'include', cache:'no-store'});
      if (!response.ok) throw new Error('DreamJourney Nexus request failed (HTTP ' + response.status + ').');
      const rawText = await response.text();
      if (rawText.length > 15 * 1024 * 1024) throw new Error('Nexus response exceeds the 15 MB import limit.');
      let raw;
      try { raw = JSON.parse(rawText); }
      catch (_) { throw new Error('DreamJourney returned a response that was not valid Nexus JSON.'); }
      if (!raw || raw.error || raw.success === false || raw.ok === false) throw new Error('DreamJourney returned a Nexus error instead of a snapshot.');
      const entities = Array.isArray(raw) ? raw : raw.entities;
      if (!Array.isArray(entities) || entities.some(entity => !entity || typeof entity !== 'object' || Array.isArray(entity) || typeof entity.name !== 'string')) {
        throw new Error('The response did not contain a recognizable Nexus entity list.');
      }
      if (sid !== currentSession()) throw new Error('The active chat changed while Aurelius was reading its Nexus. Nothing was imported.');
      window.postMessage({channel:CHANNEL,kind:'reply',id,ok:true,status:'Read ' + entities.length + ' Nexus entities from the active DreamJourney chat.',entities},location.origin);
    } catch (error) {
      window.postMessage({channel:CHANNEL,kind:'reply',id,ok:false,status:String(error.message || error)},location.origin);
    }
  }
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== location.origin || event.data?.channel !== CHANNEL || event.data?.kind !== 'command') return;
    const {id, action, text, limit, session} = event.data;
    let ok = true;
    if (action === 'import-nexus') {
      void importCurrentNexus(id, session);
      return;
    } else if (action === 'arm') {
      if (pending) { ok = false; status = 'Already armed. Cancel before rearming.'; }
      else if (session && session !== currentSession()) { ok = false; status = 'Active chat changed before arming; reopen the panel and retry.'; }
      else if (typeof text !== 'string' || !text.trim()) { ok = false; status = 'Empty injection instruction'; }
      else if (![500,1000,2000,4000,8000,16000,32000,50000,100000].includes(limit)) { ok = false; status = 'Invalid experimental ceiling'; }
      else if (text.length > limit) { ok = false; status = 'Injector context exceeds selected ceiling'; }
      else { pending = {text,limit,session:session||currentSession()}; status = 'armed (ceiling '+limit+' characters)'; }
    } else if (action === 'cancel') { pending = null; status = 'cancelled'; }
    else if (action !== 'check') { ok = false; status = 'Unknown command'; }
    window.postMessage({channel: CHANNEL, kind: 'reply', id, ok, status, active: !!pending}, location.origin);
  });
})();
