// Aurelius Rising — scheduled, user-controlled ChatGPT reminders.
// Never modifies model system prompts. Auto-send is explicitly opt-in and off by default.
(() => {
  const MARKER = '[Aurelius Rising behavior reminder]';
  const STATE_PREFIX = 'aurelius:injection:';
  const settingsKeys = ['instruction', 'interval', 'autoInjection', 'autoSend', 'behaviorModules'];
  let settings = { instruction: '', interval: 5, autoInjection: false, autoSend: false };
  let moduleStates = {};
  let busy = false;
  let lastRoute = '';

  const routeId = () => location.pathname.match(/^\/c\/([^/?#]+)/)?.[1] || null;
  const editor = () => [...document.querySelectorAll(
    '#prompt-textarea, [data-testid="composer-input"], [contenteditable="true"][role="textbox"], main [contenteditable="true"]'
  )].find(node => node.isConnected && (node.isContentEditable || node.matches('textarea')) &&
    node.getClientRects().length > 0);
  const textOf = node => (node?.matches?.('textarea') ? node.value : (node?.innerText || node?.textContent || '')).trim();

  // Identify individual modules so a combined reminder can be added to a partial draft.
  const headerPattern = /^\[Aurelius Rising — ([^\]\n]+)\]$/gm;
  function sections(payload) {
    const source = String(payload || '').trim();
    const matches = [...source.matchAll(headerPattern)];
    if (!matches.length) return source ? [{ key: 'custom:' + source, body: source }] : [];
    return matches.map((match, i) => ({
      key: match[1].trim().toLowerCase(),
      body: source.slice(match.index, i + 1 < matches.length ? matches[i + 1].index : source.length).trim()
    })).filter(section => !/^\d+ enabled behavioral modules?$/.test(section.key));
  }

  function insertDraft(instruction) {
    const target = editor();
    if (!target) return { ok: false, error: 'ChatGPT composer not found. Open a conversation and refresh the tab.' };
    const existing = textOf(target);
    const known = new Set([...existing.matchAll(headerPattern)].map(match => match[1].trim().toLowerCase()));
    const requested = sections(instruction);
    const unique = requested.filter(section => !known.has(section.key));
    if (!unique.length) return { ok: true, added: 0, skipped: requested.length, message: 'Those modules are already in the draft.' };
    const alreadyMarked = existing.includes(MARKER);
    const addition = `${existing ? '\n\n' : ''}${alreadyMarked ? '' : MARKER + '\n'}${unique.map(section => section.body).join('\n\n')}`;
    target.focus();
    if (target.matches('textarea')) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
      const updated = (target.value || '') + addition;
      if (setter) setter.call(target, updated); else target.value = updated;
      target.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(target);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);
      let inserted = false;
      try { inserted = document.execCommand('insertText', false, addition); } catch (_) {}
      if (!inserted || !textOf(target).includes(unique[0].body.split('\n')[0])) {
        // Fallback only if normal insertion failed; never clear existing draft.
        const paragraph = document.createElement('p');
        paragraph.textContent = addition;
        target.appendChild(paragraph);
      }
      target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: addition }));
    }
    const accepted = unique.every(section => textOf(target).includes(section.body.split('\n')[0]));
    if (accepted) window.dispatchEvent(new Event('aurelius:analytics-context-inserted'));
    return accepted
      ? { ok: true, added: unique.length, skipped: requested.length - unique.length }
      : { ok: false, error: 'Composer did not accept the text. Nothing was sent.' };
  }

  function sendButton() {
    return document.querySelector('button[data-testid="send-button"]') ||
      document.querySelector('button[aria-label="Send prompt"]');
  }

  async function reloadSettings() {
    const saved = await chrome.storage.local.get(settingsKeys);
    settings = {
      instruction: String(saved.instruction || '').trim(),
      interval: Number(saved.interval) || 5,
      autoInjection: saved.autoInjection === true,
      autoSend: saved.autoSend === true
    };
    moduleStates = saved.behaviorModules && typeof saved.behaviorModules === 'object' ? saved.behaviorModules : {};
  }

  // A single per-conversation countdown, anchored when auto-injection is enabled.
  // Existing installations initialize from their current count, not historical modulo.
  async function check() {
    if (busy || !settings.autoInjection) return;
    const id = routeId();
    if (!id) return;
    busy = true;
    try {
      const counts = await new Promise(resolve => {
        window.dispatchEvent(new CustomEvent('aurelius:counts-request', { detail: { respond: resolve } }));
      });
      const user = Number(counts?.user);
      if (!Number.isSafeInteger(user) || user < 0 || routeId() !== id) return;
      const interval = Number(settings.interval);
      if (!Number.isSafeInteger(interval) || interval < 1) return;
      const key = STATE_PREFIX + id;
      const stored = await chrome.storage.local.get([key, 'autoInjectionEpoch']);
      const epoch = Number(stored.autoInjectionEpoch) || 0;
      const previous = stored[key];
      if (!previous || previous.version !== 2 || previous.epoch !== epoch) {
        await chrome.storage.local.set({ [key]: { version: 2, epoch, baseline: user, lastCycle: 0 } });
        return; // Enabling injection must not immediately send an overdue reminder.
      }
      // A counter reset or conversation deletion starts a fresh countdown.
      if (user < previous.baseline) {
        await chrome.storage.local.set({ [key]: { version: 2, epoch, baseline: user, lastCycle: 0 } });
        return;
      }
      const cycle = Math.floor((user - previous.baseline) / interval);
      if (cycle < 1 || cycle <= previous.lastCycle) return;
      const due = [];
      if (settings.instruction) due.push(`[Aurelius Rising — custom behavior reminder]\n${settings.instruction}`);
      for (const [moduleId, module] of Object.entries(moduleStates)) {
        if (!module || module.enabled !== true || module.mode !== 'recurring' || !String(module.instruction || '').trim()) continue;
        const content = [`[Aurelius Rising — ${moduleId} behavioral module]`, String(module.instruction).trim()];
        if (module.includeContext === true) {
          if (module.reason) content.push(`Reason: ${String(module.reason).trim()}`);
          if (module.example) content.push(`Example: ${String(module.example).trim()}`);
        }
        due.push(content.join('\n'));
      }
      if (!due.length) return;
      const target = editor();
      if (!target || textOf(target).includes(MARKER)) return;
      if (settings.autoSend && textOf(target)) return;
      const result = insertDraft(due.join('\n\n'));
      if (!result.ok) return;
      await chrome.storage.local.set({ [key]: { ...previous, lastCycle: cycle } });
      if (settings.autoSend && routeId() === id) {
        await new Promise(resolve => setTimeout(resolve, 200));
        const button = sendButton();
        if (routeId() === id && button && !button.disabled && textOf(editor()).includes(MARKER)) button.click();
        else console.info('[Aurelius Rising] Reminder inserted for review; Send was unavailable.');
      }
    } catch (error) {
      console.warn('[Aurelius Rising] Automatic reminder check failed:', error);
    } finally { busy = false; }
  }

  // Manual insertion never sends, regardless of auto-send setting.
  chrome.runtime.onMessage.addListener((request, sender, reply) => {
    if (request?.type !== 'AURELIUS_INSERT_DRAFT') return;
    const instruction = String(request.instruction || '').trim();
    if (instruction.length > 6000) { reply({ok:false,error:'Draft exceeds the safe 6,000-character insertion limit. Reduce context or copy the payload.'}); return; }
    reply(instruction ? insertDraft(instruction) : { ok: false, error: 'Enter an instruction first.' });
  });

  chrome.runtime.onMessage.addListener((request,sender,reply)=>{
    if(request?.type!=='AURELIUS_ATTACH_FILES')return;
    try{
      const input=[...document.querySelectorAll('input[type="file"]')].find(e=>!e.disabled);
      if(!input){reply({ok:false,error:'ChatGPT file input was not available. Open the attachment menu, then retry or use manual upload.'});return;}
      const transfer=new DataTransfer();
      for(const item of request.files||[]){if(!item.name||!Array.isArray(item.bytes))throw Error('Invalid attachment');transfer.items.add(new File([new Uint8Array(item.bytes)],item.name,{type:item.type||'text/plain'}));}
      input.files=transfer.files;input.dispatchEvent(new Event('change',{bubbles:true}));
      reply({ok:true,attempted:transfer.files.length});
    }catch(e){reply({ok:false,error:'Browser rejected file handoff. Use ChatGPT manual upload: '+e.message});}
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && settingsKeys.some(key => key in changes)) {
      void reloadSettings().then(check);
    }
  });
  void reloadSettings().then(check);
  setInterval(() => {
    const id = routeId();
    if (id !== lastRoute) lastRoute = id;
    void check();
  }, 1500);
})();
