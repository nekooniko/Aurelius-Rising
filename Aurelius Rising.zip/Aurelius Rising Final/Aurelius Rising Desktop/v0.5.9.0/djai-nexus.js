// Aurelius Rising 0.5.7 — local Nexus selection and opt-in Director injection.
(() => {
  const $ = id => document.getElementById(id);
  let nodes = [], selected = new Set(), selectedFacts = new Set();
  let presets = {}, activePreset = '';
  const LIBRARY_KEY = 'aureliusNexusLibrary057';
  const PRESETS_KEY = 'aureliusNexusPresets057';
  const SELECTION_KEY = 'aureliusNexusSelection057';
  const LIMIT_KEY = 'aureliusDjaiLimit057';
  const INCLUDE_NEXUS_KEY = 'aureliusDjaiIncludeNexus057';
  const SCENE_KEY_PREFIX = 'aureliusDjaiCurrentScene059:';
  async function sceneStorageKey(){
    const fromFrame=new URLSearchParams(location.search).get('session');
    if(fromFrame)return SCENE_KEY_PREFIX+fromFrame;
    try{
      const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
      const session=tab?.url?.match(/\/app\/session\/([^/?#]+)/)?.[1];
      if(session)return SCENE_KEY_PREFIX+session;
    }catch(_){}
    return SCENE_KEY_PREFIX+'unscoped';
  }
  const MAX_PRESETS = 100;
  let saveTimer;
  const setLibraryStatus = message => { $('nexus-status').textContent = message; };
  async function saveSelection(){
    try { await chrome.storage.local.set({[SELECTION_KEY]: {nodes:[...selected],facts:[...selectedFacts]}}); }
    catch(e){setLibraryStatus('Selection could not be saved: '+e.message);}
  }
  function queueSelectionSave(){clearTimeout(saveTimer);saveTimer=setTimeout(saveSelection,200);}
  async function saveLibrary(){
    try {
      // Preserve only the imported source fields; _key/name/type are rebuilt when loading.
      const clean=nodes.map(({_key,...n})=>n);
      await chrome.storage.local.set({[LIBRARY_KEY]:clean});
      setLibraryStatus(`Saved ${nodes.length} Nexus nodes locally. They will reload automatically.`);
      return true;
    } catch(e){setLibraryStatus('Imported for this session, but persistent save failed (possibly storage quota): '+e.message);return false;}
  }
  function presetOptions(){
    const el=$('nexus-preset-select'); const previous=el.value;el.replaceChildren();
    const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Choose a saved fact group';el.append(placeholder);
    for(const name of Object.keys(presets).sort((a,b)=>a.localeCompare(b))){const option=document.createElement('option');option.value=name;option.textContent=name;el.append(option);}
    if(presets[previous])el.value=previous;
  }
  function presetStatus(message){$('nexus-preset-status').textContent=message;}
  // Presets identify whole Nexus entries by their displayed [Type] Name.
  // The current imported entry is always authoritative, including edited facts.
  const normalized = value => String(value ?? '').normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase();
  const displayRef = node => `[${node.type}] ${node.name}`;
  function resolveEntry(ref){
    if(typeof ref !== 'string')return null;
    const matches=nodes.filter(node=>normalized(displayRef(node))===normalized(ref));
    return matches.length===1 ? matches[0] : null; // Never silently choose ambiguous names.
  }
  function namedPreset(){
    const byKey=new Map(nodes.map(n=>[n._key,n]));
    const refs=new Set();
    for(const key of selected){const n=byKey.get(key);if(n)refs.add(displayRef(n));}
    // A preset is a set of named entries, even if individual facts were checked.
    for(const key of selectedFacts){
      const i=String(key).lastIndexOf('::');
      const n=i<0?null:byKey.get(String(key).slice(0,i));
      if(n)refs.add(displayRef(n));
    }
    return {version:3,entries:[...refs]};
  }
  function migratePresets(){
    if(!nodes.length)return false; // Wait for original library to be available.
    let changed=false;
    const byKey=new Map(nodes.map(n=>[n._key,n]));
    for(const [name,group] of Object.entries(presets)){
      if(!group || group.version===3)continue;
      const refs=new Set();const missing=[];
      if(group.version===2){
        for(const ref of [...(group.nodes||[]),...(group.facts||[]).map(f=>f?.node)]){
          if(!ref)continue;
          const matches=nodes.filter(n=>normalized(n.type)===normalized(ref.type)&&normalized(n.name)===normalized(ref.name));
          const n=matches.length===1?matches[0]:matches.find(n=>String(n.id??'')===String(ref.id??''));
          if(n)refs.add(displayRef(n));else missing.push(`[${ref.type}] ${ref.name}`);
        }
        for(const key of group.unresolvedLegacy?.nodes||[])missing.push('Legacy node: '+key);
        for(const key of group.unresolvedLegacy?.facts||[])missing.push('Legacy fact: '+key);
      }else{
        for(const key of group.nodes||[]){const n=byKey.get(String(key));if(n)refs.add(displayRef(n));else missing.push('Legacy node: '+key);}
        for(const key of group.facts||[]){const cut=String(key).lastIndexOf('::');const n=cut<0?null:byKey.get(String(key).slice(0,cut));if(n)refs.add(displayRef(n));else missing.push('Legacy fact: '+key);}
      }
      presets[name]={version:3,entries:[...refs],unresolved:missing};changed=true;
    }
    return changed;
  }
  async function savePresets(){await chrome.storage.local.set({[PRESETS_KEY]:presets});}
  function downloadPresets(){
    const blob=new Blob([JSON.stringify({format:'aurelius-rising-presets',version:3,presets},null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='aurelius-rising-presets.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }

  async function loadSaved(){
    try {
      const data=await chrome.storage.local.get([LIBRARY_KEY,PRESETS_KEY,SELECTION_KEY,LIMIT_KEY,INCLUDE_NEXUS_KEY]);
      if(Array.isArray(data[LIBRARY_KEY]))nodes=extract(data[LIBRARY_KEY]);
      const selection=data[SELECTION_KEY]||{};
      const keys=new Set(nodes.map(n=>n._key));
      selected=new Set((selection.nodes||[]).filter(k=>keys.has(k)));
      selectedFacts=new Set((selection.facts||[]).filter(k=>keys.has(String(k).split('::')[0])));
      const hasSavedInclusion=Object.prototype.hasOwnProperty.call(data,INCLUDE_NEXUS_KEY);
      includeNexus.checked=hasSavedInclusion ? Boolean(data[INCLUDE_NEXUS_KEY]) : Boolean(selected.size||selectedFacts.size);
      if(!hasSavedInclusion)await chrome.storage.local.set({[INCLUDE_NEXUS_KEY]:includeNexus.checked});
      if(data[PRESETS_KEY] && typeof data[PRESETS_KEY]==='object' && !Array.isArray(data[PRESETS_KEY]))presets=data[PRESETS_KEY];
      if(data[LIMIT_KEY] && [...$('djai-limit').options].some(o=>o.value===String(data[LIMIT_KEY])))$('djai-limit').value=String(data[LIMIT_KEY]);
      if(migratePresets())await savePresets();
      presetOptions();render();
      if(nodes.length)setLibraryStatus(`Restored ${nodes.length} locally saved Nexus nodes.`);
    } catch(e){setLibraryStatus('Could not restore saved library: '+e.message);}
  }
  const factKey=(node,index)=>node._key+"::"+index;
  const maxBytes = 15 * 1024 * 1024;
  function platform(name) {
    $('chatgpt-panel').hidden = name !== 'chatgpt';
    $('djai-panel').hidden = name !== 'djai';
    $('jllm-panel').hidden = name !== 'jllm';
    for (const key of ['chatgpt','djai','jllm']) {
      $('tab-'+key).classList.toggle('active',key===name);
      $('tab-'+key).setAttribute('aria-selected',String(key===name));
    }
    if(location.hash !== '#djai-floating') chrome.storage.local.set({aureliusPlatform:name});
  }
  $('tab-chatgpt').addEventListener('click',()=>platform('chatgpt'));
  $('tab-djai').addEventListener('click',()=>platform('djai'));
  $('tab-jllm').addEventListener('click',()=>platform('jllm'));
  if(location.hash==='#djai-floating')platform('djai');else chrome.storage.local.get('aureliusPlatform').then(v=>platform(['chatgpt','djai','jllm'].includes(v.aureliusPlatform)?v.aureliusPlatform:'chatgpt'));
  function extract(data) {
    // Aster Nexus exports commonly use an object with an entities array.
    const array = Array.isArray(data) ? data : (Array.isArray(data?.entities) ? data.entities : (Array.isArray(data?.nodes) ? data.nodes : null));
    if (!array) throw new Error('Expected a JSON array, or an object with an entities/nodes array.');
    return array.filter(n=>n&&typeof n==='object').map((n,i)=>({
      ...n, _key:String(n.id??`index-${i}`), name:String(n.name??n.title??`Node ${i+1}`), type:String(n.type??'unknown')
    }));
  }
  function shown(){const q=$('nexus-search').value.toLowerCase().trim();return nodes.filter(n=>(n.name+' '+n.type).toLowerCase().includes(q));}
  function payload(){
    const blocks=[];
    for(const n of nodes){
      const whole=selected.has(n._key);
      const facts=Array.isArray(n.facts)?n.facts:[];
      const chosen=facts.map((f,i)=>({f,i})).filter(({i})=>whole||selectedFacts.has(factKey(n,i)));
      if(!whole&&!chosen.length)continue;
      const lines=[`[${n.type}] ${n.name}`];
      if(whole){
        if(n.description)lines.push('Description: '+n.description);
        if(Array.isArray(n.relationships))for(const r of n.relationships)if(r?.targetName)lines.push(`Relationship — ${r.targetName}: ${r.relationship??''}`);
      }
      for(const {f} of chosen){const value=typeof f==='string'?f:f?.fact;if(value)lines.push('- '+value);}
      blocks.push(lines.join('\n'));
    }
    return blocks.length?'[Selected Nexus context]\n'+blocks.join('\n\n'):'';
  }
  function update(){const v=payload();$('nexus-payload').value=v;$('nexus-count').textContent=`${nodes.length} nodes imported · ${selected.size} full nodes · ${selectedFacts.size} individually selected facts`;$('nexus-size').textContent=`${v.length} characters in preview`;updateInjectionSize();}
  function render(){const list=$('nexus-list');list.replaceChildren();for(const n of shown().slice(0,500)){
    const wrap=document.createElement('div');wrap.className='nexus-node';wrap.style.display='block';
    const label=document.createElement('label');label.style.display='flex';label.style.gap='8px';
    const check=document.createElement('input');check.type='checkbox';check.checked=selected.has(n._key);
    check.addEventListener('change',()=>{check.checked?selected.add(n._key):selected.delete(n._key);update();render();queueSelectionSave()});
    const content=document.createElement('span');content.textContent=n.name+' · '+n.type+' · '+(Array.isArray(n.facts)?n.facts.length:0)+' facts';label.append(check,content);wrap.append(label);
    if(Array.isArray(n.facts)&&n.facts.length){const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent='Choose individual facts';details.append(summary);
      for(let i=0;i<n.facts.length;i++){const f=n.facts[i];const value=typeof f==='string'?f:f?.fact;if(!value)continue;const item=document.createElement('label');item.style.display='flex';item.style.gap='8px';item.style.margin='6px 0';const box=document.createElement('input');box.type='checkbox';box.checked=selectedFacts.has(factKey(n,i))||selected.has(n._key);box.disabled=selected.has(n._key);box.addEventListener('change',()=>{box.checked?selectedFacts.add(factKey(n,i)):selectedFacts.delete(factKey(n,i));update();queueSelectionSave()});const t=document.createElement('span');t.textContent=value;item.append(box,t);details.append(item)}wrap.append(details)}list.append(wrap);
  }update()}
  $('nexus-file').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;
    if(file.size>maxBytes){$('nexus-status').textContent='File exceeds the 15 MB import limit.';return}
    try{if(migratePresets())await savePresets();nodes=extract(JSON.parse(await file.text()));if(migratePresets())await savePresets();selected.clear();selectedFacts.clear();setLibraryStatus(`Imported ${nodes.length} nodes. Saving locally…`);render();await saveLibrary();await saveSelection()}
    catch(err){nodes=[];selected.clear();selectedFacts.clear();$('nexus-status').textContent='Import failed: '+err.message;render()}
  });
  function factText(f){return typeof f==='string'?f:String(f?.fact??'');}
  function carrySelection(oldNodes,nextNodes,oldSelected,oldSelectedFacts){
    const oldByKey=new Map(oldNodes.map(n=>[n._key,n])), nextByKey=new Map(nextNodes.map(n=>[n._key,n]));
    const nextByRef=new Map();
    for(const node of nextNodes){const ref=normalized(displayRef(node));if(!nextByRef.has(ref))nextByRef.set(ref,[]);nextByRef.get(ref).push(node);}
    const remap=oldKey=>{
      const oldNode=oldByKey.get(oldKey);if(!oldNode)return null;
      if(oldNode.id!=null)return nextByKey.has(oldKey)?oldKey:null;
      const matches=nextByRef.get(normalized(displayRef(oldNode)))||[];
      return matches.length===1?matches[0]._key:null;
    };
    const keptNodes=new Set();
    for(const key of oldSelected){const nextKey=remap(key);if(nextKey)keptNodes.add(nextKey);}
    const keptFacts=new Set();
    for(const key of oldSelectedFacts){
      const cut=String(key).lastIndexOf('::'), oldKey=String(key).slice(0,cut), oldIndex=Number(String(key).slice(cut+2));
      const oldNode=oldByKey.get(oldKey), nextKey=remap(oldKey), nextNode=nextKey&&nextByKey.get(nextKey);
      if(!oldNode||!nextNode||!Number.isInteger(oldIndex))continue;
      const oldFact=factText((oldNode.facts||[])[oldIndex]);if(!oldFact)continue;
      const facts=Array.isArray(nextNode.facts)?nextNode.facts:[];
      let nextIndex=oldIndex;
      if(factText(facts[nextIndex])!==oldFact)nextIndex=facts.findIndex(f=>factText(f)===oldFact);
      if(nextIndex>=0&&nextIndex<facts.length)keptFacts.add(factKey(nextNode,nextIndex));
    }
    return {nodes:keptNodes,facts:keptFacts};
  }
  $('nexus-sync').addEventListener('click',async()=>{
    const button=$('nexus-sync'),original=button.textContent;
    button.disabled=true;button.textContent='Reading DreamJourney Nexus…';
    setLibraryStatus('Reading the Nexus from the active DreamJourney chat. This does not change the chat.');
    try{
      const result=await aureliusDjaiCommand('import-nexus');
      if(!result?.ok)throw new Error(result?.status||'DreamJourney could not provide the current Nexus.');
      const nextNodes=extract({entities:result.entities});
      if(!nextNodes.length)throw new Error('The current Nexus contains no entities; the saved library was left unchanged.');
      if(migratePresets())await savePresets();
      const oldNodes=nodes,oldSelected=new Set(selected),oldSelectedFacts=new Set(selectedFacts);
      const carried=carrySelection(oldNodes,nextNodes,oldSelected,oldSelectedFacts);
      const clean=nextNodes.map(({_key,...node})=>node);
      await chrome.storage.local.set({[LIBRARY_KEY]:clean});
      nodes=nextNodes;selected=carried.nodes;selectedFacts=carried.facts;
      if(migratePresets())await savePresets();
      render();await saveSelection();
      setLibraryStatus(`Imported ${nodes.length} Nexus entities from this DreamJourney chat. The local library was updated in place; matching selections and saved presets were kept.`);
    }catch(error){setLibraryStatus('Direct Nexus import failed: '+String(error.message||error)+' The existing saved library was left unchanged.');}
    finally{button.disabled=false;button.textContent=original;}
  });
  $('nexus-search').addEventListener('input',render);
  $('nexus-all').addEventListener('click',()=>{for(const n of shown())selected.add(n._key);render();queueSelectionSave()});
  $('nexus-none').addEventListener('click',()=>{selected.clear();selectedFacts.clear();render();queueSelectionSave()});
  $('nexus-preset-save').addEventListener('click',async()=>{
    const name=$('nexus-preset-name').value.trim();
    if(!name || name.length>80){presetStatus('Enter a preset name (1–80 characters).');return;}
    if(!selected.size && !selectedFacts.size){presetStatus('Select at least one node or fact first.');return;}
    if(!presets[name] && Object.keys(presets).length>=MAX_PRESETS){presetStatus('Maximum 100 presets reached. Delete one first.');return;}
    const old=presets[name];presets[name]=namedPreset();
    try{await savePresets();presetOptions();$('nexus-preset-select').value=name;presetStatus(`Saved “${name}” by Nexus entry names (full current entries load automatically).`);}
    catch(e){if(old)presets[name]=old;else delete presets[name];presetStatus('Could not save preset: '+e.message);}
  });
  $('nexus-preset-load').addEventListener('click',async()=>{
    const name=$('nexus-preset-select').value, group=presets[name];
    if(!group){presetStatus('Choose a saved fact group.');return;}
    if(group.version!==3){presetStatus('Restore the original Nexus to migrate this older preset.');return;}
    const found=[],missing=[];
    for(const ref of group.entries||[]){const node=resolveEntry(ref);if(node)found.push(node);else missing.push(ref);}
    selected=new Set(found.map(n=>n._key));selectedFacts.clear();
    render();await saveSelection();
    const totalMissing=missing.length+(group.unresolved||[]).length;
    presetStatus(`Loaded “${name}”: ${selected.size} complete current Nexus entries.${totalMissing?` ${totalMissing} missing/ambiguous reference(s): ${[...missing,...(group.unresolved||[])].slice(0,8).join(', ')}${totalMissing>8?'…':''}. Preset preserved.`:' All entries matched.'}`);
  });
  $('nexus-preset-export').addEventListener('click',()=>{try{downloadPresets();presetStatus('Preset backup prepared for download.');}catch(e){presetStatus('Export failed: '+e.message);}});
  $('nexus-preset-import').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{
      if(file.size>2*1024*1024)throw new Error('Preset backup exceeds 2 MB.');
      const parsed=JSON.parse(await file.text());
      if(parsed?.format!=='aurelius-rising-presets'||![2,3].includes(parsed.version)||!parsed.presets||typeof parsed.presets!=='object'||Array.isArray(parsed.presets))throw new Error('Not a supported Aurelius Rising preset backup.');
      const entries=Object.entries(parsed.presets);
      if(entries.length>MAX_PRESETS)throw new Error('Backup contains too many presets.');
      for(const [name,group] of entries){
        if(!name.trim()||name.length>80||!group||![2,3].includes(group.version))throw new Error('Invalid preset: '+name);
        if(group.version===3 && (!Array.isArray(group.entries)||group.entries.some(x=>typeof x!=='string'||x.length>300)))throw new Error('Invalid named entries in preset: '+name);
        if(group.version===2 && (!Array.isArray(group.nodes)||!Array.isArray(group.facts)))throw new Error('Invalid older preset: '+name);
      }
      const merged={...presets,...parsed.presets};if(Object.keys(merged).length>MAX_PRESETS)throw new Error('Combined presets exceed the 100-preset limit.');
      const old=presets;presets=merged;
      migratePresets();
      try{await savePresets();}catch(e){presets=old;throw e;}
      presetOptions();presetStatus(`Imported ${entries.length} preset(s). Same-name backups replace local versions. Older presets migrate when their original Nexus is available.`);
    }catch(e){presetStatus('Preset import failed: '+e.message);}finally{e.target.value='';}
  });
  $('nexus-preset-delete').addEventListener('click',async()=>{
    const name=$('nexus-preset-select').value;
    if(!presets[name]){presetStatus('Choose a saved fact group.');return;}
    const old=presets[name];delete presets[name];
    try{await savePresets();presetOptions();presetStatus(`Deleted preset “${name}”. The Nexus library remains saved.`);}
    catch(e){presets[name]=old;presetOptions();presetStatus('Could not delete preset: '+e.message);}
  });
  $('nexus-forget-library').addEventListener('click',async()=>{
    if(!confirm('Remove the locally saved Nexus library and current selection? Named presets will remain saved.'))return;
    try{await chrome.storage.local.remove([LIBRARY_KEY,SELECTION_KEY]);nodes=[];selected.clear();selectedFacts.clear();$('nexus-file').value='';render();setLibraryStatus('Saved Nexus library cleared. Named presets were kept.');}
    catch(e){setLibraryStatus('Could not clear saved library: '+e.message);}
  });
  $('nexus-copy').addEventListener('click',async()=>{
    if(!payload()){$('nexus-copy-status').textContent='Select at least one node first.';return}
    try{await navigator.clipboard.writeText(payload());$('nexus-copy-status').textContent='Context copied. No message was sent.'}
    catch(err){$('nexus-copy-status').textContent='Clipboard unavailable; select and copy from the preview.'}
  });


// v0.5.6: popup talks to persistent DJAI content script, not MAIN-world executeScript.
async function aureliusCurrentTab(){
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id || !/^https:\/\/(?:www\.)?dreamjourneyai\.com\/app\/session\//.test(tab.url||''))throw new Error('Open a DreamJourney AI session tab first.');
  return tab.id;
}
async function aureliusDjaiCommand(action,text,limit){
  let session=new URLSearchParams(location.search).get('session');
  let bridge=new URLSearchParams(location.search).get('bridge');
  if(!session||session==='unscoped'){
    const [active]=await chrome.tabs.query({active:true,currentWindow:true});
    session=active?.url?.match(/\/app\/session\/([^/?#]+)/)?.[1]||session;
  }
  // The floating panel is an extension iframe inside the DJAI tab.
  // Ask its owning content script directly instead of querying the active tab.
  if(location.hash === '#djai-floating' && window.parent !== window){
    // Cross-browser relay: extension storage works even when Orion blocks iframe postMessage.
    const id='ar-relay-'+Date.now()+'-'+Math.random().toString(36).slice(2);
    const resultKey='aureliusDjaiRelayResult:'+id;
    const commandKey='aureliusDjaiRelayCommand:'+id;
    return new Promise((resolve,reject)=>{
      let finished=false;
      const finish=(err,result)=>{
        if(finished)return;finished=true;clearTimeout(timer);
        chrome.storage.onChanged.removeListener(onChange);
        if(err)reject(err);else resolve(result);
      };
      const timer=setTimeout(()=>finish(new Error('Floating relay timed out. Reload the DJAI tab and retry.')),action==='import-nexus'?25000:8000);
      const onChange=(changes,area)=>{
        if(area!=='local'||!changes[resultKey])return;
        const result=changes[resultKey].newValue;
        if(result?.id===id){finish(null,result.result);chrome.storage.local.remove(resultKey).catch(()=>{});}
      };
      chrome.storage.onChanged.addListener(onChange);
      chrome.storage.local.set({[commandKey]:{id,action,text,limit,session,bridge}})
        .catch(err=>finish(new Error('Could not send floating command: '+err.message)));
    });
  }
  const tabId=await aureliusCurrentTab();
  try {return await chrome.tabs.sendMessage(tabId,{type:'aurelius-djai-command',action,text,limit,session});}
  catch(e){throw new Error('DJAI bridge unavailable. Reload the DreamJourney tab. '+e.message);}
}
const injectStatus=$('djai-inject-status');
  const promptField=$('djai-director-prompt'), includeNexus=$('djai-include-nexus');
  const sizeField=$('djai-inject-size'), limitField=$('djai-limit');
  const sceneFields=$('djai-scene-location')?{location:$('djai-scene-location'),character:$('djai-scene-character'),present:$('djai-scene-present'),note:$('djai-scene-note')}:null;
  const sceneInclude=$('djai-scene-include'), sceneStatus=$('djai-scene-status');
  function currentSceneText(){
    if(!sceneFields||!sceneInclude?.checked)return '';
    const values=Object.fromEntries(Object.entries(sceneFields).map(([key,input])=>[key,input.value.trim()]));
    if(!Object.values(values).some(Boolean))return '';
    const labels={location:'Location',character:'Your character',present:'Present',note:'Scene note'};
    return '[Current Scene]\n'+Object.entries(values).filter(([,value])=>value).map(([key,value])=>labels[key]+': '+value).join('\n');
  }
  async function saveScene(showStatus=true){
    if(!sceneFields||!sceneInclude)return;
    const scene=Object.fromEntries(Object.entries(sceneFields).map(([key,input])=>[key,input.value.trim()]));
    scene.enabled=sceneInclude.checked;
    const key=await sceneStorageKey();
    await chrome.storage.local.set({[key]:scene});
    updateInjectionSize();
    if(showStatus)sceneStatus.textContent='Current Scene saved for this chat.';
  }
  if(sceneFields&&sceneInclude&&sceneStatus){
    sceneStorageKey().then(key=>chrome.storage.local.get(key)).then(data=>{
      const scene=data[Object.keys(data)[0]]||{};
      for(const [key,input] of Object.entries(sceneFields))input.value=scene[key]||'';
      sceneInclude.checked=Boolean(scene.enabled);
      updateInjectionSize();
    }).catch(error=>{sceneStatus.textContent='Could not load this chat’s scene: '+error.message;});
    $('djai-scene-save').addEventListener('click',async()=>{
      try{await saveScene();}catch(error){sceneStatus.textContent='Could not save this scene: '+error.message;}
    });
    $('djai-scene-clear').addEventListener('click',async()=>{
      try{for(const input of Object.values(sceneFields))input.value='';sceneInclude.checked=false;await chrome.storage.local.remove(await sceneStorageKey());updateInjectionSize();sceneStatus.textContent='Current Scene cleared for this chat.';}
      catch(error){sceneStatus.textContent='Could not clear this scene: '+error.message;}
    });
    for(const input of [...Object.values(sceneFields),sceneInclude])input.addEventListener(input===sceneInclude?'change':'input',()=>{updateInjectionSize();saveScene(false).catch(error=>{sceneStatus.textContent='Could not save this scene: '+error.message;});});
  }
  limitField.addEventListener('change',()=>{updateInjectionSize();chrome.storage.local.set({[LIMIT_KEY]:limitField.value}).catch(()=>{});});
  const PROMPT_KEY='aureliusDjaiDirectorPrompt053';
  const CONTINUITY_KEY='aureliusDjaiContinuity0575';
  const continuityToggle=$('djai-continuity');
  const CONTINUITY_INSTRUCTION=`[Canon continuity check — selected Nexus facts]
Treat the selected Nexus facts below as authoritative for their named subjects. Before finalizing the response, silently compare every generated description, appearance, transformation, ability, relationship and timeline detail involving those subjects against the selected facts. If a generated detail contradicts a selected fact, correct it before responding. Do not substitute details from a similarly named form or character. Do not invent missing facts; leave them unspecified. Preserve the user's control of their player character's choices, actions and dialogue. Apply this check only to the selected facts, without freezing unrelated story development.`;
  chrome.storage.local.get(CONTINUITY_KEY).then(v=>{continuityToggle.checked=Boolean(v[CONTINUITY_KEY]);updateInjectionSize()}).catch(()=>{});
  continuityToggle.addEventListener('change',()=>{updateInjectionSize();chrome.storage.local.set({[CONTINUITY_KEY]:continuityToggle.checked}).catch(e=>{injectStatus.textContent='Continuity setting could not be saved: '+e.message;});});
  function injectionText(){
    const pieces=[];
    if(promptField.value.trim())pieces.push('[Instructions]\n'+promptField.value.trim());
    const scene=currentSceneText();if(scene)pieces.push(scene);
    if(includeNexus.checked && payload()){if(continuityToggle.checked)pieces.push(CONTINUITY_INSTRUCTION);pieces.push(payload());}
    return pieces.join('\n\n');
  }
  function updateInjectionSize(){
    const value=injectionText();
    const context=payload();
    const inclusion=includeNexus.checked
      ? (context ? `selected Nexus context included (${context.length} characters)` : 'no selected Nexus context to include')
      : ((selected.size||selectedFacts.size) ? 'selected Nexus context is currently EXCLUDED' : 'Nexus inclusion off');
    sizeField.textContent=`${value.length} injector characters · ceiling ${limitField.value} (includes original Director’s Note) · ${selected.size} whole nodes / ${selectedFacts.size} facts · ${inclusion}`;
  }
  chrome.storage.local.get(PROMPT_KEY).then(v=>{promptField.value=v[PROMPT_KEY]||'';updateInjectionSize()}).catch(()=>{});
  promptField.addEventListener('input',updateInjectionSize);
  includeNexus.addEventListener('change',()=>{
    updateInjectionSize();
    chrome.storage.local.set({[INCLUDE_NEXUS_KEY]:includeNexus.checked}).catch(e=>{injectStatus.textContent='Nexus inclusion setting could not be saved: '+e.message;});
  });
  $('djai-save-prompt').addEventListener('click',async()=>{
    try{await chrome.storage.local.set({[PROMPT_KEY]:promptField.value});injectStatus.textContent='Injector prompt saved locally.'}
    catch(e){injectStatus.textContent='Could not save prompt: '+e.message}
  });
  // Refresh the count after selecting, clearing, or importing Nexus nodes.
  $('nexus-list').addEventListener('change',updateInjectionSize);
  $('nexus-all').addEventListener('click',updateInjectionSize);
  $('nexus-none').addEventListener('click',updateInjectionSize);
  $('nexus-file').addEventListener('change',()=>setTimeout(updateInjectionSize,0));
  $('djai-arm').addEventListener('click',async()=>{
    injectStatus.textContent='Arming injection…';
    try{
      const value=injectionText();
      if(!value)throw new Error('Enter injection instructions or select Nexus nodes and enable their inclusion.');
      if(value.length>Number(limitField.value))throw new Error('Injector context alone exceeds the selected ceiling. Reduce the selection or increase the experimental ceiling.');
      const r=await aureliusDjaiCommand('arm',value,Number(limitField.value));
      injectStatus.textContent=r?.ok?'Armed. Send one normal DJAI message, then check status.':(r?.status||r?.reason||'Could not arm.');
    }catch(e){injectStatus.textContent=e.message}
  });
  for(const [id,action] of [['djai-check','check'],['djai-disarm','cancel']]){
    $(id).addEventListener('click',async()=>{
      try{const r=await aureliusDjaiCommand(action);injectStatus.textContent=(r?.status||'Unknown status')+(r?.active?' (waiting for chat request)':'');
      }catch(e){injectStatus.textContent=e.message}
    });
  }
  updateInjectionSize();
  loadSaved();

  // Read-only page inspection. No content of conversations, inputs, cookies, or requests is collected.
  const probeOutput=$('djai-probe-output'), probeStatus=$('djai-probe-status');
  function inspectPage(){
    const safeText=(s)=>String(s||'').trim().slice(0,100);
    const selectors=['textarea','[contenteditable="true"]','[role="textbox"]','button','form'];
    const counts=Object.fromEntries(selectors.map(q=>[q,document.querySelectorAll(q).length]));
    const editors=[...document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]')].slice(0,12).map(el=>({
      tag:el.tagName.toLowerCase(),role:el.getAttribute('role')||'',
      contenteditable:el.getAttribute('contenteditable')||'',
      ariaLabel:safeText(el.getAttribute('aria-label')),
      placeholder:safeText(el.getAttribute('placeholder')||el.getAttribute('data-placeholder')),
      inForm:!!el.closest('form')
    }));
    const forms=[...document.querySelectorAll('form')].slice(0,8).map(f=>({method:safeText(f.getAttribute('method')||'default'),fields:f.querySelectorAll('textarea,input,[contenteditable="true"]').length}));
    return {pageOrigin:location.origin,path:location.pathname,documentTitle:safeText(document.title),
      detectedControls:counts,editors,forms,notes:'Read-only DOM metadata; no message text or network traffic collected.'};
  }
  $('djai-probe').addEventListener('click',async()=>{
    probeStatus.textContent='Inspecting active tab…';probeOutput.value='';
    try{
      const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
      if(!tab?.id||!/^https?:\/\//.test(tab.url||''))throw new Error('Open a regular HTTPS chat tab first.');
      if(new URL(tab.url).hostname==='chatgpt.com')throw new Error('Switch to your DreamJourney AI chat tab first.');
      const result=await chrome.scripting.executeScript({target:{tabId:tab.id},func:inspectPage});
      if(!result?.[0]?.result)throw new Error('No inspection result returned.');
      probeOutput.value=JSON.stringify({extension:'Aurelius Rising 0.5.7',...result[0].result},null,2);
      probeStatus.textContent='Inspection complete. No messages were changed.';
    }catch(e){probeStatus.textContent='Inspection failed: '+e.message+' Reload the page or check extension permissions.';}
  });
  $('djai-probe-copy').addEventListener('click',async()=>{
    if(!probeOutput.value){probeStatus.textContent='Run inspection first.';return;}
    try{await navigator.clipboard.writeText(probeOutput.value);probeStatus.textContent='Diagnostic report copied.'}
    catch(e){probeStatus.textContent='Select the report and copy manually.'}
  });
})();
