/* Aurelius Archive Lab — local-first, source-preserving retrieval helpers. */
const messageText=m=>typeof m?.content==='string'?m.content:Array.isArray(m?.content?.parts)?m.content.parts.filter(x=>typeof x==='string').join('\n'):typeof m?.text==='string'?m.text:'';
const role=m=>String(m?.role??m?.speaker??m?.author?.role??m?.author?.name??'unknown');
const fallback=text=>[{speaker:'transcript',text,timestamp:null,ordinal:0,start:0,end:text.length}];
/* TXT parsing is deliberately conservative: repeated explicit role headers only. */
export function parseTextMessages(text){
 const lines=/[^\r\n]*(?:\r\n|\n|\r|$)/g;let match,headers=[];
 const header=/^(?:\[)?(user|assistant|system|developer|human|ai|narrator)(?:\])?\s*:\s*/i;
 while((match=lines.exec(text)) && match[0]){const h=header.exec(match[0]);if(h)headers.push({start:match.index,bodyStart:match.index+h[0].length,speaker:h[1].toLowerCase()});}
 if(headers.length<2)return null;
 // A header can be dialogue in prose; require the first header near the beginning.
 if(headers[0].start>200)return null;
 return headers.map((h,i)=>({speaker:h.speaker,text:text.slice(h.bodyStart,headers[i+1]?.start??text.length).replace(/\s+$/,''),timestamp:null,ordinal:i,start:h.start,end:headers[i+1]?.start??text.length}));
}
/* DreamJourney exports: standalone [Bot]/[User] headings after a short export header. */
export function parseDreamJourneyMessages(text){
 if(!/Aster Chat Export|DreamJourney AI/i.test(text.slice(0,1200)))return null;
 const header=/^\[(Bot|User|Human|Assistant)\]\s*$/gmi;
 const headers=[...text.matchAll(header)].map(m=>({start:m.index,bodyStart:m.index+m[0].length,speaker:m[1].toLowerCase()}));
 if(headers.length<2||headers[0].start>1500)return null;
 return headers.map((h,i)=>({speaker:h.speaker,text:text.slice(h.bodyStart,headers[i+1]?.start??text.length).replace(/^\r?\n/,''),timestamp:null,ordinal:i,start:h.start,end:headers[i+1]?.start??text.length}));
}
export function unpackArchiveBundle(text){
 try{const obj=JSON.parse(text);if(obj?.schema!=='aurelius-archive-v1'||!Array.isArray(obj.archives))return null;
 return obj.archives.filter(a=>typeof a?.original==='string').map((a,i)=>({filename:String(a.filename||`embedded-${i+1}.txt`),original:a.original,index:i}));
 }catch{return null;}
}
export function parseArchive(text,filename='conversation.txt'){
 let messages=null,format='text',parseMethod='unstructured';
 try{
  const obj=JSON.parse(text);format='json';
  const arr=Array.isArray(obj)?obj:Array.isArray(obj?.messages)?obj.messages:null;
  if(arr && arr.length && arr.some(m=>m && typeof m==='object' && (m.role||m.speaker||m.author))){messages=arr.map((m,i)=>({speaker:role(m),text:messageText(m),timestamp:m.timestamp??m.create_time??null,ordinal:i})).filter(m=>m.text);parseMethod='json-messages';}
  else if(obj?.mapping && typeof obj.mapping==='object'){
   const nodes=Object.entries(obj.mapping).filter(([,n])=>n?.message);
   // Prefer linked-tree order when possible; otherwise stable source order, never guessed timestamps.
   const ordered=[];const visited=new Set();const byId=new Map(nodes);
   function walk(id){if(visited.has(id)||!byId.has(id))return;visited.add(id);const n=byId.get(id);if(n.message)ordered.push(n.message);for(const child of n.children||[])walk(child);}
   const roots=nodes.filter(([,n])=>!n.parent||!byId.has(n.parent));for(const [id] of roots)walk(id);for(const [id] of nodes)walk(id);
   messages=ordered.map((m,i)=>({speaker:role(m),text:messageText(m),timestamp:m.create_time??null,ordinal:i})).filter(m=>m.text);parseMethod='json-mapping';
  }
 }catch{/* Non-JSON original retained. */}
 if(!messages?.length && format==='text'){messages=parseDreamJourneyMessages(text);if(messages?.length)parseMethod='dreamjourney-headers';if(!messages?.length){messages=parseTextMessages(text);if(messages?.length)parseMethod='txt-headers';}}
 if(!messages?.length){messages=fallback(text);parseMethod='unstructured';}
 messages.forEach((m,i)=>m.ordinal=i);
 return {filename,format,original:text,messages,parseMethod,importedAt:new Date().toISOString()};
}
export function preparedArchive(a){
 // Legacy v0.1.3 records are re-parsed in memory, without modifying IndexedDB.
 if(a?.parseMethod && a.parseMethod!=='unstructured')return a;
 return {...a,...parseArchive(a.original??'',a.filename),id:a.id,importedAt:a.importedAt};
}
export function searchArchives(archives,query,context=160){
 const q=query.trim().toLocaleLowerCase();if(!q)return [];
 const out=[];
 for(const a of archives)for(const m of a.messages){const haystack=m.text.toLocaleLowerCase();let from=0,pos;
  while((pos=haystack.indexOf(q,from))!==-1){out.push({id:a.id,filename:a.filename,speaker:m.speaker,ordinal:m.ordinal,offset:pos,sourceOffset:typeof m.start==='number'?m.start+pos:null,excerpt:m.text.slice(Math.max(0,pos-context),Math.min(m.text.length,pos+q.length+context))});from=pos+Math.max(q.length,1);}
 }return out;
}
export async function fingerprint(text){const data=new TextEncoder().encode(text),hash=await crypto.subtle.digest('SHA-256',data);return Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');}
export function archiveStatistics(archives){const files=archives.map(a=>{const original=typeof a.original==='string'?a.original:'';return {id:a.id,filename:a.filename,format:a.format,parseMethod:a.parseMethod||'unstructured',characters:original.length,words:(original.match(/\S+/g)||[]).length,bytes:new TextEncoder().encode(original).length,records:a.messages?.length||0,parsed:a.parseMethod!=='unstructured'};});return {files,fileCount:files.length,characters:files.reduce((n,f)=>n+f.characters,0),words:files.reduce((n,f)=>n+f.words,0),bytes:files.reduce((n,f)=>n+f.bytes,0),records:files.reduce((n,f)=>n+f.records,0),parsedRecords:files.filter(f=>f.parsed).reduce((n,f)=>n+f.records,0),unstructuredFiles:files.filter(f=>!f.parsed).length};}
export function searchStatistics(results,elapsedMs=0){const counts=new Map();for(const r of results)counts.set(r.id,(counts.get(r.id)||0)+1);return {matches:results.length,elapsedMs,byArchive:counts};}
export function getContext(archive,ordinal,offset,queryLength=0,radius=500){const index=archive?.messages?.findIndex(m=>m.ordinal===ordinal)??-1;if(index<0)return null;const m=archive.messages[index],start=Math.max(0,offset-radius),end=Math.min(m.text.length,offset+queryLength+radius);return {message:m,index,previous:archive.messages[index-1]||null,next:archive.messages[index+1]||null,start,end,text:m.text.slice(start,end),hasEarlier:start>0,hasLater:end<m.text.length};}
export function contextWindow(archive,index,before=1,after=1){const messages=archive?.messages||[];const start=Math.max(0,index-before),end=Math.min(messages.length,index+after+1);return {start,end,total:messages.length,messages:messages.slice(start,end)};}

/* Expand Archive Lab's own export as virtual, read-only sources; originals stay in IndexedDB. */
export function expandArchives(archives){
 const result=[];
 for(const a of archives){
  const embedded=unpackArchiveBundle(a.original??'');
  if(!embedded?.length){result.push(preparedArchive(a));continue;}
  for(const item of embedded){const parsed=parseArchive(item.original,item.filename);
   result.push({...parsed,id:`${a.id}:embedded:${item.index}`,parentId:a.id,importedAt:a.importedAt,parseMethod:parsed.parseMethod});}
 }
 return result;
}
