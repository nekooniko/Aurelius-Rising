Aurelius Rising — Archive Lab (experimental, standalone)

This is NOT a replacement for the working v0.4.7 extension.

1. Extract the ZIP to a folder.
2. For reliable browser origin/storage, run a local static server from that folder:
   python -m http.server 8765
3. Open http://localhost:8765/archive.html in Chrome.
4. Import TXT or JSON exports, search phrases, optionally export archive JSON.
5. No automatic downloads; no network requests or external uploads.

IndexedDB storage is tied to the page origin (localhost:8765). Using a different port or browser profile creates a separate store. Keep backups using the optional Download button. The export format is experimental; importing its own bundled export is not supported yet.

This first experiment does not change the extension popup, counter, modules, or injector. It is deliberately separate to avoid regressions while validating archive storage and retrieval.

v0.1.3 — Context + Statistics
- Archive totals: files, characters, whitespace-estimated words, UTF-8 text size, searchable records.
- Per-file breakdown, search duration, total matches, and match distribution by source.
- Expand a result to view nearby text and (for parsed JSON) adjacent messages.
- Original TXT stays intact and is not falsely presented as individually parsed dialogue.
- Existing IndexedDB database/store and the repeated-occurrence search algorithm are unchanged.
- UI does not include any personal roleplay examples or bundled archive data.

Keep your v0.1.2 folder as a rollback copy. Run v0.1.3 on the same localhost port and browser profile to reuse stored archives. Automated tests cover core logic, not live browser rendering.

v0.1.4 — Message Parsing & Chronology (experimental)
- Recognizes arrays of role-bearing JSON messages, ChatGPT-style mapping trees, and conservative TXT role headers (User:, Assistant:, etc.).
- Unknown formats remain intact as a single searchable record; no guessed message boundaries.
- Context viewer loads adjacent messages in groups of three; full matching message is optional.
- Displays speaker and available timestamps, retaining original source order. It does not invent dates.
- Legacy IndexedDB records are re-parsed in browser memory on load, without overwriting originals or changing the database schema.
- Archive statistics distinguish detected messages from unstructured files.
- Literal escaped newlines are normalized only in the context viewer presentation.
- Message detection for a specific provider may need a representative, redacted export sample.
- The v0.1.3 source remains a separate rollback copy. Run from the extracted ar_archive_experiment directory on localhost:8765.


v0.1.5 — Nested export and DreamJourney header parsing
- Aurelius archive-v1 JSON exports are opened as virtual embedded source archives.
- DreamJourney TXT exports with repeated standalone [Bot]/[User] headers are split into source-ordered messages.
- Existing IndexedDB originals remain untouched. Import/export uses stored originals, not virtual expansions.
- Files without confidently recognized boundaries remain unstructured.
- Limitations: embedded source names may repeat; headers in narrative can resemble message boundaries; validate against your own export.
- After upgrading, restart the old Python server and hard-refresh with browser cache disabled.
