Aurelius Archive Lab v0.1.8 — Bounded Unstructured Scene Search

Aurelius Archive Lab v0.1.7 — Scene Clue Search

New: opt-in experimental multi-clue search. Enter 2–8 distinctive phrases separated by semicolons or new lines. Matches require all phrases within a single message or a +/-2-message window. Results link to original messages and context viewer. Unstructured transcripts cannot provide trustworthy message proximity: results there are same-record candidates only. This is literal matching, NOT semantic search, event classification, or confirmed scene identification.

All v0.1.6 features remain: local IndexedDB storage, nested bundle extraction, conservative DreamJourney parsing, pagination, jump to message, context copy. Originals unchanged.

Launch from ar_archive_experiment with python -m http.server 8765; open http://localhost:8765/archive.html. Stop old server, and hard-refresh browser if cached.

Tests: node test.mjs. Tests do not replace live browser verification.


v0.1.8: Unstructured scene clue searches require all literal clues to occur inside a configurable 500–10,000 character span (default 2,000). Results show each exact clue offset and the total span. Structured sources still use the previous ±2 message window. These are candidate passages, not verified scenes. Originals and browser storage are unchanged.
