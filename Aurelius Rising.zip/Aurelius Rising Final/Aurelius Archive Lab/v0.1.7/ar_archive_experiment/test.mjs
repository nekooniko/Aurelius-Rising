import assert from 'node:assert/strict';
import {parseArchive,searchArchives} from './archive-core.js';
const a=parseArchive('SpeakerA: Hello\nSpeakerB: Hello','test.txt');a.id='a';assert.equal(a.original,'SpeakerA: Hello\nSpeakerB: Hello');assert.equal(searchArchives([a],'SpeakerB').length,1);
const b=parseArchive(JSON.stringify({messages:[{role:'user',content:'Where is SpeakerC?'},{role:'assistant',content:'In the house.'}]}),'chat.json');b.id='b';assert.equal(b.messages.length,2);assert.equal(searchArchives([b],'SpeakerC')[0].speaker,'user');assert.equal(searchArchives([b],'missing').length,0);
const repeated=parseArchive('SpeakerB and SpeakerD. SpeakerB and SpeakerE. SpeakerB and SpeakerA.','repeated.txt');repeated.id='repeat';
assert.equal(searchArchives([repeated],'SpeakerB').length,3);
assert.deepEqual(searchArchives([repeated],'SpeakerB').map(r=>r.offset),[0,23,46]);
console.log('Archive parser, repeated-occurrence search, and search tests passed.');
import {archiveStatistics,searchStatistics,getContext} from './archive-core.js';
const stats=archiveStatistics([a,b,repeated]);
assert.equal(stats.fileCount,3);
assert.equal(stats.unstructuredFiles,2);
assert.equal(stats.parsedRecords,2);
assert.equal(stats.records,4);
assert.equal(stats.characters,a.original.length+b.original.length+repeated.original.length);
assert.equal(searchStatistics(searchArchives([repeated],'SpeakerB')).matches,3);
assert.equal(getContext(b,1,0,2,50).previous.speaker,'user');
assert.equal(getContext(repeated,0,23,5,5).text,'erD. SpeakerB a');
console.log('Statistics and contextual retrieval tests passed.');
import {parseTextMessages,preparedArchive,contextWindow} from './archive-core.js';
const txt=parseArchive('User: Hello\nAssistant: Hi\nUser: Again','dialogue.txt');
assert.equal(txt.parseMethod,'txt-headers');assert.equal(txt.messages.length,3);
assert.equal(contextWindow(txt,1,1,1).messages.length,3);
assert.equal(parseTextMessages('Some prose\nUser: a single dialogue line'),null);
const legacy={id:'old',filename:'dialogue.txt',original:'User: Hello\nAssistant: Hi',messages:[{speaker:'transcript',text:'User: Hello\nAssistant: Hi',ordinal:0}]};
assert.equal(preparedArchive(legacy).messages.length,2);
console.log('Message boundary, navigation, and legacy reparse tests passed.');

import {unpackArchiveBundle,expandArchives,parseDreamJourneyMessages} from './archive-core.js';
const sample='Aster Chat Export\nMade by Example at DreamJourney AI\nCharacter: Bot\n----\n[Bot]\nFirst reply.\n[User]\nSecond reply.\n[Bot]\nThird reply.';
assert.equal(parseDreamJourneyMessages(sample).length,3);
const bundle=JSON.stringify({schema:'aurelius-archive-v1',archives:[{filename:'example.txt',original:sample}]});
assert.equal(unpackArchiveBundle(bundle).length,1);
const outer={...parseArchive(bundle,'bundle.json'),id:'bundle'};
const expanded=expandArchives([outer]);
assert.equal(expanded.length,1);
assert.equal(expanded[0].parseMethod,'dreamjourney-headers');
assert.equal(expanded[0].messages.length,3);
assert.equal(searchArchives(expanded,'Second reply')[0].speaker,'user');
assert.equal(outer.original,bundle);
console.log('Nested archive and DreamJourney message parsing tests passed.');

import {findSceneEvidence,parseClues} from './archive-core.js';
assert.deepEqual(parseClues('red lantern; hidden stair;red lantern'),['red lantern','hidden stair']);
const scene=parseArchive(`User: red lantern
Assistant: walks upstairs
User: hidden stair
Assistant: unrelated`,'scene.txt');scene.id='scene';
const evidence=findSceneEvidence([scene],'red lantern;hidden stair');
assert.equal(evidence.length,1);assert.equal(evidence[0].ordinal,0);
assert.equal(findSceneEvidence([scene],'red lantern;missing clue').length,0);
const separate=parseArchive(`User: red lantern
Assistant: nothing
User: nothing
Assistant: nothing
User: hidden stair`,'far.txt');separate.id='far';
assert.equal(findSceneEvidence([separate],'red lantern;hidden stair').length,0);
console.log('Scene clue proximity tests passed.');
