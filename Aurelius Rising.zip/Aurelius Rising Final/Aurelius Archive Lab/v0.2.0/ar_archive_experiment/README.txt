Aurelius Archive Lab v0.2.0 — Evidence Navigator

Local-first search of imported TXT/JSON archives.
New: every scene result can show a separate, highlighted, copyable source
excerpt for EACH clue, including clues in different structured messages.
Source character positions are shown only where original parser positions exist.
The matching algorithm and default settings are unchanged from v0.1.9.

Launch from this folder:
  python -m http.server 8765
Then open http://localhost:8765/archive.html
Stop the old server first. Browser archives remain in IndexedDB on the
same localhost origin; source imports are not altered by this release.

Automated tests: node test.mjs
No network calls, telemetry, or automatic deletion.
