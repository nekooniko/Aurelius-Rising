/* Aurelius Archive Lab — local-first, source-preserving retrieval helpers. */
const messageText=m=>typeof m?.content==='string'?m.content:Array.isArray(m?.content?.parts)?m.content.parts.filter(x=>typeof x==='string').join('\n'):typeof m?.text==='string'?m.text:'';
const role=m=>String(m?.role??m?.speaker??m?.author?.role??m?.author?.name??'unknown');
const fallback=text=>[{speaker:'transcript',text,timestamp:null,ordinal:0,start:0,end:text.length}];
/* TXT parsing is deliberately conservative: repeated explicit role headers only. */
export function parseTextMessages(text){
 const lines=/[^\r\n]*(?:\r\n|\n|\r|$)/g;let match,headers=[];
 const header=/^(?:\[)?(user|assistant|system|developer|human|ai|narrator)(?:\])?\s*:\s*/i;
 while((match=lines.exec(text)) && match[0]){const h=header.exec(match[0]);if(h)headers.push({start:match.index,bodyStart:match.index+h[0].length,speaker:h[1].toLowerCase()});}
 if(headers.length<2)return null;
 // A header can be dialogue in prose; require the first header near the beginning.
 if(headers[0].start>200)return null;
 return headers.map((h,i)=>({speaker:h.speaker,text:text.slice(h.bodyStart,headers[i+1]?.start??text.length).replace(/\s+$/,''),timestamp:null,ordinal:i,start:h.start,end:headers[i+1]?.start??text.length}));
}
/* DreamJourney exports: standalone [Bot]/[User] headings after a short export header. */
export function parseDreamJourneyMessages(text){
 if(!/Aster Chat Export|DreamJourney AI/i.test(text.slice(0,1200)))return null;
 const header=/^\[(Bot|User|Human|Assistant)\]\s*$/gmi;
 const headers=[...text.matchAll(header)].map(m=>({start:m.index,bodyStart:m.index+m[0].length,speaker:m[1].toLowerCase()}));
 if(headers.length<2||headers[0].start>1500)return null;
 return headers.map((h,i)=>({speaker:h.speaker,text:text.slice(h.bodyStart,headers[i+1]?.start??text.length).replace(/^\r?\n/,''),timestamp:null,ordinal:i,start:h.start,end:headers[i+1]?.start??text.length}));
}
export function unpackArchiveBundle(text){
 try{const obj=JSON.parse(text);if(obj?.schema!=='aurelius-archive-v1'||!Array.isArray(obj.archives))return null;
 return obj.archives.filter(a=>typeof a?.original==='string').map((a,i)=>({filename:String(a.filename||`embedded-${i+1}.txt`),original:a.original,index:i}));
 }catch{return null;}
}
export function parseArchive(text,filename='conversation.txt'){
 let messages=null,format='text',parseMethod='unstructured';
 try{
  const obj=JSON.parse(text);format='json';
  const arr=Array.isArray(obj)?obj:Array.isArray(obj?.messages)?obj.messages:null;
  if(arr && arr.length && arr.some(m=>m && typeof m==='object' && (m.role||m.speaker||m.author))){messages=arr.map((m,i)=>({speaker:role(m),text:messageText(m),timestamp:m.timestamp??m.create_time??null,ordinal:i})).filter(m=>m.text);parseMethod='json-messages';}
  else if(obj?.mapping && typeof obj.mapping==='object'){
   const nodes=Object.entries(obj.mapping).filter(([,n])=>n?.message);
   // Prefer linked-tree order when possible; otherwise stable source order, never guessed timestamps.
   const ordered=[];const visited=new Set();const byId=new Map(nodes);
   function walk(id){if(visited.has(id)||!byId.has(id))return;visited.add(id);const n=byId.get(id);if(n.message)ordered.push(n.message);for(const child of n.children||[])walk(child);}
   const roots=nodes.filter(([,n])=>!n.parent||!byId.has(n.parent));for(const [id] of roots)walk(id);for(const [id] of nodes)walk(id);
   messages=ordered.map((m,i)=>({speaker:role(m),text:messageText(m),timestamp:m.create_time??null,ordinal:i})).filter(m=>m.text);parseMethod='json-mapping';
  }
 }catch{/* Non-JSON original retained. */}
 if(!messages?.length && format==='text'){messages=parseDreamJourneyMessages(text);if(messages?.length)parseMethod='dreamjourney-headers';if(!messages?.length){messages=parseTextMessages(text);if(messages?.length)parseMethod='txt-headers';}}
 if(!messages?.length){messages=fallback(text);parseMethod='unstructured';}
 messages.forEach((m,i)=>m.ordinal=i);
 return {filename,format,original:text,messages,parseMethod,importedAt:new Date().toISOString()};
}
export function preparedArchive(a){
 // Legacy v0.1.3 records are re-parsed in memory, without modifying IndexedDB.
 if(a?.parseMethod && a.parseMethod!=='unstructured')return a;
 return {...a,...parseArchive(a.original??'',a.filename),id:a.id,importedAt:a.importedAt};
}
export function searchArchives(archives,query,context=160){
 const q=query.trim().toLocaleLowerCase();if(!q)return [];
 const out=[];
 for(const a of archives)for(const m of a.messages){const haystack=m.text.toLocaleLowerCase();let from=0,pos;
  while((pos=haystack.indexOf(q,from))!==-1){out.push({id:a.id,filename:a.filename,speaker:m.speaker,ordinal:m.ordinal,offset:pos,sourceOffset:typeof m.start==='number'?m.start+pos:null,excerpt:m.text.slice(Math.max(0,pos-context),Math.min(m.text.length,pos+q.length+context))});from=pos+Math.max(q.length,1);}
 }return out;
}
export async function fingerprint(text){const data=new TextEncoder().encode(text),hash=await crypto.subtle.digest('SHA-256',data);return Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');}
export function archiveStatistics(archives){const files=archives.map(a=>{const original=typeof a.original==='string'?a.original:'';return {id:a.id,filename:a.filename,format:a.format,parseMethod:a.parseMethod||'unstructured',characters:original.length,words:(original.match(/\S+/g)||[]).length,bytes:new TextEncoder().encode(original).length,records:a.messages?.length||0,parsed:a.parseMethod!=='unstructured'};});return {files,fileCount:files.length,characters:files.reduce((n,f)=>n+f.characters,0),words:files.reduce((n,f)=>n+f.words,0),bytes:files.reduce((n,f)=>n+f.bytes,0),records:files.reduce((n,f)=>n+f.records,0),parsedRecords:files.filter(f=>f.parsed).reduce((n,f)=>n+f.records,0),unstructuredFiles:files.filter(f=>!f.parsed).length};}
export function searchStatistics(results,elapsedMs=0){const counts=new Map();for(const r of results)counts.set(r.id,(counts.get(r.id)||0)+1);return {matches:results.length,elapsedMs,byArchive:counts};}
export function getContext(archive,ordinal,offset,queryLength=0,radius=500){const index=archive?.messages?.findIndex(m=>m.ordinal===ordinal)??-1;if(index<0)return null;const m=archive.messages[index],start=Math.max(0,offset-radius),end=Math.min(m.text.length,offset+queryLength+radius);return {message:m,index,previous:archive.messages[index-1]||null,next:archive.messages[index+1]||null,start,end,text:m.text.slice(start,end),hasEarlier:start>0,hasLater:end<m.text.length};}
export function contextWindow(archive,index,before=1,after=1){const messages=archive?.messages||[];const start=Math.max(0,index-before),end=Math.min(messages.length,index+after+1);return {start,end,total:messages.length,messages:messages.slice(start,end)};}

/* Expand Archive Lab's own export as virtual, read-only sources; originals stay in IndexedDB. */
export function expandArchives(archives){
 const result=[];
 for(const a of archives){
  const embedded=unpackArchiveBundle(a.original??'');
  if(!embedded?.length){result.push(preparedArchive(a));continue;}
  for(const item of embedded){const parsed=parseArchive(item.original,item.filename);
   result.push({...parsed,id:`${a.id}:embedded:${item.index}`,parentId:a.id,importedAt:a.importedAt,parseMethod:parsed.parseMethod});}
 }
 return result;
}

/* v0.1.7: literal clue co-occurrence, NOT semantic inference. Each result
   references one source record; nearby messages are evidence, not summaries. */
export function parseClues(raw){return [...new Set(raw.split(/\r?\n|;/).map(s=>s.trim()).filter(Boolean).map(s=>s.toLocaleLowerCase()))].slice(0,8);}
function allOffsets(text,needle,wholeWords=false){
 const found=[];let pos=0,at;
 while((at=text.indexOf(needle,pos))!==-1){
  const before=at?text[at-1]:"",after=text[at+needle.length]??"";
  if(!wholeWords||(!/[\p{L}\p{N}_]/u.test(before)&&!/[\p{L}\p{N}_]/u.test(after)))found.push(at);
  pos=at+Math.max(needle.length,1);}
 return found;
}
/* Every unstructured candidate must be supported by exact offsets inside
   a bounded character window; never treat a whole transcript as one scene. */
export function unstructuredSceneEvidence(a,clues,{maxSpan=2000,maxResults=500,wholeWords=false}={}){
 const out=[];
 for(const m of a.messages||[]){
  const text=m.text.toLocaleLowerCase();const offsets=clues.map(c=>allOffsets(text,c,wholeWords));
  if(offsets.some(xs=>!xs.length))continue;
  const cursor=offsets.map(()=>0);let lastEnd=-1;
  while(cursor.every((v,k)=>v<offsets[k].length)){
   const current=cursor.map((v,k)=>({clue:clues[k],offset:offsets[k][v],end:offsets[k][v]+clues[k].length}));
   const start=Math.min(...current.map(x=>x.offset)),end=Math.max(...current.map(x=>x.end));
   if(end-start<=maxSpan && start>=lastEnd){
    const anchor=current.find(x=>x.offset===start);
    out.push({id:a.id,filename:a.filename,speaker:m.speaker,ordinal:m.ordinal,offset:start,queryLength:anchor.clue.length,
     excerpt:m.text.slice(Math.max(0,start-140),Math.min(m.text.length,end+140)),
     clues:current.map(x=>({clue:x.clue,message:m.ordinal+1,offset:x.offset})),kind:'bounded-characters',span:end-start});
    lastEnd=end;
    if(out.length>=maxResults)return out;
   }
   let minIndex=0;for(let k=1;k<current.length;k++)if(current[k].offset<current[minIndex].offset)minIndex=k;
   cursor[minIndex]++;
  }
 }
 return out;
}
export function findSceneEvidence(archives,raw,{neighborRadius=2,maxResults=500,maxSpan=2000,wholeWords=false}={}){
 const clues=parseClues(raw);if(clues.length<2)return [];
 const out=[];
 for(const a of archives){
  if(a.parseMethod==='unstructured'){
   out.push(...unstructuredSceneEvidence(a,clues,{maxSpan,maxResults:maxResults-out.length,wholeWords}));
   if(out.length>=maxResults)return out;
   continue;
  }
  const ms=a.messages||[];
  const hits=ms.map(m=>{const t=m.text.toLocaleLowerCase();return clues.map(c=>allOffsets(t,c,wholeWords)[0]??-1);});
  for(let i=0;i<ms.length;i++){
   const lo=a.parseMethod==='unstructured'?i:Math.max(0,i-neighborRadius);
   const hi=a.parseMethod==='unstructured'?i:Math.min(ms.length-1,i+neighborRadius);
   const matched=clues.map((c,k)=>{for(let j=lo;j<=hi;j++)if(hits[j][k]>=0)return {clue:c,index:j,offset:hits[j][k]};return null;});
   if(matched.some(x=>!x))continue;
   // Avoid repeated overlapping windows: keep first anchor in each cluster.
   const anchor=Math.min(...matched.map(x=>x.index));
   if(a.parseMethod!=='unstructured'&&i!==anchor)continue;
   const primary=matched.find(x=>x.index===anchor)||matched[0];
   const msg=ms[primary.index];const offset=primary.offset;
   out.push({id:a.id,filename:a.filename,speaker:msg.speaker,ordinal:msg.ordinal,offset,queryLength:primary.clue.length,excerpt:msg.text.slice(Math.max(0,offset-140),Math.min(msg.text.length,offset+primary.clue.length+220)),clues:matched.map(x=>({clue:x.clue,message:x.index+1})),kind:a.parseMethod==='unstructured'?'same-record':'nearby-messages'});
   if(out.length>=maxResults)return out;
  }
 }
 return out;
}

/* v0.1.9: bounded evidence context that contains every matched clue, not only the first. */
export function sceneEvidenceContext(archive,result,padding=300){
 const message=archive?.messages?.find(m=>m.ordinal===result.ordinal);
 if(!message)return null;
 const positions=(result.clues||[]).filter(c=>Number.isInteger(c.offset));
 const start=Math.max(0,Math.min(result.offset,...positions.map(c=>c.offset))-padding);
 const end=Math.min(message.text.length,Math.max(result.offset+(result.queryLength||0),...positions.map(c=>c.offset+c.clue.length))+padding);
 return {start,end,text:message.text.slice(start,end),total:message.text.length};
}

/* v0.2.0: independently verifiable clue locations across structured and
   unstructured sources. Never infer a source offset where one is unknown. */
export function sceneEvidenceCards(archive,result,padding=180){
 const cards=[];
 for(const clue of result.clues||[]){
  const index=clue.message-1, m=archive?.messages?.[index];if(!m)continue;
  const lower=m.text.toLocaleLowerCase(),needle=clue.clue.toLocaleLowerCase();
  const at=Number.isInteger(clue.offset)?clue.offset:lower.indexOf(needle);
  if(at<0||lower.slice(at,at+needle.length)!==needle)continue;
  const start=Math.max(0,at-padding),end=Math.min(m.text.length,at+needle.length+padding);
  cards.push({clue:clue.clue,speaker:m.speaker,message:index+1,offset:at,
   sourceOffset:Number.isInteger(m.start)?m.start+at:null,start,end,
   excerpt:m.text.slice(start,end),filename:archive.filename});
 }
 return cards;
}
