import assert from 'node:assert/strict';
import {parseArchive,searchArchives} from './archive-core.js';
const a=parseArchive('SpeakerA: Hello\nSpeakerB: Hello','test.txt');a.id='a';assert.equal(a.original,'SpeakerA: Hello\nSpeakerB: Hello');assert.equal(searchArchives([a],'SpeakerB').length,1);
const b=parseArchive(JSON.stringify({messages:[{role:'user',content:'Where is SpeakerC?'},{role:'assistant',content:'In the house.'}]}),'chat.json');b.id='b';assert.equal(b.messages.length,2);assert.equal(searchArchives([b],'SpeakerC')[0].speaker,'user');assert.equal(searchArchives([b],'missing').length,0);
const repeated=parseArchive('SpeakerB and SpeakerD. SpeakerB and SpeakerE. SpeakerB and SpeakerA.','repeated.txt');repeated.id='repeat';
assert.equal(searchArchives([repeated],'SpeakerB').length,3);
assert.deepEqual(searchArchives([repeated],'SpeakerB').map(r=>r.offset),[0,23,46]);
console.log('Archive parser, repeated-occurrence search, and search tests passed.');
import {archiveStatistics,searchStatistics,getContext} from './archive-core.js';
const stats=archiveStatistics([a,b,repeated]);
assert.equal(stats.fileCount,3);
assert.equal(stats.unstructuredFiles,2);
assert.equal(stats.parsedRecords,2);
assert.equal(stats.records,4);
assert.equal(stats.characters,a.original.length+b.original.length+repeated.original.length);
assert.equal(searchStatistics(searchArchives([repeated],'SpeakerB')).matches,3);
assert.equal(getContext(b,1,0,2,50).previous.speaker,'user');
assert.equal(getContext(repeated,0,23,5,5).text,'erD. SpeakerB a');
console.log('Statistics and contextual retrieval tests passed.');
import {parseTextMessages,preparedArchive,contextWindow} from './archive-core.js';
const txt=parseArchive('User: Hello\nAssistant: Hi\nUser: Again','dialogue.txt');
assert.equal(txt.parseMethod,'txt-headers');assert.equal(txt.messages.length,3);
assert.equal(contextWindow(txt,1,1,1).messages.length,3);
assert.equal(parseTextMessages('Some prose\nUser: a single dialogue line'),null);
const legacy={id:'old',filename:'dialogue.txt',original:'User: Hello\nAssistant: Hi',messages:[{speaker:'transcript',text:'User: Hello\nAssistant: Hi',ordinal:0}]};
assert.equal(preparedArchive(legacy).messages.length,2);
console.log('Message boundary, navigation, and legacy reparse tests passed.');

import {unpackArchiveBundle,expandArchives,parseDreamJourneyMessages} from './archive-core.js';
const sample='Aster Chat Export\nMade by Example at DreamJourney AI\nCharacter: Bot\n----\n[Bot]\nFirst reply.\n[User]\nSecond reply.\n[Bot]\nThird reply.';
assert.equal(parseDreamJourneyMessages(sample).length,3);
const bundle=JSON.stringify({schema:'aurelius-archive-v1',archives:[{filename:'example.txt',original:sample}]});
assert.equal(unpackArchiveBundle(bundle).length,1);
const outer={...parseArchive(bundle,'bundle.json'),id:'bundle'};
const expanded=expandArchives([outer]);
assert.equal(expanded.length,1);
assert.equal(expanded[0].parseMethod,'dreamjourney-headers');
assert.equal(expanded[0].messages.length,3);
assert.equal(searchArchives(expanded,'Second reply')[0].speaker,'user');
assert.equal(outer.original,bundle);
console.log('Nested archive and DreamJourney message parsing tests passed.');

import {findSceneEvidence,parseClues} from './archive-core.js';
assert.deepEqual(parseClues('red lantern; hidden stair;red lantern'),['red lantern','hidden stair']);
const scene=parseArchive(`User: red lantern
Assistant: walks upstairs
User: hidden stair
Assistant: unrelated`,'scene.txt');scene.id='scene';
const evidence=findSceneEvidence([scene],'red lantern;hidden stair');
assert.equal(evidence.length,1);assert.equal(evidence[0].ordinal,0);
assert.equal(findSceneEvidence([scene],'red lantern;missing clue').length,0);
const separate=parseArchive(`User: red lantern
Assistant: nothing
User: nothing
Assistant: nothing
User: hidden stair`,'far.txt');separate.id='far';
assert.equal(findSceneEvidence([separate],'red lantern;hidden stair').length,0);
console.log('Scene clue proximity tests passed.');

// v0.1.8: bounded literal co-occurrence on an unstructured record.
const giant={id:'giant',filename:'giant.txt',parseMethod:'unstructured',messages:[{speaker:'transcript',ordinal:0,text:'red lantern '+'.'.repeat(8000)+' hidden stair'}]};
assert.equal(findSceneEvidence([giant],'red lantern;hidden stair').length,0,'distant clues must not match');
assert.equal(findSceneEvidence([giant],'red lantern;hidden stair',{maxSpan:10000}).length,1,'wider span may include distant clues');
const near={id:'near',filename:'near.txt',parseMethod:'unstructured',messages:[{speaker:'transcript',ordinal:0,text:'red lantern, and then hidden stair. Later: red lantern beside hidden stair.'}]};
const close=findSceneEvidence([near],'red lantern;hidden stair',{maxSpan:80});
assert.ok(close.length>=1);
assert.equal(close[0].kind,'bounded-characters');
assert.ok(close[0].clues.every(c=>Number.isInteger(c.offset)));
assert.equal(findSceneEvidence([near],'red lantern;missing clue').length,0);
assert.equal(findSceneEvidence([near],'red lantern;hidden stair',{maxSpan:10}).length,0);
console.log('Unstructured bounded-proximity and negative-control tests passed.');

// v0.1.9: opt-in word boundaries and evidence context across long spans.
import {sceneEvidenceContext} from './archive-core.js';
const boundary={id:'boundary',filename:'boundary.txt',parseMethod:'unstructured',messages:[{speaker:'transcript',ordinal:0,text:'transformation and blue lantern. Later transform and blue lantern.'}]};
assert.equal(findSceneEvidence([boundary],'transform;blue lantern',{maxSpan:100,wholeWords:false}).length,2);
const strict=findSceneEvidence([boundary],'transform;blue lantern',{maxSpan:100,wholeWords:true});
assert.equal(strict.length,1);
assert.ok(strict[0].clues.find(c=>c.clue==='transform').offset>20);
const spaced={id:'spaced',filename:'spaced.txt',parseMethod:'unstructured',messages:[{speaker:'transcript',ordinal:0,text:'red lantern '+'.'.repeat(1600)+' hidden stair'}]};
const longHit=findSceneEvidence([spaced],'red lantern;hidden stair',{maxSpan:2000})[0];
const passage=sceneEvidenceContext(spaced,longHit,50);
assert.ok(passage.text.includes('red lantern')&&passage.text.includes('hidden stair'));
assert.equal(findSceneEvidence([spaced],'red lantern;hidden stair',{maxSpan:500}).length,0);
console.log('v0.1.9 word-boundary and full evidence-window tests passed.');

// v0.2.0: exact, source-preserving evidence cards across messages.
import {sceneEvidenceCards} from './archive-core.js';
const cards=sceneEvidenceCards(scene,evidence[0],15);
assert.equal(cards.length,2);
assert.deepEqual(cards.map(c=>c.message),[1,3]);
assert.ok(cards[0].excerpt.includes('red lantern'));
assert.ok(cards[1].excerpt.includes('hidden stair'));
assert.equal(cards[0].offset,0);
const boundedCards=sceneEvidenceCards(near,close[0],10);
assert.equal(boundedCards.length,2);
assert.ok(boundedCards.every(c=>c.excerpt.toLocaleLowerCase().includes(c.clue)));
assert.equal(sceneEvidenceCards(scene,{clues:[{clue:'not there',message:1}]}).length,0);
console.log('v0.2.0 multi-message evidence navigator tests passed.');
