/* Aurelius Rising archive experiment — browser-independent parsing/search helpers. */
export function parseArchive(text, filename='conversation.txt') {
  let messages=[]; let format='text';
  try {
    const obj=JSON.parse(text); format='json';
    const arr=Array.isArray(obj)?obj:(Array.isArray(obj.messages)?obj.messages:null);
    if(arr) messages=arr.map((m,i)=>({speaker:String(m.role??m.speaker??m.author?.role??'unknown'),text:String(typeof m.content==='string'?m.content:(m.content?.parts?.filter(x=>typeof x==='string').join('\n')??m.text??'')),timestamp:m.timestamp??m.create_time??null,ordinal:i})).filter(m=>m.text);
    else if(obj.mapping && typeof obj.mapping==='object') {
      messages=Object.values(obj.mapping).filter(n=>n.message).map(n=>n.message).map((m,i)=>({speaker:String(m.author?.role??'unknown'),text:(m.content?.parts??[]).filter(x=>typeof x==='string').join('\n'),timestamp:m.create_time??null,ordinal:i})).filter(m=>m.text);
      messages.sort((a,b)=>(a.timestamp??0)-(b.timestamp??0));
    }
  } catch { /* preserve original TXT verbatim */ }
  if(!messages.length) messages=[{speaker:'transcript',text,timestamp:null,ordinal:0}];
  return {filename,format,original:text,messages,importedAt:new Date().toISOString()};
}

export function searchArchives(archives, query, context = 160) {
    const q = query.trim().toLocaleLowerCase();
    if (!q) return [];

    const out = [];

    for (const a of archives) {
        for (const m of a.messages) {
            const haystack = m.text.toLocaleLowerCase();
            let from = 0;

            while (true) {
                const pos = haystack.indexOf(q, from);
                if (pos === -1) break;

                out.push({
                    id: a.id,
                    filename: a.filename,
                    speaker: m.speaker,
                    ordinal: m.ordinal,
                    offset: pos,
                    excerpt: m.text.slice(
                        Math.max(0, pos - context),
                        Math.min(m.text.length, pos + q.length + context)
                    )
                });

                from = pos + Math.max(1, q.length);
            }
        }
    }

    return out;
}
export async function fingerprint(text) {
    const data = new TextEncoder().encode(text);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(
        new Uint8Array(hash),
        b => b.toString(16).padStart(2, '0')
    ).join('');
}