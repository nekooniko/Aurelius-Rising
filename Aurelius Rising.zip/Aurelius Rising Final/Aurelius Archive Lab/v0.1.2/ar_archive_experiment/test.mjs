import assert from 'node:assert/strict';
import {parseArchive,searchArchives} from './archive-core.js';
const a=parseArchive('Tasuki: Hello\nRaven: Hello','test.txt');a.id='a';assert.equal(a.original,'Tasuki: Hello\nRaven: Hello');assert.equal(searchArchives([a],'Raven').length,1);
const b=parseArchive(JSON.stringify({messages:[{role:'user',content:'Where is Chiriko?'},{role:'assistant',content:'In the house.'}]}),'chat.json');b.id='b';assert.equal(b.messages.length,2);assert.equal(searchArchives([b],'Chiriko')[0].speaker,'user');assert.equal(searchArchives([b],'missing').length,0);
const repeated=parseArchive('Raven and Lupin. Raven and Dante. Raven and Tasuki.','repeated.txt');repeated.id='repeat';
assert.equal(searchArchives([repeated],'Raven').length,3);
assert.deepEqual(searchArchives([repeated],'Raven').map(r=>r.offset),[0,17,34]);
console.log('Archive parser, repeated-occurrence search, and search tests passed.');
