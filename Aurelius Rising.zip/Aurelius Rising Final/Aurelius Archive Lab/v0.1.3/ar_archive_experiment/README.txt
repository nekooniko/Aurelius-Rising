Aurelius Rising — Archive Lab (experimental, standalone)

This is NOT a replacement for the working v0.4.7 extension.

1. Extract the ZIP to a folder.
2. For reliable browser origin/storage, run a local static server from that folder:
   python -m http.server 8765
3. Open http://localhost:8765/archive.html in Chrome.
4. Import TXT or JSON exports, search phrases, optionally export archive JSON.
5. No automatic downloads; no network requests or external uploads.

IndexedDB storage is tied to the page origin (localhost:8765). Using a different port or browser profile creates a separate store. Keep backups using the optional Download button. The export format is experimental; importing its own bundled export is not supported yet.

This first experiment does not change the extension popup, counter, modules, or injector. It is deliberately separate to avoid regressions while validating archive storage and retrieval.

v0.1.3 — Context + Statistics
- Archive totals: files, characters, whitespace-estimated words, UTF-8 text size, searchable records.
- Per-file breakdown, search duration, total matches, and match distribution by source.
- Expand a result to view nearby text and (for parsed JSON) adjacent messages.
- Original TXT stays intact and is not falsely presented as individually parsed dialogue.
- Existing IndexedDB database/store and the repeated-occurrence search algorithm are unchanged.
- UI does not include any personal roleplay examples or bundled archive data.

Keep your v0.1.2 folder as a rollback copy. Run v0.1.3 on the same localhost port and browser profile to reuse stored archives. Automated tests cover core logic, not live browser rendering.
