import {parseArchive,searchArchives,fingerprint,archiveStatistics,searchStatistics,getContext} from './archive-core.js';
const $=id=>document.getElementById(id), DB='aurelius-archive-lab', STORE='archives';
function dbOpen(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE,{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function transact(mode,fn){const db=await dbOpen();try{return await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,mode),store=tx.objectStore(STORE);let request;try{request=fn(store)}catch(e){reject(e);return}tx.oncomplete=()=>resolve(request?.result);tx.onerror=()=>reject(tx.error);});}finally{db.close()}}
const all=()=>transact('readonly',s=>s.getAll());let archives=[];
const fmt=n=>Number(n).toLocaleString(), millis=n=>`${n.toFixed(1)} ms`;
function el(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function metric(label,value,detail){const d=el('div',undefined,'metric');d.append(el('small',label),el('strong',value));if(detail)d.append(el('small',detail));return d;}
function renderStats(results,elapsed){const s=archiveStatistics(archives), ss=searchStatistics(results,elapsed),target=$('archive-stats');target.replaceChildren(metric('Imported files',fmt(s.fileCount)),metric('Source characters',fmt(s.characters)),metric('Estimated words',fmt(s.words)),metric('UTF-8 text size',`${(s.bytes/1024/1024).toFixed(2)} MiB`),metric('Searchable records',fmt(s.records),`${fmt(s.parsedRecords)} JSON-parsed records`),metric('Unstructured files',fmt(s.unstructuredFiles),'TXT/fallback: no reliable message count'));
 const list=$('file-stats');list.replaceChildren();for(const f of s.files){const row=el('div',undefined,'file-stat');row.append(el('strong',f.filename),el('small',`${fmt(f.characters)} characters · ${fmt(f.words)} words · ${fmt(f.records)} searchable record(s) · ${f.parsed?'JSON message records':'unstructured text'}`));list.append(row)}if(!s.files.length)list.append(el('p','Import files to see statistics.','muted'));
 $('search-metrics').replaceChildren(metric('Total matches',fmt(ss.matches)),metric('Search duration',millis(ss.elapsedMs)),metric('Files with matches',fmt(ss.byArchive.size)));
 const dist=$('match-distribution');dist.replaceChildren();if($('query').value.trim())for(const f of s.files){const count=ss.byArchive.get(f.id)||0,row=el('div',undefined,'distribution-row'),bar=el('div',undefined,'bar');bar.style.width=`${ss.matches?100*count/ss.matches:0}%`;row.append(el('span',`${f.filename}: ${fmt(count)}`),bar);dist.append(row)}
}
function showContext(wrap,r){const a=archives.find(a=>a.id===r.id);if(!a)return;const context=getContext(a,r.ordinal,r.offset,r.queryLength,600);if(!context)return;
 const panel=el('div',undefined,'context-panel'),header=el('strong',`Source: ${a.filename} · record ${r.ordinal+1} · character ${r.offset+1}`);panel.append(header);
 const note=el('p',a.format==='text'?'Unstructured transcript: nearby text is shown without guessing speakers or scene boundaries.':'Adjacent parsed messages are shown when available.','muted');panel.append(note);
 function addMessage(title,message,text){if(!message)return;panel.append(el('h3',title),el('pre',text??message.text));}
 if(context.previous)addMessage(`Previous · ${context.previous.speaker}`,context.previous);
 addMessage(`Current · ${context.message.speaker}`,context.message,context.text);
 if(context.hasEarlier||context.hasLater)panel.append(el('small',`Current record excerpt: characters ${fmt(context.start+1)}–${fmt(context.end)} of ${fmt(context.message.text.length)}.`));
 if(context.next)addMessage(`Next · ${context.next.speaker}`,context.next);
 const actions=el('div',undefined,'actions');const full=el('button','Show full current record');full.addEventListener('click',()=>{const pre=el('pre',context.message.text);full.replaceWith(pre)});const close=el('button','Close context');close.addEventListener('click',()=>panel.remove());actions.append(full,close);panel.append(actions);wrap.append(panel);
}
function render(){const q=$('query').value,t0=performance.now(),results=searchArchives(archives,q),elapsed=performance.now()-t0;renderStats(results,elapsed);
 $('stats').textContent=q.trim()?`${fmt(results.length)} match(es) across ${fmt(new Set(results.map(r=>r.id)).size)} file(s). Results show every occurrence; the first 100 are displayed.`:'Enter a phrase to search imported source content.';
 const target=$('results');target.replaceChildren();for(const r of results.slice(0,100)){r.queryLength=q.trim().length;const wrap=el('div',undefined,'result');wrap.append(el('strong',`${r.filename} — ${r.speaker} (record ${r.ordinal+1}, character ${r.offset+1})`),el('pre',r.excerpt));const btn=el('button','Show surrounding context');btn.addEventListener('click',()=>{if(wrap.querySelector('.context-panel'))return;showContext(wrap,r)});wrap.append(btn);target.append(wrap)}if(results.length>100)target.append(el('p','Showing the first 100 matches. All matches are included in statistics. Narrow the search to see later results.','muted'));
}
async function refresh(){archives=await all();render()}
$('files').addEventListener('change',async e=>{let added=0,duplicates=0;try{for(const file of e.target.files){const text=await file.text(),id=await fingerprint(text);if(archives.some(a=>a.id===id)){duplicates++;continue;}const a={...parseArchive(text,file.name),id};await transact('readwrite',s=>s.put(a));archives.push(a);added++;}$('status').textContent=`Imported ${added} file(s); skipped ${duplicates} exact duplicate(s).`;render();}catch(err){$('status').textContent=`Import failed: ${err.message}`;}e.target.value='';});
$('query').addEventListener('input',render);
$('export').addEventListener('click',()=>{const blob=new Blob([JSON.stringify({schema:'aurelius-archive-v1',exportedAt:new Date().toISOString(),archives},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='aurelius-conversation-archive.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
$('clear').addEventListener('click',async()=>{if(!confirm('Permanently delete all archives stored by this experiment in this browser?'))return;await transact('readwrite',s=>s.clear());await refresh();$('status').textContent='Local archive cleared.';});
refresh().catch(e=>{$('status').textContent=`Storage unavailable: ${e.message}`});
