/* Aurelius Rising archive experiment — browser-independent parsing/search helpers. */
export function parseArchive(text, filename='conversation.txt') {
  let messages=[]; let format='text';
  try {
    const obj=JSON.parse(text); format='json';
    const arr=Array.isArray(obj)?obj:(Array.isArray(obj.messages)?obj.messages:null);
    if(arr) messages=arr.map((m,i)=>({speaker:String(m.role??m.speaker??m.author?.role??'unknown'),text:String(typeof m.content==='string'?m.content:(m.content?.parts?.filter(x=>typeof x==='string').join('\n')??m.text??'')),timestamp:m.timestamp??m.create_time??null,ordinal:i})).filter(m=>m.text);
    else if(obj.mapping && typeof obj.mapping==='object') {
      messages=Object.values(obj.mapping).filter(n=>n.message).map(n=>n.message).map((m,i)=>({speaker:String(m.author?.role??'unknown'),text:(m.content?.parts??[]).filter(x=>typeof x==='string').join('\n'),timestamp:m.create_time??null,ordinal:i})).filter(m=>m.text);
      messages.sort((a,b)=>(a.timestamp??0)-(b.timestamp??0));
    }
  } catch { /* preserve original TXT verbatim */ }
  if(!messages.length) messages=[{speaker:'transcript',text,timestamp:null,ordinal:0}];
  return {filename,format,original:text,messages,importedAt:new Date().toISOString()};
}
export function searchArchives(archives,query,context=160) {
  const q=query.trim().toLocaleLowerCase(); if(!q)return [];
  const out=[];
  for(const a of archives) for(const m of a.messages){
    const haystack=m.text.toLocaleLowerCase();
    let from=0,pos;
    while((pos=haystack.indexOf(q,from))!==-1){
      out.push({id:a.id,filename:a.filename,speaker:m.speaker,ordinal:m.ordinal,offset:pos,excerpt:m.text.slice(Math.max(0,pos-context),Math.min(m.text.length,pos+q.length+context))});
      from=pos+Math.max(q.length,1);
    }
  }
  return out;
}
export async function fingerprint(text){const data=new TextEncoder().encode(text);const hash=await crypto.subtle.digest('SHA-256',data);return Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');}

/* Statistics use the stored originals; message counts describe parser records, not inferred dialogue turns. */
export function archiveStatistics(archives){
 const files=archives.map(a=>{
  const original=typeof a.original==='string'?a.original:'';
  return {id:a.id,filename:a.filename,format:a.format,characters:original.length,words:(original.match(/\S+/g)||[]).length,bytes:new TextEncoder().encode(original).length,records:a.messages?.length||0,parsed:a.format==='json' && (a.messages?.length||0)>0 && a.messages?.[0]?.speaker!=='transcript'};
 });
 return {files,fileCount:files.length,characters:files.reduce((n,f)=>n+f.characters,0),words:files.reduce((n,f)=>n+f.words,0),bytes:files.reduce((n,f)=>n+f.bytes,0),records:files.reduce((n,f)=>n+f.records,0),parsedRecords:files.filter(f=>f.parsed).reduce((n,f)=>n+f.records,0),unstructuredFiles:files.filter(f=>!f.parsed).length};
}
export function searchStatistics(results,elapsedMs=0){
 const counts=new Map();for(const r of results)counts.set(r.id,(counts.get(r.id)||0)+1);
 return {matches:results.length,elapsedMs,byArchive:counts};
}
export function getContext(archive,ordinal,offset,queryLength=0,radius=500){
 const index=archive?.messages?.findIndex(m=>m.ordinal===ordinal)??-1;
 if(index<0)return null;
 const m=archive.messages[index],start=Math.max(0,offset-radius),end=Math.min(m.text.length,offset+queryLength+radius);
 return {message:m,previous:archive.messages[index-1]||null,next:archive.messages[index+1]||null,start,end,text:m.text.slice(start,end),hasEarlier:start>0,hasLater:end<m.text.length};
}
