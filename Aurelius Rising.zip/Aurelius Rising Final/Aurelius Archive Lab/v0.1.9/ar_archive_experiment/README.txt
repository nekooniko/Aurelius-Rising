Aurelius Archive Lab v0.1.9 — Evidence Inspection & Optional Word Boundaries

New in v0.1.9:
- Optional complete-word/phrase matching in scene clues. OFF by default to preserve v0.1.8 behavior.
  When ON, a clue like "transform" will not match "transformation" or "transformed".
- Search excerpts highlight the literal clue phrases for faster review.
- Unstructured "Show surrounding context" includes ALL matched clue positions, even
  when they are thousands of characters apart, with 300 characters of padding.
- Source-preserving, local-only. No automatic changes to IndexedDB records.

Retained: 500–10,000 character unstructured proximity setting (2,000 default),
structured +/-2 message search, original archives, pagination, copy context,
DreamJourney header parsing, nested bundle import/export, archive stats.

Launch: in ar_archive_experiment run `python -m http.server 8765` and visit
http://localhost:8765/archive.html . Stop prior server and hard refresh.
Tests: `node test.mjs`. Browser testing still required.

Caution: Matches are literal candidates, not verified scenes or semantic search.
