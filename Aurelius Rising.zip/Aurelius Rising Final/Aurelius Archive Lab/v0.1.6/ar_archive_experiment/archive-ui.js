import {parseArchive,searchArchives,fingerprint,archiveStatistics,searchStatistics,getContext,preparedArchive,contextWindow,expandArchives} from './archive-core.js';
const $=id=>document.getElementById(id), DB='aurelius-archive-lab', STORE='archives';
function dbOpen(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE,{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function transact(mode,fn){const db=await dbOpen();try{return await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,mode),store=tx.objectStore(STORE);let request;try{request=fn(store)}catch(e){reject(e);return}tx.oncomplete=()=>resolve(request?.result);tx.onerror=()=>reject(tx.error);});}finally{db.close()}}
const all=()=>transact('readonly',s=>s.getAll());let archives=[];
const PAGE_SIZE=50;let currentPage=0,searchResults=[],searchElapsed=0,statsCache=null,searchTimer=null;
const fmt=n=>Number(n).toLocaleString(), millis=n=>`${n.toFixed(1)} ms`;
function el(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function metric(label,value,detail){const d=el('div',undefined,'metric');d.append(el('small',label),el('strong',value));if(detail)d.append(el('small',detail));return d;}
function renderStats(results,elapsed){const s=statsCache??(statsCache=archiveStatistics(archives)), ss=searchStatistics(results,elapsed),target=$('archive-stats');target.replaceChildren(metric('Imported files',fmt(s.fileCount)),metric('Source characters',fmt(s.characters)),metric('Estimated words',fmt(s.words)),metric('UTF-8 text size',`${(s.bytes/1024/1024).toFixed(2)} MiB`),metric('Searchable records',fmt(s.records),`${fmt(s.parsedRecords)} detected messages`),metric('Unstructured files',fmt(s.unstructuredFiles),'No reliable message boundaries'));
 const list=$('file-stats');list.replaceChildren();for(const f of s.files){const row=el('div',undefined,'file-stat');row.append(el('strong',f.filename),el('small',`${fmt(f.characters)} characters · ${fmt(f.words)} words · ${fmt(f.records)} searchable record(s) · ${f.parseMethod}`));list.append(row)}if(!s.files.length)list.append(el('p','Import files to see statistics.','muted'));
 $('search-metrics').replaceChildren(metric('Total matches',fmt(ss.matches)),metric('Search duration',millis(ss.elapsedMs)),metric('Files with matches',fmt(ss.byArchive.size)));
 const dist=$('match-distribution');dist.replaceChildren();if($('query').value.trim())for(const f of s.files){const count=ss.byArchive.get(f.id)||0,row=el('div',undefined,'distribution-row'),bar=el('div',undefined,'bar');bar.style.width=`${ss.matches?100*count/ss.matches:0}%`;row.append(el('span',`${f.filename}: ${fmt(count)}`),bar);dist.append(row)}
}
function showContext(wrap,r){
 const a=archives.find(a=>a.id===r.id);if(!a)return;
 const ctx=getContext(a,r.ordinal,r.offset,r.queryLength,600);if(!ctx)return;
 const panel=el('div',undefined,'context-panel');wrap.append(panel);
 let before=1,after=1,full=false,focusIndex=ctx.index;
 const displayText=t=>t.replace(/\\n/g,'\n').replace(/\\r/g,'\r').replace(/\\t/g,'\t'); // presentation only
 function draw(){
  panel.replaceChildren(el('strong',`Source: ${a.filename} · record ${r.ordinal+1} of ${a.messages.length} · character ${r.offset+1}`));
  panel.append(el('p',a.parseMethod==='unstructured'?'Unstructured source: displaying nearby characters without inventing message boundaries.':`Detected structure: ${a.parseMethod}. Source order is preserved.`,'muted'));
  const win=contextWindow(a,focusIndex,before,after);
  if(a.parseMethod==='unstructured'){
   panel.append(el('h3','Matching source passage'),el('pre',displayText(full?ctx.message.text:ctx.text)));
   if(!full)panel.append(el('small',`Excerpt characters ${fmt(ctx.start+1)}–${fmt(ctx.end)} of ${fmt(ctx.message.text.length)}`));
  }else{
   for(let i=0;i<win.messages.length;i++){
    const m=win.messages[i],absolute=win.start+i,section=el('div',undefined,'message-card');
    section.append(el('strong',`${absolute===ctx.index?'★ Match · ':''}${m.speaker} · message ${absolute+1}${m.timestamp?' · '+m.timestamp:''}`));
    const text=absolute===ctx.index&&!full&&m.text.length>1600?ctx.text:m.text;
    section.append(el('pre',displayText(text)));panel.append(section);
   }
  }
  const actions=el('div',undefined,'actions');
  function button(label,fn,disabled=false){const b=el('button',label);b.disabled=disabled;b.addEventListener('click',fn);actions.append(b);}
  if(a.parseMethod!=='unstructured'){
   button('↑ 3 earlier messages',()=>{before+=3;draw()},win.start===0);
   button('↓ 3 later messages',()=>{after+=3;draw()},win.end===win.total);
   const jump=el('div',undefined,'jump-control'),label=el('label','Jump to message number');
   const input=el('input');input.type='number';input.min='1';input.max=String(a.messages.length);input.value=String(focusIndex+1);input.setAttribute('aria-label','Message number');
   const go=el('button','Go');const navigate=()=>{const n=Number(input.value);if(!Number.isInteger(n)||n<1||n>a.messages.length){input.setCustomValidity(`Enter 1–${a.messages.length}`);input.reportValidity();return;}input.setCustomValidity('');focusIndex=n-1;before=1;after=1;draw();};
   go.addEventListener('click',navigate);input.addEventListener('keydown',e=>{if(e.key==='Enter')navigate()});jump.append(label,input,go);panel.append(jump);
  }
  button('Copy visible context',()=>{const content=a.parseMethod==='unstructured'?(full?ctx.message.text:ctx.text):win.messages.map((m,i)=>`[${m.speaker} · message ${win.start+i+1}]\n${m.text}`).join('\n\n');navigator.clipboard.writeText(`Source: ${a.filename}\n\n${content}`).then(()=>{const note=el('small','Copied to clipboard.');panel.append(note);setTimeout(()=>note.remove(),2000)}).catch(()=>{const note=el('small','Clipboard unavailable. Select text to copy.');panel.append(note)})});
  button(full?'Show compact match':'Show full matching message',()=>{full=!full;draw()});
  button('Close context',()=>panel.remove());panel.append(actions);
 }
 draw();
}
function renderPage(){
 const target=$('results');target.replaceChildren();const totalPages=Math.max(1,Math.ceil(searchResults.length/PAGE_SIZE));currentPage=Math.min(Math.max(currentPage,0),totalPages-1);
 const begin=currentPage*PAGE_SIZE;
 for(const r of searchResults.slice(begin,begin+PAGE_SIZE)){
  const wrap=el('div',undefined,'result');wrap.append(el('strong',`${r.filename} — ${r.speaker} (record ${r.ordinal+1}, character ${r.offset+1})`),el('pre',r.excerpt));
  const btn=el('button','Show surrounding context');btn.addEventListener('click',()=>{if(wrap.querySelector('.context-panel'))return;showContext(wrap,r)});wrap.append(btn);target.append(wrap);
 }
 const nav=$('result-navigation');nav.replaceChildren();if(searchResults.length>PAGE_SIZE){
  const prev=el('button','← Previous 50');prev.disabled=currentPage===0;prev.addEventListener('click',()=>{currentPage--;renderPage()});
  const next=el('button','Next 50 →');next.disabled=currentPage===totalPages-1;next.addEventListener('click',()=>{currentPage++;renderPage()});
  nav.append(prev,el('span',`Page ${fmt(currentPage+1)} of ${fmt(totalPages)} · results ${fmt(begin+1)}–${fmt(Math.min(begin+PAGE_SIZE,searchResults.length))} of ${fmt(searchResults.length)}`),next);
 }
}
function render(){const q=$('query').value,t0=performance.now();searchResults=searchArchives(archives,q);searchElapsed=performance.now()-t0;currentPage=0;
 for(const r of searchResults)r.queryLength=q.trim().length;
 renderStats(searchResults,searchElapsed);
 $('stats').textContent=q.trim()?`${fmt(searchResults.length)} match(es) across ${fmt(new Set(searchResults.map(r=>r.id)).size)} file(s). Browse all matches in pages of ${PAGE_SIZE}.`:'Enter a phrase to search imported source content.';
 renderPage();
}
async function refresh(){archives=expandArchives(await all());statsCache=null;render()}
$('files').addEventListener('change',async e=>{let added=0,duplicates=0;try{for(const file of e.target.files){const text=await file.text(),id=await fingerprint(text);if((await all()).some(a=>a.id===id)){duplicates++;continue;}const a={...parseArchive(text,file.name),id};await transact('readwrite',s=>s.put(a));added++;}$('status').textContent=`Imported ${added} file(s); skipped ${duplicates} exact duplicate(s).`;await refresh();}catch(err){$('status').textContent=`Import failed: ${err.message}`;}e.target.value='';});
$('query').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(render,180)});
$('export').addEventListener('click',async()=>{const blob=new Blob([JSON.stringify({schema:'aurelius-archive-v1',exportedAt:new Date().toISOString(),archives:await all()},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='aurelius-conversation-archive.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
$('clear').addEventListener('click',async()=>{if(!confirm('Permanently delete all archives stored by this experiment in this browser?'))return;await transact('readwrite',s=>s.clear());await refresh();$('status').textContent='Local archive cleared.';});
refresh().catch(e=>{$('status').textContent=`Storage unavailable: ${e.message}`});
