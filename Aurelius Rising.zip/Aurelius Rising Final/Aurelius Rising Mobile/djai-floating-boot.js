// Minimal floating-page health check, independent of ChatGPT popup initialization.
(() => {
  const status = document.getElementById('floating-diagnostic');
  const interval = document.getElementById('djai-reminder-interval');
  const intervalKey = 'aureliusDjaiInjectionReminderInterval';
  const arm = document.getElementById('djai-arm');
  if (!status || !arm) return;
  status.textContent = 'DJAI-only panel loaded · checking controls…';
  arm.addEventListener('click', () => {
    status.textContent = 'Arm click received · checking injection status below';
  }, {capture:true});
  window.addEventListener('error', event => {
    const message = String(event.message || 'unknown error');
    const source = String(event.filename || '');
    const location = source
      ? ` · ${source.split('/').pop()}:${event.lineno || 0}:${event.colno || 0}`
      : ' · source details unavailable';
    status.textContent = 'Panel script error: ' + message + location;
  });
  window.addEventListener('unhandledrejection', event => {
    status.textContent = 'Panel async error: ' + String(event.reason?.message || event.reason || 'unknown error');
  });
  if (typeof chrome === 'undefined' || !chrome.storage?.local) {
    status.textContent = 'Extension storage unavailable in floating frame';
  } else {
    status.textContent = 'DJAI-only panel ready · tap Arm to test';
    for (let count = 10; count <= 20; count++) interval.add(new Option(`Every ${count} sent messages`, String(count)));
    interval.disabled = true;
    chrome.storage.local.get(intervalKey).then(settings => {
      const saved = settings[intervalKey];
      if (Number.isInteger(saved) && saved >= 10 && saved <= 20) interval.value = String(saved);
      interval.disabled = false;
    }).catch(() => { status.textContent = 'Could not load reminder settings.'; });
    interval.addEventListener('change', () => {
      void chrome.storage.local.set({[intervalKey]: Number(interval.value)})
        .catch(() => { status.textContent = 'Could not save reminder interval. Reopen the menu to try again.'; });
    });
  }
  if (new URLSearchParams(location.search).get('review') === 'scene') {
    document.getElementById('djai-injector').scrollIntoView();
  }
})();
