// JLLM preparation tab. Local-only, no website access or automatic injection.
document.addEventListener('DOMContentLoaded',async()=>{
  const seed=document.getElementById('jllm-seed');
  const status=document.getElementById('jllm-status');
  const stats=document.getElementById('jllm-seed-stats');
  const KEY='aureliusJllmContextSeed';
  const update=()=>{stats.textContent=`${seed.value.length.toLocaleString()} characters · approx. ${Math.ceil(seed.value.length/4).toLocaleString()} tokens (rough estimate)`;};
  try { const data=await chrome.storage.local.get(KEY); seed.value=data[KEY]||''; update(); }
  catch(e){status.textContent='Could not load local seed: '+e.message;}
  async function requestChat(type){
    if (location.pathname.endsWith('/jllm-floating.html') && window.parent !== window) {
      const hostOrigin = new URLSearchParams(location.hash.slice(1)).get('parent');
      if (!['https://janitorai.com', 'https://www.janitorai.com'].includes(hostOrigin)) {
        throw new Error('Reopen the JLLM menu from a JanitorAI chat.');
      }
      const id = crypto.randomUUID();
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          window.removeEventListener('message', onReply);
          reject(new Error('JLLM menu did not respond. Reload the chat and retry.'));
        }, 2500);
        function onReply(event){
          if (event.source !== window.parent || event.origin !== hostOrigin ||
              event.data?.channel !== 'aurelius-jllm-floating' || event.data.replyTo !== id) return;
          clearTimeout(timer);
          window.removeEventListener('message', onReply);
          resolve(event.data.result);
        }
        window.addEventListener('message', onReply);
        window.parent.postMessage({channel:'aurelius-jllm-floating', id, type}, hostOrigin);
      });
    }
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if (!tab || !/^https:\/\/(www\.)?janitorai\.com\/chats\//.test(tab.url||'')) return null;
    return chrome.tabs.sendMessage(tab.id,{type});
  }
  document.getElementById('jllm-open-archive-lab').addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL('archive.html')}));
  document.getElementById('jllm-open-saved-chats').addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL('archive.html#jllm-archive')}));
  document.getElementById('jllm-lite-open').addEventListener('click',async()=>{
    try{const result=await requestChat('AURELIUS_JLLM_LITE_OPEN');
      status.textContent=result?.ok?'Node selector opened in the JLLM chat.':'Open a JLLM chat first.';
    }catch{status.textContent='Refresh the JLLM page after updating the extension.';}
  });
  seed.addEventListener('input',update);
  document.getElementById('jllm-save').addEventListener('click',async()=>{
    try{await chrome.storage.local.set({[KEY]:seed.value});status.textContent='Context seed saved locally.';}
    catch(e){status.textContent='Save failed: '+e.message;}
  });
  document.getElementById('jllm-copy').addEventListener('click',async()=>{
    try{await navigator.clipboard.writeText(seed.value);status.textContent='Context seed copied. Paste and review it in JLLM.';}
    catch(e){status.textContent='Copy failed: '+e.message;}
  });
});
