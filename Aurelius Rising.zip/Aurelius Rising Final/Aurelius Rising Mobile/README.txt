Aurelius Rising v0.5.8.45 — Opt-in Analytics, Behavioral Modules & Pink UI

INSTALL
1. Extract the ZIP into a folder.
2. Open chrome://extensions, enable Developer mode, and choose Load unpacked.
3. Select the extracted folder. If upgrading, remove the old unpacked extension or update its files and reload the extension.
4. Reload any open ChatGPT tabs.

WHAT'S NEW
- Fixes the narrow mobile layout for the Download presets JSON and Import presets JSON controls.
- DreamJourney AI experimental combined character ceiling now includes 100,000 characters. This is an extension-side request ceiling, not a confirmed DJAI context or server limit; the 100,000 option has not been verified live.
- Pink-on-charcoal popup theme.
- Six built-in editable behavioral lessons, each with instruction, reason, example, enable switch, mode, and message interval.
- Manual insertion of a selected module or all enabled modules.
- Automatic injection schedules enabled recurring modules independently, alongside the existing custom reminder.
- All new modules default DISABLED. Existing custom settings remain stored under their original keys.

IMPORTANT
- Automatic injection remains opt-in, and auto-send remains separately opt-in.
- Manual mode modules are never injected on a schedule.
- Automatic draft mode inserts reminders into the visible ChatGPT composer, NOT into a hidden model/system context.
- Auto-send sends only if the composer is empty; if it contains a user's draft, it waits.
- Manual insertion never sends.
- Intervals count observed user messages in a ChatGPT /c/<conversation-id> route, not tokens or necessarily all historical messages.
- Browser DOM changes may break composer insertion or message counting.
- JLLM memories are managed locally: select them, preview them, copy them, and paste them into JanitorAI memory fields. Aurelius does not inject those memories into JLLM requests.
- Existing injection thresholds are preserved for custom reminders; new module thresholds start fresh.
- Test automatic injection in a disposable conversation first.


v0.4.2: Master interval controls all enabled recurring modules; Research Before Contradiction has a dedicated manual button. On first run or re-enabling automatic injection, countdown starts from current observed user count. Existing per-conversation schedule state migrates to v2 without sending an overdue reminder.

0.4.3: Manual injection composer detection and error feedback improved.

Version 0.4.5: Each behavior module now expands with the original outlined pixel star and collapses with the filled pixel star. Hearts still toggle enabled state independently. Expanded settings appear directly beneath the module.

Version 0.4.6: Force-hide the shared editor unless its star is expanded. Fixes built-in prompts showing outside dropdown.


v0.5.0: Added ChatGPT / DreamJourney AI tabs. DreamJourney tab imports Nexus JSON locally, searches and selects nodes, previews and copies their context. It does NOT yet perform invisible injection or modify DJAI chat requests. Existing ChatGPT scripts and settings remain unchanged. Nexus data stays in the popup memory and is cleared when the popup closes.


v0.5.1 — DJAI compatibility lab
- Adds a read-only active-tab DOM inspection button on the DreamJourney tab.
- Reports page origin/path, form and editor counts, and limited element metadata.
- Does not capture conversation text, typed messages, tokens, cookies, or network requests.
- Does not inject hidden context or send messages.
- Uses activeTab + scripting permissions, granted when the user clicks the extension.
- To test: open a DJAI chat in the browser, open Aurelius Rising, select DreamJourney, click Inspect active chat tab, and copy the report.
- Do not assume an invisible context API exists until the site integration has been verified.


v0.5.2 — experimental one-message DJAI Director context test
- DreamJourney tab: enter a short harmless test fact, then click Arm next DJAI message.
- Send a normal DJAI message, reopen popup and Check injection status.
- The page MAIN-world fetch wrapper attempts to append the test fact to director.instruction in exactly one POST /api/chat request, preserving the original instruction in that request.
- Does NOT change saved Director note, send messages, log requests, capture credentials, or persist the test fact.
- If the combined instruction exceeds 500 characters, or the request format differs, it skips modification and sends the original request.
- Status 'modified outgoing request' does NOT prove DJAI server/model accepted or used the extra context. Verify with a harmless test.
- Cancel pending injection before sending; reloading the DJAI page also clears the pending hook.
- This is a brittle experiment tied to the observed November 2026 client request structure; it may stop working after DJAI updates.


Aurelius Rising v0.5.3 — Director's Note Injector
- In the DreamJourney tab, write injection instructions and optionally include selected Nexus nodes.
- Save injector prompt locally; arming applies to one outgoing /api/chat request only.
- Existing director.instruction is preserved and appended to; if empty, an instruction is attempted.
- Experimental combined 500-character guard; if over limit, request is sent unchanged.
- No persistent DJAI Director Note edits; success requires checking status and observing model behavior.
- Updating the extension may require reloading the DJAI tab.

0.5.5: Experimental request-size ceilings 500/1000/2000/4000/8000; per-fact Nexus selection. Larger limits are not verified by DJAI.

0.5.6: Transparent draggable shooting-star launcher on DJAI session pages, quick one-shot Director injection and status. Full Nexus selector remains in popup.


VERSION 0.5.8.11 — JLLM READ-ONLY MESSAGE DETECTOR
- Adds janitorai.com content script using observed data-index and message wrapper selectors.
- JLLM tab: Check active JLLM chat; shows loaded count, visible indices, highest observed index.
- Virtualized list indices are not a verified total message count.
- No automatic message injection, network interception, or JLLM conversation archive.
- Preserve existing extension identity: replace files in the SAME loaded unpacked extension directory, then Reload at chrome://extensions. Reload the JanitorAI chat page to attach the new content script.


JLLM archive (v0.5.8.12): Opt-in capture via JLLM popup tab. Scroll through a chat while capture is enabled; currently rendered messages are saved under per-chat chrome.storage.local keys. The Archive Lab JLLM saved messages section supports search, browsing, per-chat/all JSON downloads, and per-chat deletion. Virtualized messages not visited during capture are not archived. Capture stops on reload or chat navigation. Storage is subject to Chrome local quota; this is not a complete conversation export.

v0.5.8.13 — JLLM selected-memory injection
- Selected Memory Nodes Lite facts are inserted into JanitorAI's `/generateAlpha` request as a hidden system message at the chosen 10, 15, or 20 message interval. OpenAI-compatible `/chat/completions` requests with a `messages` array are also supported.
- Injection is enabled by default for selected nodes and can be turned off in the memory panel. The panel reports whether the hidden request hook is connected, how many messages remain, and when context was injected.
- Automatic injection never writes selected memory text into the chat textbox. The manual lorebook copy controls were removed to avoid confusing a copied prompt with hidden injection.
- If a generation request does not contain a recognized `messages` array, the panel reports that it was skipped; it does not paste text into the composer. The extension cannot verify server/model acceptance.


v0.5.8.13 — Optional local live conversation capture
- Independent opt-in toggles for DreamJourney AI and JanitorAI. When enabled, rendered chat messages are appended/updated in local extension storage as they appear.
- DreamJourney AI capture watches the session message list. JanitorAI capture watches rendered message positions. The extension stores text locally and does not upload it.
- A 30-minute alarm displays a checkpoint notification while either platform toggle is on. An active-page timer also requests the reminder and shows an in-page prompt if the browser notification call fails. “Save checkpoint” records a timestamp and message position/count; “Open archive” opens the local archive page.
- The Archive Lab lists both platforms, shows last-saved times and checkpoint timestamps, supports per-chat deletion, and exports one conversation or all conversations as JSON.
- Disabling capture stops future collection but keeps previously saved archives. A separate “Save checkpoint now” action is available in each platform tab.
- Requires alarms, notifications, and unlimited local storage permissions. Notification timing can be delayed while the device sleeps; it will not wake the device.
- Live capture only sees messages rendered by the site's chat page. Missing/unrendered content is not fabricated. Export periodically for an independent backup.

v0.5.8.14 — DreamJourney AI capture speaker labels
- Deduplicates nested DJAI message wrappers that repeat the same message ID. The outer wrapper carries the bot avatar; keeping it prevents the nested wrapper from overwriting bot replies as user messages.

v0.5.8.15 — DJAI role detection and active-page reminder fallback
- Associates bot avatar IDs with every nested wrapper carrying that ID, then deduplicates the wrappers. This preserves the bot role even when the inner duplicate lacks the avatar element.
- Adds an active-page 30-minute reminder fallback for DJAI and JanitorAI. It requests the same native notification and shows a page prompt with save/open actions if the browser rejects the notification.

Orion no-live-capture build (0.5.8.16): Removed automatic conversation capture, capture reminders and live-capture archive controls. Manual TXT/JSON Archive Lab import and JLLM Memory Nodes Lite remain available.


v0.5.8.22 — DJAI scene injection reminders
In the floating menu's Director's Note Injector, choose Off or a reminder every 10–20 sent messages. The reminder opens the injector so you can choose the scene's Nexus facts and instructions and arm the next request yourself. The count is per chat in the current tab and restarts after an injected request gets a successful HTTP response.


v0.5.8.23 — Added a tap-to-open JLLM star menu with the context seed, message detector, Memory Nodes Lite, and archive shortcuts.


v0.5.8.24 — Added the notification picture to the existing DJAI scene reminder and the injection status inside JLLM Memory Nodes Lite.


v0.5.8.25 — Fixed the mobile JLLM message detector and Memory Nodes Lite launcher when the floating frame has no referrer.


v0.5.8.26 — Orion mobile preset button layout
- Separates Download presets JSON from the Import presets JSON label and file picker in the popup and floating panel.
- Gives the export action a full-width button and removes the 380 px minimum width at narrow viewports.
- Preset behavior is unchanged. This remains the mobile build and does not add live capture.


v0.5.8.27 — Mobile panel overflow and diagnostics
- Wraps long Nexus node names and fact text so saved libraries do not widen the mobile panel.
- Adds source filename and line/column to the floating panel script-error status when the browser exposes them.
- Keeps the v0.5.8.26 preset control layout and Orion mobile feature set.


v0.5.8.28 — Mobile Nexus injection persistence
- Saves the “Include selected Nexus nodes” choice locally so the floating panel review/reload flow does not silently turn it off.
- Injection preview reports whether selected Nexus context will be included, excluded, or is empty, including its character count.
- Preserves the v0.5.8.27 mobile layout and diagnostics.


v0.5.8.29 — Neutral mobile injection labels
- Removes the Aurelius Rising wrapper from the injected Director’s Note.
- Labels selected reference material as “Selected Nexus context” without extension branding.
- Keeps the v0.5.8.28 mobile injection-setting persistence and preview.


v0.5.8.30 — JLLM Current Scene card
- Adds a per-chat Current Scene card to Memory Nodes Lite with location, your character, people present, and an optional scene note.
- Saves scene details with that chat and includes them in hidden context alongside selected memory nodes when auto-injection is enabled.
- Adds a separate include toggle and clear action; an empty or excluded scene is not injected.
- Keeps the Orion mobile feature set and does not add live capture.


v0.5.8.31 — DreamJourney Current Scene card
Adds a per-chat Current Scene card to the DreamJourney AI floating panel. Location, player character, present characters, and an optional scene note can be saved per chat. When enabled, the scene is included with the hidden context in the next explicitly armed DJAI request. JLLM’s separate Current Scene card remains available.

v0.5.8.32 — Popup initialization guard
Fixes an initialization error when the standard extension popup loads the shared DreamJourney script without the floating panel’s scene fields. The Current Scene card remains in the DreamJourney floating panel.

v0.5.8.33 — Current Scene in DreamJourney popup
Adds the Current Scene card to both the DreamJourney extension tab and floating panel. Both surfaces resolve and use the active DreamJourney chat ID for shared per-chat scene storage.

v0.5.8.34 — Chat-scoped and compatibility fixes
Binds one-shot DJAI injections to the session active when armed, targets floating-panel relays to their originating tab, handles fetch(Request) bodies, resets the JLLM injection baseline when the chat changes, and preserves saved ChatGPT behavioral module edits when reopening settings.

v0.5.8.35 — JLLM bridge connection check
The Memory Nodes Lite panel requests a fresh hidden-hook acknowledgement when opened and provides a Check connection button. Missing acknowledgements time out with a useful error. The latest per-chat connection result is saved and shown on reopening. The page bridge acknowledges explicit checks even when configuration is unchanged.

v0.5.8.37 — JLLM request diagnostics and one-shot test
Memory Nodes Lite now distinguishes settings received, generation-request candidates observed, unsupported paths/body formats, counter skips, and modified outgoing requests. Request diagnostics store only method, sanitized host/path, body type, safe content-type, stage, and skip reason; request content and credentials are not recorded. Added Inject on next reply to bypass the counter for one supported request.

0.5.8.38: Import the current DreamJourney chat’s Nexus directly into the local node library. The one-shot same-origin read imports entities, preserves matching selections and presets, and leaves DJAI unchanged; manual JSON import remains available.

0.5.8.39: Added direct current-chat Nexus import to the DreamJourney floating hover menu. The shared local library is updated in place; matching selections and presets are retained.

0.5.8.40: JLLM diagnostics show redacted JSON request/response structure and response status without recording values. JanitorAI tracking-route traffic is ignored; /hampter/chats/:chat-id/messages remains diagnostic-only and is not an injection target.

0.5.8.41: Replaced JLLM hidden injection with a manual memory workflow. Added a live preview and Copy selected memories action. Removed JLLM request hooks, injection counters, message detector, and connection diagnostics; DreamJourney and ChatGPT features remain separate.

v0.5.8.44 — Opt-in analytics
- Adds local generation, reroll, and continuity-correction counts. Collection is off by default.
- ChatGPT and DreamJourney generation observation is content-free; ChatGPT counts replies following a detected send/retry action, JLLM and continuity corrections are logged manually because the extension does not hook JLLM requests or judge response quality.
- Optional per-platform joules-per-generation values produce modeled estimates only. Blank values mean no energy estimate is reported.
- The report preview and JSON download contain aggregate counts only. Users can delete local counts.
- Sending is a separate opt-in action to a user-configured HTTPS server. No server is bundled or deployed. The companion analytics-server scaffold explains setup and report limitations.
- No messages, prompts, responses, chat identifiers, model names, URLs, account identifiers, or device identifiers are collected for analytics.
- ChatGPT only counts a newly observed assistant reply following a detected send/retry action; those accessible labels can change. DreamJourney counts successful replies; context-added means the adapter modified that request, not that the server/model used it.


v0.5.8.45 — Hosted opt-in analytics endpoint
- Prefills the Aurelius Rising analytics receiver at https://aurelius-rising-analytics.aurelius-rising.workers.dev/api/analytics. Users can edit the endpoint.
- Collection remains off by default, and sending requires the user's explicit consent and Send action.
- Reports contain aggregate counts only; no prompts, messages, chat IDs, account IDs, or device IDs are sent.
