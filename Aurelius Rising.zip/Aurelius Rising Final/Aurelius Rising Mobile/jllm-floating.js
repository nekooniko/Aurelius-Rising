(() => {
  const frameUrl = chrome.runtime.getURL('jllm-floating.html');
  const extensionOrigin = new URL(frameUrl).origin;
  const chat = () => location.pathname.match(/^\/chats\/([^/]+)/)?.[1];
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;right:14px;bottom:110px;z-index:2147483646;pointer-events:none';
  const root = host.attachShadow({mode:'open'});
  root.innerHTML = `<style>
    *{box-sizing:border-box}
    button{cursor:pointer}
    .star{pointer-events:auto;border:0;width:52px;height:52px;background:transparent;padding:0;touch-action:manipulation}
    .star img{width:100%;height:100%;object-fit:contain;image-rendering:pixelated}
    .panel{pointer-events:auto;position:absolute;bottom:60px;right:0;width:min(380px,calc(100vw - 28px));height:min(600px,calc(100dvh - 180px));overflow:hidden;background:#24212e;color:#fff;border:1px solid #9b7aa9;border-radius:14px;box-shadow:0 8px 35px #0009;display:flex;flex-direction:column}
    .panel[hidden]{display:none}
    header{display:flex;justify-content:space-between;align-items:center;padding:0 10px;background:#292332;color:#ffa4dd;font:700 14px system-ui}
    .close{width:44px;height:44px;background:transparent;border:0;color:#fff;font-size:24px}
    iframe{width:100%;min-height:0;flex:1;border:0}
  </style>
  <section class="panel" hidden aria-label="Aurelius Rising JLLM tools">
    <header><span>Aurelius Rising · JLLM</span><button type="button" class="close" aria-label="Close JLLM menu">×</button></header>
    <iframe title="Aurelius Rising JLLM controls" allow="clipboard-write" referrerpolicy="origin"></iframe>
  </section>
  <button type="button" class="star" aria-label="Aurelius Rising JLLM menu" aria-expanded="false"><img alt="" src="${chrome.runtime.getURL('assets/aurelius-rising-icon.png')}"></button>`;
  const panel = root.querySelector('.panel');
  const star = root.querySelector('.star');
  const frame = root.querySelector('iframe');
  function setOpen(open) {
    panel.hidden = !open;
    if (open && !frame.hasAttribute('src')) frame.src = frameUrl + '#parent=' + encodeURIComponent(location.origin);
    star.setAttribute('aria-expanded', String(open));
  }
  star.addEventListener('click', () => setOpen(panel.hidden));
  root.querySelector('.close').addEventListener('click', () => {
    setOpen(false);
    star.focus();
  });
  window.addEventListener('message', async event => {
    const request = event.data;
    if (event.source !== frame.contentWindow ||
        (event.origin !== extensionOrigin && event.origin !== 'null') ||
        request?.channel !== 'aurelius-jllm-floating' || typeof request.id !== 'string' || !chat()) return;
    let result;
    if (request.type === 'AURELIUS_JLLM_LITE_OPEN') {
      result = await globalThis.aureliusJllmOpenNodes().catch(() => ({ok:false}));
      if (result.ok) setOpen(false);
    } else return;
    event.source.postMessage({channel:'aurelius-jllm-floating', replyTo:request.id, result},
      event.origin === 'null' ? '*' : extensionOrigin);
  });
  let currentChat;
  function updateRoute() {
    const next = chat();
    if (next === currentChat) return;
    currentChat = next;
    setOpen(false);
    if (next && !host.isConnected) document.documentElement.append(host);
    if (!next) host.remove();
  }
  new MutationObserver(updateRoute).observe(document.documentElement,{childList:true,subtree:true});
  updateRoute();
})();
